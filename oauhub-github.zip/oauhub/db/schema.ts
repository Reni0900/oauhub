// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import { sqliteTable, text, integer, real, index, uniqueIndex } from 'drizzle-orm/sqlite-core';
export const accounts = sqliteTable('accounts', {id:text('id').primaryKey(),email:text('email').notNull(),passwordHash:text('password_hash').notNull(),created:integer('created').notNull()},t=>[uniqueIndex('idx_accounts_email').on(t.email)]);
export const sessions = sqliteTable('auth_sessions', {tokenHash:text('token_hash').primaryKey(),accountId:text('account_id').notNull().references(()=>accounts.id,{onDelete:'cascade'}),expiresAt:integer('expires_at').notNull()},t=>[index('idx_auth_sessions_expiry').on(t.expiresAt)]);
export const authLimits = sqliteTable('auth_limits',{key:text('key').primaryKey(),attempts:integer('attempts').notNull().default(0),expiresAt:integer('expires_at').notNull()},t=>[index('idx_auth_limits_expiry').on(t.expiresAt)]);
export const students = sqliteTable('students', {
 id: text('id').primaryKey(), name:text('name').notNull(), hostel:text('hostel').notNull(), faculty:text('faculty').notNull(), color:text('color').notNull(), appearance:text('appearance').notNull().default('{}'),
 x:real('x').notNull().default(0), z:real('z').notNull().default(0), money:integer('money').notNull().default(5000), energy:integer('energy').notNull().default(80), hunger:integer('hunger').notNull().default(75), study:integer('study').notNull().default(0), lastSeen:integer('last_seen').notNull().default(0), lastAction:integer('last_action').notNull().default(0), lastChat:integer('last_chat').notNull().default(0), block:text('block').notNull().default('A'), room:integer('room').notNull().default(0), inside:text('inside').notNull().default(''), hygiene:integer('hygiene').notNull().default(70), social:integer('social').notNull().default(50), actionNonce:text('action_nonce').notNull().default('')
}, t=>[index('idx_students_last_seen').on(t.lastSeen),index('idx_students_room').on(t.hostel,t.block,t.room)]);
export const messages = sqliteTable('messages', { id:text('id').primaryKey(), userId:text('user_id').notNull(), name:text('name').notNull(), body:text('body').notNull(), x:real('x').notNull(), z:real('z').notNull(), created:integer('created').notNull() },t=>[index('idx_messages_created').on(t.created)]);
export const roomMessages=sqliteTable('room_messages',{id:text('id').primaryKey(),channel:text('channel').notNull(),userId:text('user_id').notNull(),name:text('name').notNull(),body:text('body').notNull(),created:integer('created').notNull()},t=>[index('idx_room_messages_channel_created').on(t.channel,t.created)]);
export const directMessages=sqliteTable('direct_messages',{id:text('id').primaryKey(),sender:text('sender').notNull(),recipient:text('recipient').notNull(),body:text('body').notNull(),created:integer('created').notNull()},t=>[index('idx_dm_sender_created').on(t.sender,t.created),index('idx_dm_recipient_created').on(t.recipient,t.created)]);
export const walletEntries=sqliteTable('wallet_entries',{id:text('id').primaryKey(),userId:text('user_id').notNull(),label:text('label').notNull(),amount:integer('amount').notNull(),created:integer('created').notNull()},t=>[index('idx_wallet_user_created').on(t.userId,t.created)]);
export const campusInventory=sqliteTable('campus_inventory',{userId:text('user_id').notNull(),item:text('item').notNull()},t=>[uniqueIndex('idx_inventory_owner_item').on(t.userId,t.item)]);
export const campusCandidates=sqliteTable('campus_candidates',{id:text('id').primaryKey(),name:text('name').notNull(),manifesto:text('manifesto').notNull(),policy:text('policy').notNull(),week:integer('week').notNull()},t=>[index('idx_candidates_week').on(t.week)]);
export const campusVotes=sqliteTable('campus_votes',{userId:text('user_id').notNull(),week:integer('week').notNull(),candidate:text('candidate').notNull()},t=>[uniqueIndex('idx_votes_user_week').on(t.userId,t.week),index('idx_votes_candidate_week').on(t.candidate,t.week)]);
export const campusEventEntries=sqliteTable('campus_event_entries',{userId:text('user_id').notNull(),day:integer('day').notNull(),event:text('event').notNull(),attended:integer('attended').notNull().default(0)},t=>[uniqueIndex('idx_event_owner_day').on(t.userId,t.day,t.event)]);
export const campusBoard=sqliteTable('campus_board',{id:text('id').primaryKey(),userId:text('user_id').notNull(),name:text('name').notNull(),body:text('body').notNull(),created:integer('created').notNull()},t=>[index('idx_board_created').on(t.created)]);
export const campusShifts=sqliteTable('campus_shifts',{userId:text('user_id').primaryKey(),job:text('job').notNull(),started:integer('started').notNull(),claimed:integer('claimed').notNull().default(0)});

// A permanent fictional game background, allocated once when an account opens.
export const accountOrigins=sqliteTable('account_origins',{
 accountId:text('account_id').primaryKey().references(()=>accounts.id,{onDelete:'cascade'}),
 background:text('background').notNull(),gender:text('gender').notNull(),
 startingMoney:integer('starting_money').notNull(),hostel:text('hostel').notNull(),
 created:integer('created').notNull()
});
