import {build} from 'rolldown';
import {mkdirSync,writeFileSync,readFileSync,copyFileSync} from 'node:fs';
const release=JSON.parse(readFileSync('public/version.json','utf8'));
const api=process.env.OAUHUB_API_URL;
if(!api||!/^https:\/\/[a-z0-9.-]+$/.test(api))throw new Error('Set OAUHUB_API_URL to the deployed Cloudflare API origin (HTTPS, no trailing slash).');
mkdirSync('dist/pages',{recursive:true});mkdirSync('dist/worker',{recursive:true});
await build({input:'hosting/entry.tsx',platform:'browser',plugins:[{name:'oauhub-api-client',transform(code,id){if(/app[\\/](game|account-dialog|phone-messages)\.tsx$/.test(id))return `import {campusFetch} from '../hosting/api-client';\n`+code.replace(/\bfetch\(/g,'campusFetch(');}}],transform:{define:{'process.env.NODE_ENV':'"production"','__OAUHUB_API_URL__':JSON.stringify(api)},jsx:{runtime:'automatic',importSource:'react'}},output:{file:'dist/pages/game.js',format:'esm',minify:true}});
await build({input:'hosting/worker.ts',platform:'neutral',external:['cloudflare:workers','crypto','node:crypto'],output:{file:'dist/worker/index.js',format:'esm',minify:true}});
writeFileSync('dist/pages/index.html','<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OAUHub — Your campus, your story</title><link rel="icon" href="./favicon.svg"><link rel="stylesheet" href="./game.css?v='+release.version+'"></head><body><div id="root"></div><script type="module" src="./game.js?v='+release.version+'"></script></body></html>');
writeFileSync('dist/pages/game.css',readFileSync('app/globals.css'));copyFileSync('public/favicon.svg','dist/pages/favicon.svg');writeFileSync('dist/pages/.nojekyll','');
console.log('Built GitHub Pages frontend and Cloudflare API.');

for(const name of ['version.json','food-menu-v2.png'])copyFileSync('public/'+name,'dist/pages/'+name);
