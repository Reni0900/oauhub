# OAUHub version policy

The user saved the current public application as **Version 1** on 5 October 2026 and requested that subsequent changes become **Version 2**.

- Preserve the GitHub tag `v1.0.0` and commit `08f1dea28c9225fc5375a2bb0147be85e97a769b`.
- Preserve `../versions/oauhub-v1.0.0/` and `../versions/oauhub-v1.0.0.zip`; never overwrite these snapshots during builds or packaging.
- Implement future requested changes in this working checkout as Version 2. Preview and verify them before publishing; release the resulting version under a new `v2.0.0` tag when complete.
- GitHub Pages remains the frontend host. The Cloudflare gateway uses the existing Sites backend database. A code version snapshot does not contain or roll back player accounts and progress.
- The existing `../oau-life` Site checkout is the separate backend source. Do not treat frontend version changes as authorization to modify its database.
