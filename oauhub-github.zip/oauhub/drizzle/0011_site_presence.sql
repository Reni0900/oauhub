CREATE TABLE site_presence (
 visitor_id TEXT PRIMARY KEY NOT NULL,
 first_seen INTEGER NOT NULL,
 last_seen INTEGER NOT NULL
);
CREATE INDEX site_presence_last_seen ON site_presence(last_seen);
