CREATE TABLE `campus_board` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`name` text NOT NULL,
	`body` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_board_created` ON `campus_board` (`created`);--> statement-breakpoint
CREATE TABLE `campus_candidates` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`manifesto` text NOT NULL,
	`policy` text NOT NULL,
	`week` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_candidates_week` ON `campus_candidates` (`week`);--> statement-breakpoint
CREATE TABLE `campus_event_entries` (
	`user_id` text NOT NULL,
	`day` integer NOT NULL,
	`event` text NOT NULL,
	`attended` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_event_owner_day` ON `campus_event_entries` (`user_id`,`day`,`event`);--> statement-breakpoint
CREATE TABLE `campus_inventory` (
	`user_id` text NOT NULL,
	`item` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_inventory_owner_item` ON `campus_inventory` (`user_id`,`item`);--> statement-breakpoint
CREATE TABLE `campus_shifts` (
	`user_id` text PRIMARY KEY NOT NULL,
	`job` text NOT NULL,
	`started` integer NOT NULL,
	`claimed` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `campus_votes` (
	`user_id` text NOT NULL,
	`week` integer NOT NULL,
	`candidate` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_votes_user_week` ON `campus_votes` (`user_id`,`week`);--> statement-breakpoint
CREATE INDEX `idx_votes_candidate_week` ON `campus_votes` (`candidate`,`week`);