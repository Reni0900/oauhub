CREATE TABLE `messages` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`name` text NOT NULL,
	`body` text NOT NULL,
	`x` real NOT NULL,
	`z` real NOT NULL,
	`created` integer NOT NULL
);

--> statement-breakpoint
CREATE INDEX `idx_messages_created` ON `messages` (`created`);
--> statement-breakpoint
CREATE TABLE `students` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`hostel` text NOT NULL,
	`faculty` text NOT NULL,
	`color` text NOT NULL,
	`x` real DEFAULT 0 NOT NULL,
	`z` real DEFAULT 0 NOT NULL,
	`money` integer DEFAULT 5000 NOT NULL,
	`energy` integer DEFAULT 80 NOT NULL,
	`hunger` integer DEFAULT 75 NOT NULL,
	`study` integer DEFAULT 0 NOT NULL,
	`last_seen` integer DEFAULT 0 NOT NULL,
	`last_action` integer DEFAULT 0 NOT NULL,
	`last_chat` integer DEFAULT 0 NOT NULL
);

--> statement-breakpoint
CREATE INDEX `idx_students_last_seen` ON `students` (`last_seen`);