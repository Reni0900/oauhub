CREATE TABLE `account_origins` (
	`account_id` text PRIMARY KEY NOT NULL,
	`background` text NOT NULL,
	`gender` text NOT NULL,
	`starting_money` integer NOT NULL,
	`hostel` text NOT NULL,
	`created` integer NOT NULL,
	FOREIGN KEY (`account_id`) REFERENCES `accounts`(`id`) ON UPDATE no action ON DELETE cascade
);
