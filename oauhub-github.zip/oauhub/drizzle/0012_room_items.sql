CREATE TABLE room_items (
 user_id TEXT NOT NULL REFERENCES students(id),
 item TEXT NOT NULL,
 hostel TEXT NOT NULL,
 block TEXT NOT NULL,
 room INTEGER NOT NULL,
 x REAL NOT NULL,
 z REAL NOT NULL,
 rotation INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(user_id,item)
);
CREATE INDEX room_items_location ON room_items(hostel,block,room);
