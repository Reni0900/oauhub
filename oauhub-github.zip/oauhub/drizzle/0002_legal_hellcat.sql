CREATE TABLE `direct_messages` (
	`id` text PRIMARY KEY NOT NULL,
	`sender` text NOT NULL,
	`recipient` text NOT NULL,
	`body` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_dm_sender_created` ON `direct_messages` (`sender`,`created`);--> statement-breakpoint
CREATE INDEX `idx_dm_recipient_created` ON `direct_messages` (`recipient`,`created`);--> statement-breakpoint
CREATE TABLE `room_messages` (
	`id` text PRIMARY KEY NOT NULL,
	`channel` text NOT NULL,
	`user_id` text NOT NULL,
	`name` text NOT NULL,
	`body` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_room_messages_channel_created` ON `room_messages` (`channel`,`created`);--> statement-breakpoint
CREATE TABLE `wallet_entries` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`label` text NOT NULL,
	`amount` integer NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_wallet_user_created` ON `wallet_entries` (`user_id`,`created`);--> statement-breakpoint
ALTER TABLE `students` ADD `block` text DEFAULT 'A' NOT NULL;--> statement-breakpoint
ALTER TABLE `students` ADD `room` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `students` ADD `inside` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `students` ADD `hygiene` integer DEFAULT 70 NOT NULL;--> statement-breakpoint
ALTER TABLE `students` ADD `social` integer DEFAULT 50 NOT NULL;--> statement-breakpoint
ALTER TABLE `students` ADD `action_nonce` text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_students_room` ON `students` (`hostel`,`block`,`room`);