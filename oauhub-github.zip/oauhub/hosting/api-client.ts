const base=__OAUHUB_API_URL__;
declare const __OAUHUB_API_URL__:string;
const key='oauhub-session';
// Cross-site API calls use a tab-scoped token, never a URL or a public repository secret.
export async function campusFetch(path:string,init:RequestInit={}){
 const headers=new Headers(init.headers),token=sessionStorage.getItem(key);
 if(token)headers.set('Authorization',`Bearer ${token}`);
 const response=await fetch(base+path,{...init,headers,credentials:'omit'});
 if(path==='/api/account'&&init.method==='POST'&&response.ok){
  const body=await response.clone().json() as {sessionToken?:string};
  if(body.sessionToken)sessionStorage.setItem(key,body.sessionToken);
  else if(JSON.parse(String(init.body)).op==='logout')sessionStorage.removeItem(key);
 }
 if(response.status===401)sessionStorage.removeItem(key);
 return response;
}

