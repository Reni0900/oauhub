// Cloudflare gateway preserves the existing database and keeps password hashing
// on its current server, rather than duplicating accounts or exceeding Free CPU limits.
const allowedOrigin='https://reni0900.github.io';
const upstream='https://oau-life-campus.reniboyyy.chatgpt.site';
const routes=new Set(['/api/account','/api/game','/api/life']);
export default {async fetch(request:Request){
 const url=new URL(request.url),origin=request.headers.get('Origin');
 if(url.pathname==='/health'&&request.method==='GET')return Response.json({ok:true,service:'OAUHub gateway'},{headers:{'Cache-Control':'no-store'}});
 if(origin!==allowedOrigin)return Response.json({error:'Open OAUHub from its GitHub Pages address.'},{status:403});
 const cors={'Access-Control-Allow-Origin':allowedOrigin,'Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Authorization,Content-Type','Vary':'Origin','Cache-Control':'no-store'};
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
 if(!routes.has(url.pathname)||url.search||!['GET','POST'].includes(request.method))return Response.json({error:'Not found.'},{status:404,headers:cors});
 if(Number(request.headers.get('Content-Length')||0)>4096)return Response.json({error:'Request too large.'},{status:413,headers:cors});
 const bearer=request.headers.get('Authorization')?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
 const headers=new Headers({'Origin':upstream,'Content-Type':'application/json'});
 if(bearer)headers.set('Cookie',`__Host-oau_session=${bearer}`);
 // Preserve trusted Cloudflare client IP for existing login rate limits.
 const ip=request.headers.get('CF-Connecting-IP');if(ip)headers.set('CF-Connecting-IP',ip);
 try{
  const body=request.method==='POST'?await request.text():undefined;
  if(body&&body.length>4096)return Response.json({error:'Request too large.'},{status:413,headers:cors});
  const response=await fetch(upstream+url.pathname,{method:request.method,headers,body,redirect:'manual'});
  if(response.status>=300&&response.status<400)throw new Error('Unexpected upstream redirect');
  const resultHeaders=new Headers(cors);resultHeaders.set('Content-Type','application/json');
  if(url.pathname==='/api/account'&&request.method==='POST'&&response.ok){const sessionToken=response.headers.get('Set-Cookie')?.match(/__Host-oau_session=([a-f0-9]{64});/)?.[1];if(sessionToken){const data=await response.json() as Record<string,unknown>;return Response.json({...data,sessionToken},{status:response.status,headers:resultHeaders});}}
  return new Response(response.body,{status:response.status,headers:resultHeaders});
 }catch{return Response.json({error:'Campus connection interrupted. Please try again.'},{status:503,headers:cors});}
}};


