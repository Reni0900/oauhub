// Source backup retains the existing Sites database binding for backend types.
declare namespace Cloudflare { interface Env { DB: D1Database; } }
