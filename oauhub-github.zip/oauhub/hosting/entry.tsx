import React from 'react';
import {createRoot} from 'react-dom/client';
import Game from '../app/game';
import {campusFetch} from './api-client';
campusFetch('/api/account').then(r=>r.json()).then(d=>createRoot(document.getElementById('root')!).render(<Game signedIn={!!d.signedIn}/>)).catch(()=>{document.getElementById('root')!.textContent='OAUHub could not connect. Please refresh to try again.';});
