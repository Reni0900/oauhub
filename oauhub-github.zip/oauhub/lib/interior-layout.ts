import {apartmentDistricts} from './student-origin';
export const ROOM_SCALE=1.4;
export const ROOM_X=11.3*ROOM_SCALE,ROOM_Z=9.3*ROOM_SCALE;
export type Point={x:number;z:number};
export type Rect=Point&{w:number;d:number};
export type InteriorLayout={kind:'hostel'|'apartment';capacity:number;beds:Point[];walls:Rect[];obstacles:Rect[];spots:Record<string,Point>;zones:(Point&{name:string})[]};
export const isApartment=(id:string)=>apartmentDistricts.some(area=>area===id);
export const roomCapacity=(id:string)=>isApartment(id)?1:4;
export function interiorLayout(apartment:boolean,bedIndex=0,scale=ROOM_SCALE):InteriorLayout{
 const beds=apartment?[{x:-7,z:-6.7}]:[-9,-3,3,9].map(x=>({x,z:-6.7}));
 const walls:Rect[]=apartment?[
  {x:0,z:-7,w:.22,d:6},{x:-7.5,z:-2,w:9,d:.22},{x:2,z:-2,w:4,d:.22},{x:10,z:-2,w:4,d:.22},
  {x:4,z:7,w:.22,d:6},{x:8,z:2,w:8,d:.22}
 ]:[
  ...[-6,0,6].map(x=>({x,z:-5.6,w:.18,d:8.8})),
  {x:-8,z:2,w:8,d:.2},{x:0,z:2,w:2,d:.2},{x:8,z:2,w:8,d:.2},
  {x:-4,z:7,w:.2,d:6},{x:4,z:7,w:.2,d:6}
 ];
 const bed=beds[Math.min(beds.length-1,bedIndex)];
 const spots:Record<string,Point>=apartment?{bed:{x:bed.x+2.3,z:-5},desk:{x:-2.5,z:-5},sofa:{x:-7,z:5},kitchen:{x:6,z:-6.5},shower:{x:9,z:5},laundry:{x:6,z:7},food:{x:0,z:6}}:{bed:{x:bed.x,z:-3.6},desk:{x:bed.x+1.7,z:-1.1},sofa:{x:-8,z:5},kitchen:{x:0,z:7},shower:{x:9,z:5},laundry:{x:6,z:7},food:{x:-6,z:7}};
 const obstacles:Rect[]=[...walls,...beds.map(b=>({...b,w:2.8,d:4.6})),
  ...beds.map(b=>({x:b.x+1.9,z:-9.15,w:1.3,d:1})),
  {x:apartment?-7:-8,z:.6,w:4.2,d:1},
  ...(apartment?[{x:-2.5,z:-6.8,w:2.2,d:1.3},{x:6,z:-8.8,w:10,d:1.6},{x:10.7,z:-5.5,w:1.6,d:2}]:beds.map(b=>({x:b.x+1.7,z:-2.8,w:1.8,d:1.1}))),
  {x:apartment?-9.8:-10,z:6,w:1.8,d:5},{x:apartment?-6:-7.8,z:7.8,w:4,d:1.6},
  {x:apartment?-6:-8,z:6,w:2.3,d:1.2},
  ...(apartment?[{x:6,z:-5,w:2.5,d:1.6}]:[{x:0,z:8.8,w:6,d:1.6},{x:2.9,z:7,w:1.4,d:2}]),
  {x:10.4,z:7.7,w:2,d:2.4},{x:6,z:8.7,w:1.6,d:1.6}
 ];
 const raw:InteriorLayout={kind:apartment?'apartment':'hostel',capacity:apartment?1:4,beds,walls,obstacles,spots,zones:apartment?[{x:-7,z:-9,name:'BEDROOM'},{x:6,z:-9,name:'KITCHEN'},{x:-5,z:0,name:'LIVING ROOM'},{x:8,z:3,name:'BATHROOM'}]:[{x:0,z:-9,name:'FOUR STUDENTS · FOUR BED SPACES'},{x:-8,z:3,name:'COMMON AREA'},{x:0,z:3,name:'SHARED KITCHEN'},{x:8,z:3,name:'BATHROOM'}]};
 const point=(p:Point)=>({...p,x:p.x*scale,z:p.z*scale});const rect=(r:Rect)=>({...point(r),w:r.w*scale,d:r.d*scale});return {...raw,beds:raw.beds.map(point),walls:raw.walls.map(rect),obstacles:raw.obstacles.map(rect),spots:Object.fromEntries(Object.entries(raw.spots).map(([id,p])=>[id,point(p)])),zones:raw.zones.map(z=>({...point(z),name:z.name}))};
}
export function canStand(point:Point,layout:InteriorLayout){
 return Math.abs(point.x)<=ROOM_X&&Math.abs(point.z)<=ROOM_Z&&!layout.obstacles.some(o=>Math.abs(point.x-o.x)<o.w/2+.32&&Math.abs(point.z-o.z)<o.d/2+.32);
}
// Grid routing keeps avatar movement inside doorways and around beds/counters.
export function interiorPath(from:Point,to:Point,layout:InteriorLayout):Point[]{
 const step=.5,key=(x:number,z:number)=>`${x},${z}`;
 const cells=new Map<string,Point>();for(let x=-Math.floor(ROOM_X/step);x<=Math.floor(ROOM_X/step);x++)for(let z=-Math.floor(ROOM_Z/step);z<=Math.floor(ROOM_Z/step);z++){const p={x:x*step,z:z*step};if(canStand(p,layout))cells.set(key(x,z),p);}
 const nearest=(p:Point)=>[...cells.entries()].reduce((best,current)=>(current[1].x-p.x)**2+(current[1].z-p.z)**2<(best[1].x-p.x)**2+(best[1].z-p.z)**2?current:best);
 const [start]=nearest(from),[end]=nearest(to),queue=[start],previous=new Map<string,string|null>([[start,null]]);
 for(let i=0;i<queue.length&&!previous.has(end);i++){const id=queue[i],[x,z]=id.split(',').map(Number);for(const [dx,dz]of [[1,0],[-1,0],[0,1],[0,-1]]){const next=key(x+dx,z+dz);if(cells.has(next)&&!previous.has(next)){previous.set(next,id);queue.push(next);}}}
 if(!previous.has(end))return [];
 const result:Point[]=[];let current:string|null=end;while(current&&current!==start){result.unshift(cells.get(current)!);current=previous.get(current)??null;}return result;
}
