export const blocks=['A','B','C','D'];
export const roomNumbers=Array.from({length:12},(_,i)=>101+i);
export const meals=[{id:'rice',name:'Jollof rice',price:500,hunger:35},{id:'amala',name:'Amala & ewedu',price:700,hunger:45},{id:'bread',name:'Bread & egg',price:350,hunger:25}];
export const activities=[{id:'shower',name:'Take a shower',hint:'+35 hygiene',spot:'shower'},{id:'sleep',name:'Get some sleep',hint:'+30 energy',spot:'bed'},{id:'study',name:'Study at your desk',hint:'+8 study · −10 energy',spot:'desk'},{id:'gist',name:'Gist with roommates',hint:'+15 social',spot:'sofa'},{id:'laundry',name:'Wash your clothes',hint:'+15 hygiene · −5 energy',spot:'laundry'},{id:'football',name:'Play football',hint:'+12 social · −12 energy',spot:'football'}];
export type Resident={id:string;name:string;color:string;appearance?:string;block:string;room:number;last_seen:number;inside:string;visitor?:number};
export type DirectMessage={id:string;sender:string;recipient:string;body:string;created:number;sender_name:string;recipient_name:string};
import type {CampusState} from './campus-life';
import type {HousingState} from './housing';
export type PhoneContact={username?:string;id:string;name:string;color:string;appearance?:string;hostel:string;last_seen:number};
export type PhoneState={username?:string;blocked?:{target_id:string;name:string;username?:string}[];groups:{id:string;name:string;owner_id:string;created:number;members:number;unread:number}[];messages:{id:string;group_id:string;sender:string;sender_name:string;body:string;created:number}[];reads:Record<string,number>};
export type LifeState={phone?:PhoneState;visit?:HomeVisit|null;invites?:HomeInvite[];housing?:HousingState;campus:CampusState;residents:Resident[];roomMessages:{id:string;user_id:string;name:string;body:string;created:number}[];contacts:PhoneContact[];directMessages:DirectMessage[];wallet:{id:string;label:string;amount:number;created:number}[]};


export type HomeVisit={id:string;host_id:string;host_name:string;hostel:string;block:string;room:number;expires_at:number};
export type HomeInvite={id:string;host_id:string;guest_id:string;host_name:string;guest_name:string;hostel:string;block:string;room:number;status:string;created:number;expires_at:number;visit_until?:number};
