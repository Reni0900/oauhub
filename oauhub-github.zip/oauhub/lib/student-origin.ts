export type StudentGender='female'|'male';
export type StudentOrigin={background:'nepo'|'lapo';gender:StudentGender;startingMoney:number;hostel:string};
export const schoolHostels=['awo','fajuyi','angola','etf','moremi','moza','akintola','alumni'] as const;
export function allocateOrigin(gender:StudentGender,roll:()=>number=()=>crypto.getRandomValues(new Uint32Array(1))[0]/4294967296):StudentOrigin{
 const background=roll()<.5?'nepo':'lapo';
 const privatePlacement=roll()<(background==='nepo'?.8:.2);
 const pool=privatePlacement?(gender==='female'?['ojaja','oakhouse','maintenance']:['ojaja','oakhouse']):schoolHostels;
 return {background,gender,startingMoney:background==='nepo'?500000:150000,hostel:pool[Math.floor(roll()*pool.length)]};
}
