export type StudentGender='female'|'male';
export type StudentOrigin={background:'nepo'|'lapo';gender:StudentGender;startingMoney:number;hostel:string};
export const maleSchoolHostels=['awo','fajuyi','angola','etf'] as const;
export const femaleSchoolHostels=['moremi','moza','akintola','alumni'] as const;
export const schoolHostels=[...maleSchoolHostels,...femaleSchoolHostels] as const;
export const privateHostels=['ojaja','oakhouse'] as const;
export const apartmentDistricts=['damico','ooni-layout','asherifa','mayfair','oduduwa-area'] as const;
export function allocateOrigin(gender:StudentGender,roll:()=>number=()=>crypto.getRandomValues(new Uint32Array(1))[0]/4294967296):StudentOrigin{
 const background=roll()<.5?'nepo':'lapo';
 const placement=roll(),schoolChance=background==='nepo'?.2:.6,privateEnd=background==='nepo'?.6:.8;
 const pool=placement<schoolChance?(gender==='female'?femaleSchoolHostels:maleSchoolHostels):placement<privateEnd?privateHostels:(gender==='female'?[...apartmentDistricts,'maintenance']:apartmentDistricts);
 return {background,gender,startingMoney:background==='nepo'?500000:150000,hostel:pool[Math.floor(roll()*pool.length)]};
}
