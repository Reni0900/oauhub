export const appearanceOptions = {
 skin:['#593927','#795039','#9a6245','#bc865e','#d9a779','#f1c9a5'],
 face:['round','oval','angular'], body:['slim','regular','broad'], height:['short','regular','tall'],
 hair:['short','afro','braids','bun','shaved'], hairColor:['#292323','#563622','#9c683b','#ded0b4'],
 top:['tee','hoodie','shirt','dress'], bottoms:['jeans','shorts','skirt'], bottomColor:['#33435c','#22232a','#a08464','#ebe3d3'],
 shoes:['sneakers','slides','boots'], shoeColor:['#f2eddf','#24242a','#9a6245','#c35490'], accessory:['none','glasses','cap']
} as const;
export type Appearance = {[K in keyof typeof appearanceOptions]:string};
export const defaultAppearance:Appearance={skin:'#9a6245',face:'round',body:'regular',height:'regular',hair:'short',hairColor:'#292323',top:'tee',bottoms:'jeans',bottomColor:'#33435c',shoes:'sneakers',shoeColor:'#f2eddf',accessory:'none'};
export function validateAppearance(value:unknown):Appearance|null{
 if(value===undefined)return {...defaultAppearance};
 if(!value||typeof value!=='object'||Array.isArray(value))return null;
 const result={...defaultAppearance};
 for(const [key,v] of Object.entries(value)){if(!Object.hasOwn(appearanceOptions,key)||typeof v!=='string'||!(appearanceOptions[key as keyof Appearance] as readonly string[]).includes(v))return null;result[key as keyof Appearance]=v;}
 return result;
}
export function readAppearance(value?:string|Appearance):Appearance{
 try{return validateAppearance(typeof value==='string'?JSON.parse(value):value)||{...defaultAppearance};}catch{return {...defaultAppearance};}
}
