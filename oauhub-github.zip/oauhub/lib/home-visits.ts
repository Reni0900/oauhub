import {authDb} from './account-auth';
import {readOrigin} from './account-origin';
import {hostels,arrival,Student} from './campus';
import type {HomeVisit} from './hostel-life';
const json=(body:unknown,status=200)=>Response.json(body,{status});
const read=(id:string)=>authDb().prepare('SELECT * FROM students WHERE id=?').bind(id).first<Student>();
export const homeChannel=(s:{hostel:string;block:string;room:number})=>`${s.hostel}:${s.block}:${s.room}`;
export async function currentVisit(me:Student,now=Date.now()){
 return authDb().prepare(`SELECT v.id,v.host_id,v.hostel,v.block,v.room,v.expires_at,s.name AS host_name FROM home_visits v JOIN students s ON s.id=v.host_id LEFT JOIN housing_leases l ON l.user_id=s.id WHERE v.guest_id=? AND v.expires_at>? AND v.hostel=? AND s.hostel=v.hostel AND s.block=v.block AND s.room=v.room AND (l.paid_until IS NULL OR l.paid_until>?)`).bind(me.id,now,me.inside,now).first<HomeVisit>();
}
export async function homeInvitations(me:Student){
 const result=await authDb().prepare(`SELECT i.*,s.name AS host_name,g.name AS guest_name,COALESCE(v.expires_at,0) AS visit_until FROM home_invites i LEFT JOIN home_visits v ON v.id=i.id JOIN students s ON s.id=i.host_id JOIN students g ON g.id=i.guest_id WHERE i.host_id=? OR i.guest_id=? ORDER BY i.created DESC LIMIT 60`).bind(me.id,me.id).all();return result.results;
}
export async function visitAction(b:{op?:string;recipient?:unknown;invite?:unknown},me:Student,now:number){
 const db=authDb();if(!b.op?.startsWith('visit-'))return null;
 if(b.op==='visit-leave'){
  const p=arrival(hostels.find(h=>h.id===me.inside)||hostels.find(h=>h.id===me.hostel)!);
  await db.batch([db.prepare('DELETE FROM home_visits WHERE guest_id=?').bind(me.id),db.prepare("UPDATE students SET inside='',x=?,z=?,last_seen=? WHERE id=?").bind(p.x,p.z,now,me.id)]);return json({me:await read(me.id),notice:'You left the visit. Your own home is unchanged.'});
 }
 if(b.op==='visit-invite'){
  if(typeof b.recipient!=='string'||b.recipient===me.id||!await read(b.recipient))return json({error:'Choose another student to invite.'},400);
  if(!me.room)return json({error:'Choose your own room or apartment before inviting a friend.'},400);
  const lease=await db.prepare('SELECT paid_until FROM housing_leases WHERE user_id=?').bind(me.id).first<{paid_until:number}>();if(lease&&lease.paid_until<=now)return json({error:'Renew your housing semester before inviting friends.'},402);
  if(me.hostel==='maintenance'&&(await readOrigin(b.recipient))?.gender!=='female')return json({error:'Maintenance visits are for female students only.'},403);
  const recent=await db.prepare('SELECT id FROM home_invites WHERE host_id=? AND guest_id=? AND created>?').bind(me.id,b.recipient,now-30000).first();if(recent)return json({error:'An invitation was just sent. Give your friend a moment.'},429);
  const id=crypto.randomUUID();await db.batch([
   db.prepare("UPDATE home_invites SET status='cancelled' WHERE host_id=? AND guest_id=? AND status='pending'").bind(me.id,b.recipient),
   db.prepare("INSERT INTO home_invites (id,host_id,guest_id,hostel,block,room,status,created,expires_at) VALUES (?,?,?,?,?,?,'pending',?,?)").bind(id,me.id,b.recipient,me.hostel,me.block,me.room,now,now+1800000),
   db.prepare('DELETE FROM home_visits WHERE guest_id=?').bind(me.id),
   db.prepare('UPDATE students SET inside=hostel,last_seen=? WHERE id=?').bind(now,me.id)
  ]);return json({me:await read(me.id),notice:'Invitation sent in Messages. You are home and ready for your visitor.'});
 }
 if(typeof b.invite!=='string')return json({error:'Choose an invitation.'},400);
 const invitation=await db.prepare('SELECT * FROM home_invites WHERE id=?').bind(b.invite).first<{id:string;host_id:string;guest_id:string;hostel:string;block:string;room:number;status:string;expires_at:number}>();
 if(!invitation||![invitation.host_id,invitation.guest_id].includes(me.id))return json({error:'Invitation not found.'},404);
 if(b.op==='visit-cancel'||b.op==='visit-decline'){
  if((b.op==='visit-cancel'&&me.id!==invitation.host_id)||(b.op==='visit-decline'&&me.id!==invitation.guest_id))return json({error:'This invitation is not yours to change.'},403);
  await db.batch([db.prepare("UPDATE home_invites SET status=? WHERE id=? AND status IN ('pending','accepted')").bind(b.op==='visit-cancel'?'cancelled':'declined',invitation.id),db.prepare('DELETE FROM home_visits WHERE id=?').bind(invitation.id)]);return json({ok:true,notice:b.op==='visit-cancel'?'Invitation or visit ended.':'Invitation declined.'});
 }
 if(b.op!=='visit-accept')return json({error:'Unknown visit action.'},400);
 if(me.id!==invitation.guest_id)return json({error:'Only the invited student can accept.'},403);
 if(invitation.status!=='pending'||invitation.expires_at<=now)return json({error:'This invitation is no longer available. Ask for a new one.'},409);
 const host=await read(invitation.host_id);
 if(!host||host.hostel!==invitation.hostel||host.block!==invitation.block||host.room!==invitation.room)return json({error:'Your friend changed homes. Ask for a new invitation.'},409);
 if(host.inside!==host.hostel)return json({error:'Your friend is away. Ask them to return home first.'},409);
 const lease=await db.prepare('SELECT paid_until FROM housing_leases WHERE user_id=?').bind(host.id).first<{paid_until:number}>();if(lease&&lease.paid_until<=now)return json({error:'Your friend needs to renew their housing semester first.'},402);
 if(host.hostel==='maintenance'&&(await readOrigin(me.id))?.gender!=='female')return json({error:'Maintenance visits are for female students only.'},403);
 const count=await db.prepare('SELECT COUNT(*) AS total FROM home_visits WHERE hostel=? AND block=? AND room=? AND expires_at>? AND guest_id!=?').bind(host.hostel,host.block,host.room,now,me.id).first<{total:number}>();if((count?.total??0)>=4)return json({error:'This home already has four visitors. Try again when someone leaves.'},409);
 // A conditional claim prevents a cancelled, expired or replayed invite from creating a visit.
 const claim=crypto.randomUUID();const result=await db.batch([
  db.prepare(`UPDATE home_invites SET status='accepted',acceptance_nonce=? WHERE id=? AND guest_id=? AND status='pending' AND expires_at>? AND EXISTS (SELECT 1 FROM students s LEFT JOIN housing_leases l ON l.user_id=s.id WHERE s.id=home_invites.host_id AND s.hostel=home_invites.hostel AND s.block=home_invites.block AND s.room=home_invites.room AND s.inside=s.hostel AND (l.paid_until IS NULL OR l.paid_until>?)) AND (SELECT COUNT(*) FROM home_visits v WHERE v.hostel=home_invites.hostel AND v.block=home_invites.block AND v.room=home_invites.room AND v.expires_at>? AND v.guest_id!=?)<4`).bind(claim,invitation.id,me.id,now,now,now,me.id),
  db.prepare(`INSERT INTO home_visits (guest_id,id,host_id,hostel,block,room,expires_at) SELECT guest_id,id,host_id,hostel,block,room,? FROM home_invites WHERE id=? AND guest_id=? AND status='accepted' AND acceptance_nonce=? ON CONFLICT(guest_id) DO UPDATE SET id=excluded.id,host_id=excluded.host_id,hostel=excluded.hostel,block=excluded.block,room=excluded.room,expires_at=excluded.expires_at`).bind(now+3600000,invitation.id,me.id,claim),
  db.prepare('UPDATE students SET inside=?,last_seen=? WHERE id=? AND EXISTS (SELECT 1 FROM home_visits WHERE guest_id=? AND id=?)').bind(host.hostel,now,me.id,me.id,invitation.id)
 ]);if(!result[0].meta.changes)return json({error:'This invitation has already been used or ended.'},409);
 return json({me:await read(me.id),notice:`You are visiting ${host.name} in ${host.block}${host.room}. Your own home is unchanged.`});
}
