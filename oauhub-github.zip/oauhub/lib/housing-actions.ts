import {authDb} from './account-auth';
import {readOrigin} from './account-origin';
import {arrival,hostels,Student} from './campus';
import {HousingLease,housingOptions,housingQuote,semesterDurationMs,maintenanceTiers} from './housing';
export async function housingState(userId:string){
 const origin=await readOrigin(userId);
 const lease=await authDb().prepare('SELECT hostel,paid_until,fee FROM housing_leases WHERE user_id=?').bind(userId).first<HousingLease>();
 return {options:housingOptions(origin?.gender??null),lease,semesterDurationMs};
}
export async function housingAction(body:{op?:string;hostel?:unknown;housingTier?:unknown},me:Student,now:number){
 if(body.op!=='housing-move'&&body.op!=='housing-renew')return null;
 const renew=body.op==='housing-renew',destination=renew?me.hostel:body.hostel;
 if(typeof destination!=='string')return Response.json({error:'Choose a home.'},{status:400});
 if(!renew&&destination===me.hostel)return Response.json({error:'You already live here. Use Renew for your next semester.'},{status:409});
 const db=authDb(),state=await housingState(me.id),origin=await readOrigin(me.id);
 const tier=renew&&state.lease?Object.entries(maintenanceTiers).find(([,fee])=>fee===state.lease!.fee)?.[0]??'basic':body.housingTier??'basic';
 const quote=housingQuote(destination,origin?.gender??null,me.money,tier);
 if('error' in quote)return Response.json({error:quote.error},{status:quote.status});
 if(renew&&state.lease&&state.lease.paid_until>now)return Response.json({error:'This semester is already paid. Renew when it ends.'},{status:409});
 const place=hostels.find(h=>h.id===destination)!,point=arrival(place),nonce=crypto.randomUUID(),paidUntil=now+quote.duration;
 const results=await db.batch([
  db.prepare("UPDATE students SET money=money-?,hostel=?,block=CASE WHEN ? THEN block ELSE 'A' END,room=CASE WHEN ? THEN room ELSE 0 END,inside=CASE WHEN ? THEN inside ELSE '' END,x=CASE WHEN ? THEN x ELSE ? END,z=CASE WHEN ? THEN z ELSE ? END,last_seen=?,action_nonce=? WHERE id=? AND hostel=? AND money>=? AND NOT EXISTS (SELECT 1 FROM housing_leases WHERE user_id=? AND ? AND paid_until>?)").bind(quote.fee,destination,Number(renew),Number(renew),Number(renew),Number(renew),point.x,Number(renew),point.z,now,nonce,me.id,me.hostel,quote.fee,me.id,Number(renew),now),
  db.prepare('INSERT INTO housing_leases (user_id,hostel,paid_until,fee) SELECT id,?,?,? FROM students WHERE id=? AND action_nonce=? ON CONFLICT(user_id) DO UPDATE SET hostel=excluded.hostel,paid_until=excluded.paid_until,fee=excluded.fee').bind(destination,paidUntil,quote.fee,me.id,nonce),
  db.prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,`${renew?'Housing renewal':'Moved to'} · ${quote.option.name} · semester fee`,-quote.fee,now,me.id,nonce)
 ]);
 if(!results[0].meta.changes)return Response.json({error:'Your housing or balance changed. Refresh and try again.'},{status:409});
 const updated=await db.prepare('SELECT * FROM students WHERE id=?').bind(me.id).first<Student>();
 return Response.json({me:updated,notice:`${renew?'Renewed':'Moved into'} ${quote.option.name}. ₦${quote.fee.toLocaleString()} paid for one semester.`});
}

