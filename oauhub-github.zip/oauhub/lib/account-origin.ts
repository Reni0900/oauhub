import {authDb} from './account-auth';
import type {StudentOrigin} from './student-origin';
export const readOrigin=(accountId:string)=>authDb().prepare('SELECT background,gender,starting_money AS startingMoney,hostel FROM account_origins WHERE account_id=?').bind(accountId).first<StudentOrigin>();
