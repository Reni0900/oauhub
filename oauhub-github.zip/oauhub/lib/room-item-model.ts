import * as THREE from 'three';
import {roomProducts} from './commerce';
import type {RoomItem} from './room-decor';
export function addRoomItem(scene:THREE.Scene,item:Pick<RoomItem,'item'|'x'|'z'|'rotation'>,ghost=false){
 const p=roomProducts.find(p=>p.id===item.item);if(!p)return;
 const group=new THREE.Group();group.position.set(item.x,0,item.z);group.rotation.y=item.rotation*Math.PI/2;scene.add(group);
 const mat=(color:string)=>new THREE.MeshStandardMaterial({color,roughness:.7,transparent:ghost,opacity:ghost?.55:1});
 function box(w:number,h:number,d:number,x=0,y=h/2,z=0,c=p!.tone){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(c));m.position.set(x,y,z);m.castShadow=!ghost;m.receiveShadow=true;group.add(m);return m;}
 function round(r:number,h:number,x=0,y=h/2,z=0,c=p!.tone){const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,20),mat(c));m.position.set(x,y,z);m.castShadow=!ghost;group.add(m);return m;}
 const art=p.art;
 if(art==='rug'){box(1.15,.025,1.15,0,.04,0);box(.9,.03,.9,0,.065,0,'#eedda7');}
 else if(art==='plant'){round(.22,.4);for(const x of [-.18,0,.18]){const m=new THREE.Mesh(new THREE.SphereGeometry(.25,10,8),mat('#458662'));m.scale.set(.6,1.7,.7);m.position.set(x,.75+Math.abs(x),0);group.add(m);}}
 else if(art==='lamp'){round(.3,.08);round(.045,1,0,.5);round(.32,.35,0,1.1,0,'#f4d589');}
 else if(art==='poster'||art==='mirror'){box(.8,1.25,.08,0,.8);box(.66,1.1,.09,0,.8,.02,art==='mirror'?'#a7cfd0':'#e6bc79');box(.1,.55,.4,0,.3);}
 else if(art==='fan'){box(.55,.08,.4);box(.08,.7,.08,0,.4);const m=round(.42,.12,0,.9);m.rotation.x=Math.PI/2;box(.62,.05,.14,0,.9,.09,'#d7e8e0');box(.05,.62,.14,0,.9,.09,'#d7e8e0');}
 else if(art==='headphones'){box(.16,.55,.35,-.25,.4);box(.16,.55,.35,.25,.4);box(.65,.13,.16,0,.7);}
 else if(art==='speaker'||art==='powerbank'||art==='extension'||art==='calculator'){box(.55,art==='speaker'?.7:.12,.4);box(.38,.04,.26,0,art==='speaker'?.6:.15,0,'#283b43');}
 else if(art==='book'){for(let i=0;i<3;i++)box(.7,.1,.5,0,.1+i*.1,0,['#658cad','#b47860','#dcc28e'][i]);}
 else if(art==='bag'){box(.6,.8,.3);box(.35,.12,.1,0,.87);box(.48,.28,.12,0,.35,.2,'#ddd2b4');}
 else if(art==='bottle'||art==='mug'){round(art==='bottle'?.16:.25,art==='bottle'?.7:.35);round(.13,.08,0,art==='bottle'?.74:.37,0,'#f4ede0');}
 else if(art==='bucket'||art==='basket'||art==='storage'){box(.85,.6,.7);box(.7,.04,.55,0,.62,0,'#e9dfc7');}
 else if(art==='bedsheet'||art==='pillow'){box(.9,art==='pillow'?.25:.12,.6,0,.18);box(.75,.04,.48,0,art==='pillow'?.33:.26,0,'#ece4d5');}
 else if(art==='kettle'||art==='pot'){round(.35,.5);round(.38,.06,0,.53,0,'#e5dfcf');box(.2,.12,.15,.4,.35);}
 else if(art==='plate'){round(.4,.06);box(.05,.04,.7,.5,.08);}
 else box(.7,.6,.6);
 if(ghost){const edges=new THREE.BoxHelper(group,0x42bb89);scene.add(edges);}
 return group;
}
