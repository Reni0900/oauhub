export const locations = [
 {id:'library',name:'Hezekiah Oluwasanmi Library',short:'The Library',x:0,z:-19,w:13,d:8,color:'#eee2be',type:'academic',action:'Study',description:'Find a quiet corner and build your study points.'},
 {id:'amphi',name:'Amphitheatre',short:'Amphitheatre',x:20,z:-12,w:11,d:9,color:'#e6bc82',type:'social',action:'Hang out',description:'Take a break and meet other Great Ife students.'},
 {id:'sports',name:'Sports Centre',short:'Sports Centre',x:25,z:16,w:12,d:12,color:'#bbdba9',type:'social',action:'Exercise',description:'Stretch your legs and recharge between classes.'},
 {id:'awo',name:'Awo Hall',short:'Awo Hall',x:-27,z:-22,w:9,d:6,color:'#efbb77',type:'hostel',action:'Rest',description:'Your hostel is the place to recover your energy.'},
 {id:'fajuyi',name:'Faj Hall',short:'Faj Hall',x:-27,z:-8,w:9,d:6,color:'#dda182',type:'hostel',action:'Rest',description:'Drop by the hall and catch up with students nearby.'},
 {id:'angola',name:'Angola Hall',short:'Angola Hall',x:-27,z:6,w:9,d:6,color:'#e4c993',type:'hostel',action:'Rest',description:'A place to recharge after a busy campus day.'},
 {id:'etf',name:'Education Tax Fund Hall',short:'ETF Hall',x:-27,z:20,w:9,d:6,color:'#a2c5c3',type:'hostel',action:'Rest',description:'Get some rest before the next lecture.'},
 {id:'moremi',name:'Moremi Hall',short:'Moremi Hall',x:44,z:-22,w:9,d:6,color:'#e7aca9',type:'hostel',action:'Rest',description:'Make time for hostel life as well as lectures.'},
 {id:'moza',name:'Mozambique Hall',short:'Mozambique Hall',x:44,z:-8,w:9,d:6,color:'#c9b8dd',type:'hostel',action:'Rest',description:'Meet neighbours and recover your energy.'},
 {id:'akintola',name:'Akintola Hall',short:'Akintola Hall',x:44,z:6,w:9,d:6,color:'#f1ca96',type:'hostel',action:'Rest',description:'Take a little time out from campus life.'},
 {id:'alumni',name:'Alumni Hall',short:'Alumni Hall',x:44,z:20,w:9,d:6,color:'#a8cbac',type:'hostel',action:'Rest',description:'A home base for your campus story.'},
 {id:'ojaja',name:'Ojaja Private Hostel',short:'Ojaja',x:-12,z:12,w:8,d:6,color:'#d4b477',type:'hostel',action:'Rest',description:'Private hostel living, with room blocks, neighbours and everyday student life.'},
 {id:'oakhouse',name:'Oakhouse Private Hostel',short:'Oakhouse',x:-12,z:26,w:8,d:6,color:'#a8c4b7',type:'hostel',action:'Rest',description:'A private hostel with space to settle in, recharge and meet your roommates.'},
 {id:'maintenance',name:'Maintenance Female Hostel',short:'Maintenance',x:32,z:-33,w:8,d:6,color:'#c6b3d9',type:'hostel',action:'Rest',description:'An off-campus hostel for female students. Explore its blocks, rooms and shared activities.'},
 {id:'lecture',name:'Lecture Theatre',short:'Lecture Theatre',x:0,z:2,w:11,d:7,color:'#c0cbd7',type:'academic',action:'Attend lecture',description:'Show up, take notes, and keep your studies moving.'},
 {id:'food',name:'Campus food spot',short:'Food spot',x:0,z:23,w:8,d:5,color:'#f3a57f',type:'food',action:'Buy a meal · ₦500',description:'Grab a meal before heading back into campus.'},
 {id:'oduduwa',name:'Oduduwa Hall',short:'Oduduwa Hall',x:14,z:-26,w:8,d:5,color:'#dcb48c',type:'social',action:'Campus events',description:'Join a debate, attend a game event and meet other students.'},
 {id:'union',name:'Student union hub',short:'Student union',x:14,z:3,w:7,d:5,color:'#c5b7e5',type:'social',action:'Elections',description:'Campaign, vote and choose this week’s game campus policy.'},
 {id:'market',name:'Campus shopping arcade',short:'Shopping arcade',x:14,z:24,w:7,d:5,color:'#ecc882',type:'social',action:'Shop for your room',description:'Spend your game allowance on furnishings that appear in your room.'},
 {id:'health',name:'OAU Health Centre',short:'Health Centre',x:-42,z:-20,w:7,d:6,color:'#d0e3e0',type:'social',action:'Health visit',description:'Recharge your avatar’s energy and hygiene with a game clinic visit.'},
 {id:'chapel',name:'All Souls’ Chapel',short:'All Souls’ Chapel',x:-42,z:1,w:6,d:5,color:'#e7dbc0',type:'social',action:'Quiet moment',description:'A quiet campus space for your avatar to pause and recharge.'},
 {id:'wellbeing',name:'Campus wellbeing corner',short:'Wellbeing',x:-42,z:21,w:6,d:5,color:'#adcfc7',type:'social',action:'Take a break',description:'Make room for a calm moment between lectures and hostel life.'},
 {id:'shuttle',name:'Campus shuttle stop',short:'Campus shuttle',x:54,z:34,w:5,d:4,color:'#e2bf55',type:'social',action:'Take a shuttle',description:'Choose a stop and travel across campus with game money.'},
 {id:'radio',name:'Ife Mobile radio lounge',short:'Radio lounge',x:54,z:-33,w:5,d:4,color:'#c2c9dd',type:'social',action:'Open radio',description:'Campus notices, a local beat loop and the latest student posts.'},
 {id:'salon',name:'Campus style studio',short:'Style studio',x:-6,z:-33,w:6,d:4,color:'#e4a8c7',type:'social',action:'Change your look',description:'Choose an outfit colour and make your avatar your own.'},
 {id:'jobs',name:'Student jobs desk',short:'Jobs desk',x:-42,z:-33,w:6,d:4,color:'#acc8de',type:'social',action:'Find a job',description:'Complete a timed student shift and earn more game allowance.'},
 {id:'club',name:'Student common room',short:'Common room',x:29,z:34,w:6,d:4,color:'#b3c99b',type:'social',action:'Campus board',description:'Post plans, find people to play with and arrange a campus meetup.'}
] as const;
export const hostels = locations.filter(l=>l.type==='hostel');
export const colors = ['#7159e8','#e66f46','#278b91','#c35490','#3d71c7','#a77b31'];
export type Student = {id:string;name:string;hostel:string;faculty:string;color:string;appearance?:string;x:number;z:number;money:number;energy:number;hunger:number;study:number;last_seen?:number;block:string;room:number;inside:string;hygiene:number;social:number};
export type Message = {id:string;name:string;body:string;x:number;z:number;created:number};
export function arrival(l:{x:number;z:number;d:number}) {return {x:l.x,z:l.z+l.d/2+3};}
