import {authDb} from './account-auth';
export const cleanUsername=(value:unknown)=>typeof value==='string'?value.trim().replace(/^@/,'').toLowerCase():'';
export const validUsername=(username:string)=>/^[a-z][a-z0-9_]{2,23}$/.test(username)&&!username.startsWith('ife_');
export const readIdentity=(id:string)=>authDb().prepare('SELECT username,display_name FROM account_identities WHERE account_id=?').bind(id).first<{username:string;display_name:string}>();
