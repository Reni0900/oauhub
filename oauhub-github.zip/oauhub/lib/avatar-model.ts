import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import {Appearance,readAppearance} from './appearance';

// Shared by the wardrobe, campus, rooms and activities.
export function createAvatar(color:string,appearance?:string|Appearance){
 const a=readAppearance(appearance),avatar=new THREE.Group();
 const material=(c:string,roughness=.75)=>new THREE.MeshStandardMaterial({color:c,roughness});
 const skin=material(a.skin,.65),shirt=material(color),pants=material(a.bottomColor),hair=material(a.hairColor,.9),shoe=material(a.shoeColor,.55),sole=material('#eeeadd'),ink=material('#24242e'),white=material('#fffaf0'),lip=material(new THREE.Color(a.skin).multiplyScalar(.55).getStyle());
 const seam=material(new THREE.Color(color).multiplyScalar(.72).getStyle()),hairLight=material(new THREE.Color(a.hairColor).multiplyScalar(1.22).getStyle());
 function mesh(geometry:THREE.BufferGeometry,mat:THREE.Material,x:number,y:number,z:number,parent:THREE.Object3D=avatar){const m=new THREE.Mesh(geometry,mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
 function sphere(w:number,h:number,d:number,mat:THREE.Material,x:number,y:number,z:number,parent:THREE.Object3D=avatar){const m=mesh(new THREE.SphereGeometry(1,16,12),mat,x,y,z,parent);m.scale.set(w,h,d);return m;}
 function rounded(w:number,h:number,d:number,mat:THREE.Material,x:number,y:number,z:number,parent:THREE.Object3D=avatar){return mesh(new RoundedBoxGeometry(w,h,d,2,Math.min(w,h,d)*.24),mat,x,y,z,parent);}
 function curve(points:number[][],radius:number,mat:THREE.Material){return mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p as [number,number,number]))),12,radius,5,false),mat,0,0,0);}

 const torso=mesh(new THREE.CylinderGeometry(.36,.29,.88,16),shirt,0,1.65,0);torso.scale.z=.72;
 sphere(.39,.17,.275,shirt,0,2.03,0);
 mesh(new THREE.CylinderGeometry(.14,.16,.25,12),skin,0,2.16,0);
 const y=2.58,w=a.face==='round'?.41:a.face==='angular'?.35:.37,h=a.face==='oval'?.48:.43;
 sphere(w,h,.36,skin,0,y,0);sphere(.27,.21,.28,skin,0,y-.19,.025);
 for(const side of [-1,1]){
  sphere(.085,.13,.07,skin,side*w,y-.015,0);sphere(.037,.075,.025,lip,side*(w+.02),y-.015,.051);
  const x=side*.145;
  sphere(.099,.112,.034,white,x,y+.015,.326);sphere(.057,.076,.021,ink,x+.01,y+.008,.355);sphere(.017,.024,.011,white,x-.008,y+.042,.375);
  curve([[x-.09,y+.17,.30],[x,y+.195,.315],[x+.085,y+.17,.30]],.024,hair);
 }
 sphere(.065,.07,.065,skin,0,y-.085,.355);
 curve([[-.10,y-.22,.312],[0,y-.245,.335],[.10,y-.22,.312]],.015,lip);

 if(a.hair!=='shaved'){
  const scalp=mesh(new THREE.SphereGeometry(1,16,12,0,Math.PI*2,0,1.48),hair,0,y+.06,-.025);scalp.scale.set(w+.045,h+.015,.395);
  if(a.hair==='short')for(let i=0;i<7;i++)sphere(.14,.09,.21,i%2?hair:hairLight,-.27+i*.09,y+.40+Math.sin(i*.55)*.025,-.03);
  if(a.hair==='afro'){
   sphere(.49,.42,.43,hair,0,y+.32,-.07);
   for(let i=0;i<14;i++){const angle=i/14*Math.PI*2;sphere(.16,.15,.16,i%3?hair:hairLight,Math.cos(angle)*.40,y+.34+Math.sin(angle)*.25,-.06+Math.sin(i*2.4)*.18);}
  }
  if(a.hair==='bun'){sphere(.25,.25,.24,hair,0,y+.53,-.18);mesh(new THREE.TorusGeometry(.22,.025,6,16),seam,0,y+.44,-.16).rotation.x=Math.PI/2;}
  if(a.hair==='braids')for(let i=0;i<7;i++){const angle=.35+i/6*(Math.PI*2-.7),x=Math.sin(angle)*.36,z=-Math.cos(angle)*.32;curve([[x*.6,y+.34,z*.7],[x,y+.03,z],[x*1.1,y-.5,z+.03]],.055,i%2?hair:hairLight);for(let j=0;j<4;j++)sphere(.06,.07,.06,hair,x*(1+j*.025),y-.08-j*.12,z+.01);}
 }

 const limbs:THREE.Group[]=[],skirt=a.top==='dress'||a.bottoms==='skirt';
 if(skirt){const dress=mesh(new THREE.CylinderGeometry(.30,.52,.64,24),a.top==='dress'?shirt:pants,0,1.12,0);dress.scale.z=.80;const hem=mesh(new THREE.TorusGeometry(.49,.025,6,24),a.top==='dress'?seam:pants,0,.80,0);hem.rotation.x=Math.PI/2;hem.scale.y=.8;}
 for(const side of [-1,1]){
  const leg=new THREE.Group();leg.position.set(side*.185,1.23,0);avatar.add(leg);
  const exposed=skirt||a.bottoms==='shorts';
  mesh(new THREE.CapsuleGeometry(a.bottoms==='wide-leg'||a.bottoms==='cargo'?.18:.135,.29,4,10),exposed?skin:pants,0,-.28,0,leg);
  mesh(new THREE.CapsuleGeometry(a.bottoms==='wide-leg'||a.bottoms==='cargo'?.18:.115,.29,4,10),exposed?skin:pants,0,-.74,0,leg);
  if(a.bottoms==='cargo')rounded(.12,.19,.20,pants,side*.18,-.40,0,leg);
  if(a.bottoms==='shorts'&&!skirt)rounded(.29,.36,.29,pants,0,-.16,0,leg);
  rounded(.31,.12,.51,sole,0,-1.155,.095,leg);
  if(a.shoes==='slides'){sphere(.13,.06,.21,skin,0,-1.06,.10,leg);rounded(.29,.10,.19,shoe,0,-1.015,.12,leg);}
  else{
   rounded(.29,a.shoes==='boots'?.32:.20,.47,shoe,0,a.shoes==='boots'?-1.0:-1.055,.08,leg);
   for(let j=0;j<3;j++)rounded(.14,.014,.023,sole,0,a.shoes==='boots'?-.835:-.947,.09+j*.065,leg);
   if(a.shoes==='sneakers')rounded(.018,.065,.22,sole,side*.15,-1.06,.08,leg);
  }limbs.push(leg);
 }
 for(const side of [-1,1]){
  const arm=new THREE.Group();arm.position.set(side*.43,2.02,0);arm.rotation.z=side*.10;avatar.add(arm);
  mesh(new THREE.CapsuleGeometry(.13,.20,4,10),shirt,0,-.15,0,arm);
  mesh(new THREE.CapsuleGeometry(.092,.28,4,10),a.top==='hoodie'?shirt:skin,0,-.46,0,arm);
  sphere(.10,.125,.085,skin,0,-.73,.015,arm);sphere(.045,.065,.045,skin,-side*.075,-.70,.055,arm);
  if(a.top==='hoodie')rounded(.21,.09,.21,seam,0,-.65,0,arm);limbs.push(arm);
 }
 if(a.top==='hoodie'){
  sphere(.24,.24,.16,shirt,0,2.08,-.20);rounded(.38,.19,.035,seam,0,1.44,.245);
  for(const side of [-1,1]){curve([[side*.10,2.02,.24],[side*.09,1.85,.27]],.014,white);sphere(.02,.027,.02,white,side*.09,1.85,.27);}
 }else if(a.top==='shirt'){
  for(const side of [-1,1])rounded(.18,.14,.05,white,side*.12,2.02,.245).rotation.z=side*.38;
  rounded(.025,.7,.025,seam,0,1.65,.27);for(let j=0;j<4;j++)sphere(.023,.023,.015,white,0,1.40+j*.17,.29);rounded(.15,.16,.025,seam,-.19,1.79,.25);
 }else{
  mesh(new THREE.TorusGeometry(.16,.028,6,16),seam,0,2.11,.015).rotation.x=Math.PI/2;
  if(a.top==='tee')rounded(.085,.10,.012,white,-.19,1.87,.254);
  if(a.top==='dress')rounded(.64,.07,.44,seam,0,1.44,0);
 }
 if(a.accessory==='glasses'){
  for(const side of [-1,1]){mesh(new THREE.TorusGeometry(.122,.019,6,20),ink,side*.145,y+.015,.376).scale.y=.92;curve([[side*.26,y+.025,.36],[side*.40,y+.04,.02]],.018,ink);}
  rounded(.07,.023,.025,ink,0,y+.025,.383);
 }
 if(a.accessory==='cap'){
  const cap=mesh(new THREE.SphereGeometry(1,16,10,0,Math.PI*2,0,Math.PI/2),shirt,0,y+.22,-.02);cap.scale.set(.45,.25,.40);
  sphere(.39,.035,.26,shirt,0,y+.22,.33);rounded(.085,.075,.015,white,0,y+.35,.36);
 }
 if(a.accessory==='tote'||a.accessory==='bag'){
  const bagMat=new THREE.MeshStandardMaterial({color:a.accessory==='tote'?'#c69a62':'#c35490',roughness:.85});
  rounded(.42,.47,.20,bagMat,.51,1.54,.14);curve([[.48,1.78,.15],[.48,2.05,.14],[.35,2.12,.09]],.025,bagMat);
 }
 if(a.accessory==='chain'){
  const gold=new THREE.MeshStandardMaterial({color:'#dbad43',metalness:.65,roughness:.3});
  curve([[-.19,2.08,.25],[0,1.85,.30],[.19,2.08,.25]],.022,gold);sphere(.04,.06,.02,gold,0,1.84,.31);
 }
 const width=a.body==='slim'?.85:a.body==='broad'?1.16:1,height=a.height==='short'?.90:a.height==='tall'?1.10:1;
 for(const child of avatar.children){child.position.x*=width;child.position.y*=height;child.scale.x*=width;child.scale.y*=height;}
 avatar.userData.styleKey=color+JSON.stringify(a);avatar.userData.shirt=shirt;avatar.userData.limbs=limbs;return avatar;
}
export function animateAvatar(avatar:THREE.Group,time:number,moving:boolean){const limbs=avatar.userData.limbs as THREE.Group[]|undefined;limbs?.forEach((limb,i)=>{const direction=i===0||i===3?1:-1;limb.rotation.x=moving?Math.sin(time/135)*direction*(i<2?.38:.28):i<2?0:Math.sin(time/1400)*.025;});}
export function disposeAvatarScene(scene:THREE.Object3D){const materials=new Set<THREE.Material>();scene.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>materials.add(m));}});materials.forEach(m=>m.dispose());}
export function updateAvatarAppearance(avatar:THREE.Group,color:string,appearance?:string|Appearance){const a=readAppearance(appearance);if(avatar.userData.styleKey===color+JSON.stringify(a))return;const replacement=createAvatar(color,a);disposeAvatarScene(avatar);avatar.clear();for(const child of [...replacement.children])avatar.add(child);avatar.userData={...avatar.userData,...replacement.userData};}
