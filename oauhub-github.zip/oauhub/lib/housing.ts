import {hostels} from './campus';
import {maleSchoolHostels,femaleSchoolHostels,apartmentDistricts} from './student-origin';
import type {StudentGender} from './student-origin';

// One paid game semester lasts 30 real days. Null fees never mean free.
export const semesterDurationMs:number|null=30*24*60*60*1000;
export const semesterFees:Record<string,number|null>={awo:50000,fajuyi:50000,angola:50000,etf:50000,moremi:50000,moza:50000,akintola:50000,alumni:50000,ojaja:300000,oakhouse:250000,maintenance:250000,damico:400000,'ooni-layout':400000,asherifa:300000,mayfair:250000,'oduduwa-area':400000};
export const maintenanceTiers={basic:250000,standard:325000,premium:400000} as const;
export type HousingOption={id:string;name:string;kind:string;gender:'male'|'female'|'mixed';eligible:boolean;fee:number|null};
export type HousingLease={hostel:string;paid_until:number;fee:number};
export type HousingState={options:HousingOption[];lease:HousingLease|null;semesterDurationMs:number|null};
export function housingOptions(gender:StudentGender|null):HousingOption[]{
 return hostels.map(h=>{
  const restriction:HousingOption['gender']=maleSchoolHostels.some(id=>id===h.id)?'male':femaleSchoolHostels.some(id=>id===h.id)||h.id==='maintenance'?'female':'mixed';
  return {id:h.id,name:h.short,kind:apartmentDistricts.some(id=>id===h.id)?'Off-campus apartment':h.id==='maintenance'?'Off-campus hostel':['ojaja','oakhouse'].includes(h.id)?'Private hostel':'School hostel',gender:restriction,eligible:restriction==='mixed'||gender===restriction,fee:semesterFees[h.id]??null};
 });
}
export function housingQuote(destination:string,gender:StudentGender|null,balance:number,tier:unknown='basic'){
 const option=housingOptions(gender).find(h=>h.id===destination);
 if(!option)return {error:'Choose a valid home.',status:400} as const;
 if(!option.eligible)return {error:`${option.name} is a ${option.gender}-only residence.`,status:403} as const;
 if(destination==='maintenance'){
  if(typeof tier!=='string'||!Object.hasOwn(maintenanceTiers,tier))return {error:'Choose a valid Maintenance price tier.',status:400} as const;
  option.fee=maintenanceTiers[tier as keyof typeof maintenanceTiers];
 }
 if(option.fee===null||semesterDurationMs===null)return {error:'Housing fees and the semester calendar are being configured. No money has been charged.',status:503} as const;
 if(balance<option.fee)return {error:`You need ₦${option.fee.toLocaleString()} for a semester at ${option.name}.`,status:400} as const;
 return {option,fee:option.fee,duration:semesterDurationMs} as const;
}
