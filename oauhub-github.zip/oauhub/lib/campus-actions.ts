import {validateAppearance} from './appearance';
import {authDb} from './account-auth';
import {Student,colors,locations,arrival} from './campus';
import {CampusState,campusJobs,shopItems,campusEvents,unionPolicies,electionWeek} from './campus-life';
const read=(id:string)=>authDb().prepare('SELECT * FROM students WHERE id=?').bind(id).first<Student>();
export async function campusState(me:Student):Promise<CampusState>{
 const db=authDb(),week=electionWeek(),day=Math.floor(Date.now()/86400000);
 const [inventory,candidates,vote,events,board,shift]=await Promise.all([
 db.prepare('SELECT item FROM campus_inventory WHERE user_id=?').bind(me.id).all<{item:string}>(),
 db.prepare('SELECT c.id,c.name,c.manifesto,c.policy,COUNT(v.user_id) AS votes FROM campus_candidates c LEFT JOIN campus_votes v ON v.candidate=c.id AND v.week=c.week WHERE c.week=? GROUP BY c.id ORDER BY votes DESC,c.name LIMIT 100').bind(week).all<CampusState['candidates'][number]>(),
 db.prepare('SELECT candidate FROM campus_votes WHERE user_id=? AND week=?').bind(me.id,week).first<{candidate:string}>(),
 db.prepare('SELECT event,attended FROM campus_event_entries WHERE user_id=? AND day=?').bind(me.id,day).all<{event:string;attended:number}>(),
 db.prepare('SELECT id,name,body,created FROM campus_board ORDER BY created DESC LIMIT 40').all<CampusState['board'][number]>(),
 db.prepare('SELECT job,started FROM campus_shifts WHERE user_id=? AND claimed=0').bind(me.id).first<{job:string;started:number}>()]);
 const leader=candidates.results[0];
 return {inventory:inventory.results,candidates:candidates.results,vote,events:events.results,board:board.results,job:shift?{id:shift.job,started:shift.started}:null,policy:leader&&leader.votes>0?leader.policy:null};
}
export async function campusAction(b:Record<string,unknown>,me:Student,now:number):Promise<Response|null>{
 const db=authDb(),nonce=crypto.randomUUID(),day=Math.floor(now/86400000),week=electionWeek(now);
 const reply=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
 const success=async(notice:string)=>reply({me:await read(me.id),notice});
 const fail=(error:string,status=400)=>reply({error},status);
 if(b.op==='venue-activity'){
  const loc=locations.find(l=>l.id===b.location);if(!loc||!['library','lecture','sports'].includes(loc.id)||me.inside)return fail('Return to campus and choose a learning or sports venue.');
  const sport=loc.id==='sports',state=await campusState(me),points=sport?0:(loc.id==='library'?12:10)+(state.policy==='study'?3:0),p=arrival(loc);
  const result=await db.prepare('UPDATE students SET energy=energy-12,hunger=MAX(0,hunger-8),study=study+?,social=MIN(100,social+?),hygiene=MAX(0,hygiene-?),x=?,z=?,last_action=? WHERE id=? AND energy>=? AND hunger>=? AND last_action<?').bind(points,sport?12:0,sport?8:0,p.x,p.z,now,me.id,sport?12:15,sport?0:10,now-8000).run();
  return result.meta.changes?success(sport?'Good game! +12 social.':`You earned ${points} study points.`):fail('Eat or rest first, or finish your previous activity.',409);
 }
 if(b.op==='appearance'){
  const look=validateAppearance(b.appearance);if(!look||typeof b.color!=='string'||!colors.includes(b.color))return fail('Choose valid appearance options.');
  await db.prepare('UPDATE students SET appearance=?,color=? WHERE id=?').bind(JSON.stringify(look),b.color,me.id).run();return success('Your look is saved. See you on campus!');
 }
 if(b.op==='outfit'){
  if(typeof b.color!=='string'||!colors.includes(b.color))return fail('Choose a valid outfit colour.');
  await db.prepare('UPDATE students SET color=? WHERE id=?').bind(b.color,me.id).run();return success('Your avatar has a new look.');
 }
 if(b.op==='shop'){
  const item=shopItems.find(i=>i.id===b.item);if(!item)return fail('Choose a shop item.');
  const result=await db.batch([
   db.prepare('UPDATE students SET money=money-?,action_nonce=?,last_action=? WHERE id=? AND money>=? AND last_action<? AND NOT EXISTS(SELECT 1 FROM campus_inventory WHERE user_id=? AND item=?)').bind(item.price,nonce,now,me.id,item.price,now-8000,me.id,item.id),
   db.prepare('INSERT INTO campus_inventory (user_id,item) SELECT id,? FROM students WHERE id=? AND action_nonce=?').bind(item.id,me.id,nonce),
   db.prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,item.name,-item.price,now,me.id,nonce)]);
  return result[0].meta.changes?success(`${item.name} is now in your room.`):fail('Already owned, insufficient funds, or your last activity is still finishing.',409);
 }
 if(b.op==='job-start'){
  const job=campusJobs.find(j=>j.id===b.job);if(!job)return fail('Choose a campus job.');
  const result=await db.prepare('INSERT INTO campus_shifts (user_id,job,started,claimed) VALUES (?,?,?,0) ON CONFLICT(user_id) DO UPDATE SET job=excluded.job,started=excluded.started,claimed=0 WHERE campus_shifts.claimed=1 AND campus_shifts.started<?').bind(me.id,job.id,now,now-1200000).run();
  return result.meta.changes?success(`Your ${job.name.toLowerCase()} shift has started. Return to Jobs when the timer finishes.`):fail('Finish your active shift first. New shifts are available every 20 minutes.',409);
 }
 if(b.op==='job-claim'){
  const shift=await db.prepare('SELECT job,started,claimed FROM campus_shifts WHERE user_id=?').bind(me.id).first<{job:string;started:number;claimed:number}>();const job=campusJobs.find(j=>j.id===shift?.job);
  if(!shift||!job||shift.claimed)return fail('Start a shift first.');if(now<shift.started+job.duration*1000)return fail('Your shift is still in progress.');
  const result=await db.batch([
   db.prepare('UPDATE students SET money=money+?,energy=energy-?,action_nonce=?,last_action=? WHERE id=? AND energy>=? AND last_action<? AND EXISTS(SELECT 1 FROM campus_shifts WHERE user_id=? AND claimed=0 AND started<=?)').bind(job.reward,job.energy,nonce,now,me.id,job.energy,now-8000,me.id,now-job.duration*1000),
   db.prepare('UPDATE campus_shifts SET claimed=1 WHERE user_id=? AND EXISTS(SELECT 1 FROM students WHERE id=? AND action_nonce=?)').bind(me.id,me.id,nonce),
   db.prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,job.name+' wages',job.reward,now,me.id,nonce)]);
  return result[0].meta.changes?success(`Shift complete! You earned ₦${job.reward}.`):fail('Rest before collecting this shift, or finish your last activity first.',409);
 }
 if(b.op==='transfer'){
  const amount=b.amount,recipient=b.recipient;if(typeof amount!=='number'||!Number.isInteger(amount)||amount<1||amount>5000||typeof recipient!=='string'||recipient===me.id)return fail('Choose another student and an amount from ₦1 to ₦5,000.');
  const target=await read(recipient);if(!target)return fail('Student not found.');
  const result=await db.batch([
   db.prepare('UPDATE students SET money=money-?,action_nonce=?,last_action=? WHERE id=? AND money>=? AND last_action<?').bind(amount,nonce,now,me.id,amount,now-8000),
   db.prepare('UPDATE students SET money=money+? WHERE id=? AND EXISTS(SELECT 1 FROM students WHERE id=? AND action_nonce=?)').bind(amount,recipient,me.id,nonce),
   db.prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,`Transfer to ${target.name}`,-amount,now,me.id,nonce),
   db.prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,?,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce+'-in',recipient,`Transfer from ${me.name}`,amount,now,me.id,nonce)]);
  return result[0].meta.changes?success(`Sent ₦${amount} in game money to ${target.name}.`):fail('Insufficient game money, or finish your last activity first.',409);
 }
 if(b.op==='campaign'){
  const manifesto=typeof b.manifesto==='string'?b.manifesto.trim():'';if(manifesto.length<10||manifesto.length>180||!unionPolicies.some(p=>p.id===b.policy))return fail('Choose a policy and write a manifesto of 10–180 characters.');
  await db.prepare('INSERT INTO campus_candidates (id,name,manifesto,policy,week) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET manifesto=excluded.manifesto,policy=excluded.policy').bind(`${week}:${me.id}`,me.name,manifesto,b.policy,week).run();return success('Your student union campaign is on the ballot.');
 }
 if(b.op==='vote'){
  if(typeof b.candidate!=='string')return fail('Choose a candidate.');
  const result=await db.prepare('INSERT OR IGNORE INTO campus_votes (user_id,week,candidate) SELECT ?,?,id FROM campus_candidates WHERE id=? AND week=?').bind(me.id,week,b.candidate,week).run();return result.meta.changes?success('Your vote is saved. One vote per student each week.'):fail('You have already voted this week, or that candidate is unavailable.',409);
 }
 if(b.op==='event-rsvp'||b.op==='event-attend'){
  const event=campusEvents.find(e=>e.id===b.event);if(!event)return fail('Choose an event.');
  if(b.op==='event-rsvp'){await db.prepare('INSERT OR IGNORE INTO campus_event_entries (user_id,day,event,attended) VALUES (?,?,?,0)').bind(me.id,day,event.id).run();return success(`You are on the list for ${event.name}.`);}
  if(me.inside)return fail('Return to campus before attending an event.');
  const p=arrival(locations.find(l=>l.id===event.location)!);
  const result=await db.batch([
   db.prepare('UPDATE students SET social=MIN(100,social+?),study=study+?,energy=MAX(0,energy-8),x=?,z=?,last_action=?,action_nonce=? WHERE id=? AND last_action<? AND NOT EXISTS(SELECT 1 FROM campus_event_entries WHERE user_id=? AND day=? AND event=? AND attended=1)').bind(event.social,event.study,p.x,p.z,now,nonce,me.id,now-8000,me.id,day,event.id),
   db.prepare('INSERT INTO campus_event_entries (user_id,day,event,attended) SELECT id,?,?,1 FROM students WHERE id=? AND action_nonce=? ON CONFLICT(user_id,day,event) DO UPDATE SET attended=1').bind(day,event.id,me.id,nonce)]);
  return result[0].meta.changes?success(`You attended ${event.name}. Meet other students at the venue!`):fail('You already attended today, or your last activity is still finishing.',409);
 }
 if(b.op==='board'){
  const body=typeof b.body==='string'?b.body.trim():'';if(body.length<1||body.length>280)return fail('Write a campus post of 1–280 characters.');
  const result=await db.batch([db.prepare('INSERT INTO campus_board (id,user_id,name,body,created) SELECT ?,id,name,?,? FROM students WHERE id=? AND last_chat<?').bind(nonce,body,now,me.id,now-10000),db.prepare('UPDATE students SET last_chat=? WHERE id=? AND last_chat<?').bind(now,me.id,now-10000)]);return result[0].meta.changes?success('Posted to the campus noticeboard.'):fail('Wait a few seconds before posting again.',429);
 }
 if(b.op==='quiz'){
  if(!Array.isArray(b.answers)||b.answers.length!==3||b.answers.some((a,i)=>a!==[1,1,2][i]))return fail('Not quite! Try the quiz again.');
  const result=await db.batch([db.prepare("UPDATE students SET study=study+5,action_nonce=? WHERE id=? AND NOT EXISTS(SELECT 1 FROM campus_event_entries WHERE user_id=? AND day=? AND event='quiz' AND attended=1)").bind(nonce,me.id,me.id,day),db.prepare("INSERT INTO campus_event_entries (user_id,day,event,attended) SELECT id,?,'quiz',1 FROM students WHERE id=? AND action_nonce=?").bind(day,me.id,nonce)]);
  return result[0].meta.changes?success('Perfect score! You earned 5 study points.'):fail('You already earned today’s quiz reward.',409);
 }
 if(b.op==='wellbeing'){
  if(!['clinic','quiet','fitness'].includes(String(b.activity)))return fail('Choose a wellbeing activity.');
  const clinic=b.activity==='clinic',fitness=b.activity==='fitness',cost=clinic?250:0;
  const result=await db.batch([db.prepare('UPDATE students SET money=money-?,energy=MIN(100,MAX(0,energy+?)),hygiene=MIN(100,hygiene+?),social=MIN(100,social+?),last_action=?,action_nonce=? WHERE id=? AND money>=? AND energy>=? AND last_action<?').bind(cost,clinic?20:fitness?-10:15,clinic?20:0,fitness?15:5,now,nonce,me.id,cost,fitness?10:0,now-8000),...clinic?[db.prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,'Health Centre visit',-cost,now,me.id,nonce)]:[]]);
  return result[0].meta.changes?success(clinic?'Your avatar feels refreshed.':fitness?'Workout complete.':'A quiet moment to recharge.'):fail('Check your funds and energy, or wait for your last activity.',409);
 }
 if(b.op==='transport'){
  const destination=locations.find(l=>l.id===b.destination);if(!destination)return fail('Choose a campus stop.');const state=await campusState(me),cost=state.policy==='transport'?50:100,p=arrival(destination);
  const result=await db.batch([db.prepare("UPDATE students SET inside='',x=?,z=?,money=money-?,action_nonce=?,last_action=? WHERE id=? AND money>=? AND last_action<?").bind(p.x,p.z,cost,nonce,now,me.id,cost,now-8000),db.prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,`Shuttle to ${destination.short}`,-cost,now,me.id,nonce)]);
  return result[0].meta.changes?success(`Arrived at ${destination.short}.`):fail('You need the shuttle fare, or your last activity is still finishing.',409);
 }
 return null;
}
