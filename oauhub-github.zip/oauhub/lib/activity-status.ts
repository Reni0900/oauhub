'use client';
import {useEffect} from 'react';
export function reportActivity(source:string,label:string,duration=0){
 if(typeof window!=='undefined')window.dispatchEvent(new CustomEvent('oauhub-activity',{detail:{source,label,started:Date.now(),duration}}));
}
export function useActivityStatus(source:string,label:string){
 useEffect(()=>{reportActivity(source,label);return()=>reportActivity(source,'');},[source,label]);
}
