import * as THREE from 'three';
import type {InteriorLayout} from './interior-layout';
export function buildInterior(scene:THREE.Scene,layout:InteriorLayout,inventory:{item:string}[]){
 const materials=new Map<string,THREE.MeshStandardMaterial>(),geometry=new THREE.BoxGeometry(1,1,1),hot:THREE.Object3D[]=[],objects:Record<string,THREE.Group>={};
 const mat=(color:string)=>{if(!materials.has(color))materials.set(color,new THREE.MeshStandardMaterial({color,roughness:.8}));return materials.get(color)!;};
 function box(w:number,h:number,d:number,color:string,x:number,y:number,z:number,parent:THREE.Object3D=scene){const m=new THREE.Mesh(geometry,mat(color));m.scale.set(w,h,d);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
 function cylinder(radius:number,h:number,color:string,x:number,y:number,z:number,parent:THREE.Object3D=scene){const m=new THREE.Mesh(new THREE.CylinderGeometry(radius,radius,h,20),mat(color));m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
 function group(id:string,x:number,z:number){const g=new THREE.Group();g.position.set(x,0,z);objects[id]=g;scene.add(g);return g;}
 function plant(x:number,z:number){cylinder(.3,.55,'#ba7858',x,.28,z);for(const [dx,dz]of [[0,0],[.2,.1],[-.2,-.1]]){const leaf=new THREE.Mesh(new THREE.SphereGeometry(.32,8,6),mat('#4e8760'));leaf.scale.set(.7,1.7,.7);leaf.position.set(x+dx,1+Math.abs(dx),z+dz);scene.add(leaf);}}
 const apartment=layout.kind==='apartment';
 const island=cylinder(20,.25,'#d0d9b4',0,-.55,0);island.receiveShadow=true;
 cylinder(18.8,.1,'#c3cea6',0,-.37,0);
 const floor=box(24,.35,20,'#bbc1b1',0,-.18,0);
 const tiles=new THREE.InstancedMesh(geometry,mat('#e5e3d8'),480),matrix=new THREE.Matrix4();let tile=0;
 for(let x=-12;x<12;x++)for(let z=-10;z<10;z++){matrix.makeScale(.97,.035,.97);matrix.setPosition(x+.5,.015,z+.5);tiles.setMatrixAt(tile++,matrix);}tiles.receiveShadow=true;scene.add(tiles);
 box(24,3.6,.24,'#263c49',0,1.8,-10);box(.24,3.6,20,'#1e3542',-12,1.8,0);
 box(24,.12,.35,'#426575',0,3.62,-10);box(.35,.12,20,'#426575',-12,3.62,0);
 // The camera-facing walls are cut away so every room stays visible.
 box(24,.3,.22,'#78919a',0,.15,10);box(.22,.3,20,'#78919a',12,.15,0);
 for(const wall of layout.walls){box(wall.w,1.25,wall.d,'#3b5360',wall.x,.625,wall.z);box(wall.w+.04,.06,wall.d+.04,'#eae9df',wall.x,1.28,wall.z);}
 const bedColors=['#7d699e','#b76d62','#6c957d','#bd9c61'];
 layout.beds.forEach((p,i)=>{
  const bed=group(`bed-${i}`,p.x,p.z);box(2.6,.5,4.4,'#84654c',0,.35,0,bed);box(2.5,.35,4.2,'#fff9e9',0,.78,0,bed);box(2.5,.16,2.85,bedColors[i],0,1.02,.62,bed);box(1.8,.28,.8,'#fdf9ef',0,1.05,-1.45,bed);box(2.7,1.4,.18,'#77543c',0,.8,-2.2,bed);
  const shelf=group(`wardrobe-${i}`,p.x+1.9,-9.15);box(1.3,2.8,1,'#c7a77f',0,1.4,0,shelf);box(.04,2.6,.07,'#8d6d4c',0,1.4,.52,shelf);box(.1,.3,.1,'#e9ddb8',-.17,1.45,.6,shelf);
  box(1.1,.75,.1,'#e2c87b',p.x,2.4,-9.82);box(.8,.12,.12,bedColors[i],p.x,2.4,-9.73);
 });
 const desks=apartment?[{x:-2.5,z:-6.8}]:layout.beds.map(p=>({x:p.x+1.7,z:-2.8}));
 desks.forEach((p,i)=>{
  const desk=group(`desk-${i}`,p.x,p.z);box(1.8,.15,1,'#c8a16c',0,1.5,0,desk);for(const x of [-.7,.7])box(.12,1.5,.12,'#7d654e',x,.75,0,desk);
  box(.7,.08,.55,'#4f6170',0,1.64,0,desk);box(.7,.5,.06,'#264452',0,1.9,-.2,desk);box(.48,.08,.5,'#ca7766',.58,1.66,0,desk);
  box(.7,.12,.7,'#bd9c7b',0,.8,1.05,desk);box(.7,.7,.12,'#b18e6b',0,1.2,1.36,desk);for(const x of [-.25,.25])box(.1,.75,.1,'#7d654e',x,.4,1.1,desk);
 });
 const sofa=group('sofa',apartment?-9.8:-10,6);box(1.8,.55,4.8,'#b86566',0,.55,0,sofa);box(.4,1.1,4.8,'#a14f54',-.7,.85,0,sofa);for(const z of [-2.2,2.2])box(1.8,.8,.32,'#a14f54',0,.8,z,sofa);for(const z of [-1.5,0,1.5])box(1.3,.18,1.4,'#cd7b76',.15,.93,z,sofa);
 const frontSofa=group('lounge',apartment?-6:-7.8,7.8);box(4,.5,1.6,'#c0a777',0,.55,0,frontSofa);box(4,1,.25,'#ac925f',0,.9,.68,frontSofa);
 const table=group('food',apartment?-6:-8,6);box(2.3,.16,1.2,'#976d4e',0,.8,0,table);for(const x of [-.85,.85])box(.12,.8,.12,'#775b44',x,.4,0,table);cylinder(.3,.035,'#faf3da',.3,.92,0,table);cylinder(.14,.25,'#708c85',-.5,1,0,table);
 box(5,.025,4,'#ccb577',apartment?-6:-8,.06,5.8);box(4.6,.028,3.6,inventory.some(i=>i.item==='rug')?'#a87688':'#819492',apartment?-6:-8,.08,5.8);
 const tv=group('tv',apartment?-7:-8,.6);box(3.8,2,.18,'#1c2c35',0,1.7,0,tv);box(3.5,1.7,.05,'#426573',0,1.7,.12,tv);box(4.2,.55,1,'#ad8b65',0,.38,0,tv);box(.4,.5,.12,'#1f3037',-1.4,.7,.2,tv);box(.4,.5,.12,'#1f3037',1.4,.7,.2,tv);
 const kx=apartment?6:0,kz=apartment?-8.8:8.8,kitchen=group('kitchen',kx,kz);
 box(apartment?10:6,1.45,1.6,'#ceb999',0,.75,0,kitchen);box(apartment?10.2:6.2,.17,1.8,'#faf5e6',0,1.53,0,kitchen);
 for(const x of apartment?[-4,-2,0,2,4]:[-2,0,2]){box(.035,1.3,.06,'#b49b7d',x,.8,-.82,kitchen);box(.35,.07,.1,'#685f55',x+.45,1.2,-.87,kitchen);}
 const stove=group('stove',kx-1.7,kz);box(1.7,.08,1.35,'#3a454b',0,1.68,0,stove);for(const x of [-.4,.4])for(const z of [-.3,.3])cylinder(.22,.035,'#8c9293',x,1.74,z,stove);cylinder(.32,.35,'#bd8762',-.4,1.95,-.25,stove);box(.2,.06,.55,'#544d44',-.4,2.15,-.57,stove);
 const sink=group('sink',kx+1.6,kz);box(1.15,.05,1,'#90a3a7',0,1.65,0,sink);box(.8,.06,.7,'#5f7983',0,1.67,0,sink);box(.08,.55,.08,'#c1cccc',0,1.93,-.35,sink);box(.35,.08,.08,'#c1cccc',.13,2.2,-.35,sink);
 const fridge=group('fridge',apartment?10.7:2.9,apartment?-5.5:7);box(1.6,2.8,1.5,'#e1e9e3',0,1.4,0,fridge);box(1.5,.03,.06,'#859aa0',0,1.8,.78,fridge);box(.12,.65,.12,'#5c7681',-.55,1.1,.84,fridge);
 if(apartment){box(2.5,.16,1.6,'#bd9a6f',6,1.05,-5);for(const x of [5.2,6.8])box(.12,1,.12,'#7b6047',x,.5,-5);for(const x of [4.5,7.5]){box(.65,.12,.7,'#718d7e',x,.65,-5);box(.15,1,.75,'#567564',x,1,-5);}}
 const shower=group('shower',10.4,7.7);box(2,.12,2.4,'#e4ece7',0,.12,0,shower);box(.1,2.7,2.4,'#adc8ca',1,1.45,0,shower);box(2,2.7,.1,'#adc8ca',0,1.45,1.2,shower);box(.09,2.4,.09,'#77939e',.8,1.35,.8,shower);box(.6,.12,.4,'#b8ced3',.58,2.5,.72,shower);
 const glass=new THREE.Mesh(new THREE.BoxGeometry(.05,2.3,2.2),new THREE.MeshStandardMaterial({color:'#b6dfdf',transparent:true,opacity:.35,roughness:.18}));glass.position.set(-1,1.38,0);shower.add(glass);
 const washer=group('laundry',6,8.7);box(1.6,1.8,1.6,'#e5ebe4',0,.9,0,washer);const drum=cylinder(.55,.07,'#587480',0,.9,-.85,washer);drum.rotation.x=Math.PI/2;box(1.3,.13,.09,'#a6bab6',0,1.62,-.84,washer);
 const toilet=group('toilet',8.2,8.8);cylinder(.45,.7,'#f2f4eb',0,.4,0,toilet);box(.9,1.2,.45,'#e8ece4',0,.85,.5,toilet);cylinder(.5,.1,'#b3c3bd',0,.82,0,toilet);
 plant(-11,1);plant(apartment?2:-2,6);plant(11,-9);
 if(inventory.some(i=>i.item==='lamp')){cylinder(.25,.1,'#4f5d61',-10,.1,2);cylinder(.06,2.6,'#5b6c6d',-10,1.4,2);cylinder(.5,.5,'#edd29a',-10,2.65,2);}
 if(inventory.some(i=>i.item==='poster'))box(1.7,1.6,.07,'#db9f83',-4,2.35,-9.8);
 for(const [id,g]of Object.entries(objects))g.traverse(o=>{if(o instanceof THREE.Mesh){o.userData.spot=id.startsWith('wardrobe-')?'style':id.startsWith('bed-')?'bed':id.startsWith('desk-')?'desk':['stove','sink','fridge'].includes(id)?'kitchen':id==='tv'||id==='lounge'?'sofa':id==='toilet'?'shower':id;hot.push(o);}});
 return {floor,hot,objects};
}
