export const campusJobs=[
 {id:'library',name:'Library assistant',location:'library',description:'Sort the return shelf and help students find books.',reward:450,energy:10,duration:30},
 {id:'canteen',name:'Canteen shift',location:'food',description:'Help serve lunch at the campus food spot.',reward:600,energy:15,duration:45},
 {id:'tutor',name:'Peer tutor',location:'lecture',description:'Help a fellow student revise for class.',reward:750,energy:18,duration:60}
];
export const shopItems=[
 {id:'rug',name:'Room rug',price:800,description:'A colourful rug for your room.'},
 {id:'plant',name:'Desk plant',price:450,description:'A little green beside your study desk.'},
 {id:'lamp',name:'Reading lamp',price:650,description:'Make your desk feel like home.'},
 {id:'poster',name:'Great Ife poster',price:300,description:'Put your campus pride on the wall.'}
];
export const campusEvents=[
 {id:'debate',name:'Faculty debate',location:'oduduwa',description:'Meet students and exchange ideas.',social:15,study:5},
 {id:'match',name:'Hall football meetup',location:'sports',description:'Meet on the pitch for a friendly game.',social:20,study:0},
 {id:'reading',name:'Reading circle',location:'library',description:'Bring your notes and revise together.',social:10,study:10},
 {id:'openmic',name:'Amphi open mic',location:'amphi',description:'An evening of campus stories and talent.',social:25,study:0}
];
export const unionPolicies=[{id:'transport',name:'Transport support',description:'Shuttle rides cost ₦50 instead of ₦100.'},{id:'food',name:'Meal support',description:'Phone meals cost ₦100 less.'},{id:'study',name:'Study support',description:'Library and lecture activities earn 3 extra study points.'}];
export function electionWeek(now=Date.now()){return Math.floor((now-345600000)/604800000);}
export type CampusState={inventory:{item:string}[];candidates:{id:string;name:string;manifesto:string;policy:string;votes:number}[];vote:{candidate:string}|null;policy:string|null;events:{event:string;attended:number}[];board:{id:string;name:string;body:string;created:number}[];job:{id:string;started:number}|null};
