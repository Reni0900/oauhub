import {Student,locations} from './campus';
import {Appearance} from './appearance';
export type Product={id:string;name:string;category:string;price:number;description:string;art:string;tone:string;look?:Partial<Appearance>;color?:string};
const product=(id:string,name:string,category:string,price:number,art:string,description:string,tone='#527b72'):Product=>({id,name,category,price,art,description,tone});
export const roomProducts:Product[]=[
 product('rug','Woven room rug','Room',12000,'rug','A warm patterned rug for your room.','#bc7950'),
 product('plant','Desk plant','Room',3500,'plant','A little green beside your books.'),
 product('lamp','Rechargeable reading lamp','Study',6500,'lamp','Light up late-night revision.','#e1b349'),
 product('poster','Great Ife art print','Room',2000,'poster','A framed campus print.','#5273a0'),
 product('fan','Rechargeable desk fan','Electronics',28000,'fan','A portable fan for hot afternoons.'),
 product('powerbank','20,000mAh power bank','Electronics',20000,'powerbank','Backup power for student life.','#343a4b'),
 product('headphones','Wireless headphones','Electronics',15000,'headphones','Your own study soundtrack.','#ae799c'),
 product('speaker','Portable speaker','Electronics',12000,'speaker','Music for room hangouts.','#bf8840'),
 product('extension','Surge extension socket','Electronics',6500,'extension','Keep your charging corner organised.'),
 product('notebooks','Notebook set','Study',2500,'book','Three notebooks for lecture notes.','#b86658'),
 product('calculator','Scientific calculator','Study',12500,'calculator','For maths and science revision.','#49669b'),
 product('backpack','Campus backpack','Study',16000,'bag','Carry your everyday lecture essentials.','#946245'),
 product('bottle','Reusable water bottle','Essentials',4500,'bottle','A refillable bottle for long campus days.','#68a7ad'),
 product('laundry','Laundry basket','Essentials',5500,'basket','A home for clothes waiting for wash day.'),
 product('bucket','Bucket and bowl set','Essentials',4000,'bucket','A hostel bathroom essential.','#a18cc4'),
 product('bedsheet','Bedsheet and pillowcase set','Room',12000,'bedsheet','Fresh bedding for your space.','#8198bf'),
 product('pillow','Soft pillow','Room',5000,'pillow','Make your bed a little cosier.','#c18a9d'),
 product('mirror','Standing mirror','Room',18000,'mirror','Check your outfit before lectures.'),
 product('storage','Under-bed storage box','Room',7000,'storage','Keep your room tidy.','#c69a62'),
 product('kettle','Electric kettle','Kitchen',15000,'kettle','A hot-water essential for your kitchen.'),
 product('pots','Cooking pot set','Kitchen',22000,'pot','A starter set for home cooking.','#766b89'),
 product('plates','Plate and cutlery set','Kitchen',6000,'plate','Your own dining essentials.','#c7a15e'),
 product('mug','Ceramic mug','Kitchen',2500,'mug','For tea and study breaks.','#bc7950'),
 product('flask','Food flask','Kitchen',9000,'pot','Keep your lunch ready between lectures.')
];
const fashion=(id:string,name:string,category:string,price:number,art:string,tone:string,look:Partial<Appearance>,color?:string):Product=>({...product('fashion-'+id,name,category,price,art,'A curated piece for your campus wardrobe.',tone),look,color});
export const boutiqueProducts:Product[]=[
 fashion('oversized-tee','Oversized graphic tee','Clothes',8500,'tee','#7159e8',{top:'tee'},'#7159e8'),
 fashion('baby-tee','Rose baby tee','Clothes',6500,'tee','#c35490',{top:'tee'},'#c35490'),
 fashion('jersey','Campus jersey','Clothes',10000,'tee','#278b91',{top:'tee'},'#278b91'),
 fashion('hoodie','Relaxed hoodie','Clothes',18000,'hoodie','#3d71c7',{top:'hoodie'},'#3d71c7'),
 fashion('linen','Linen button-up','Clothes',14000,'shirt','#a77b31',{top:'shirt'},'#a77b31'),
 fashion('dress','Berry day dress','Clothes',16000,'dress','#c35490',{top:'dress'},'#c35490'),
 fashion('denim','Wide-leg denim','Clothes',13000,'trousers','#33435c',{bottoms:'wide-leg',bottomColor:'#33435c'}),
 fashion('black-denim','Washed black jeans','Clothes',14000,'trousers','#22232a',{bottoms:'jeans',bottomColor:'#22232a'}),
 fashion('cargo','Sand cargo trousers','Clothes',16000,'trousers','#a08464',{bottoms:'cargo',bottomColor:'#a08464'}),
 fashion('shorts','Relaxed denim shorts','Clothes',9000,'shorts','#33435c',{bottoms:'shorts',bottomColor:'#33435c'}),
 fashion('skirt','Cream campus skirt','Clothes',11000,'skirt','#ebe3d3',{bottoms:'skirt',bottomColor:'#ebe3d3'}),
 fashion('retro','Cream retro sneakers','Shoes',18000,'shoe','#f2eddf',{shoes:'sneakers',shoeColor:'#f2eddf'}),
 fashion('pink-sneaker','Pink low-profile sneakers','Shoes',16000,'shoe','#c35490',{shoes:'sneakers',shoeColor:'#c35490'}),
 fashion('black-sneaker','Black everyday sneakers','Shoes',15000,'shoe','#24242a',{shoes:'sneakers',shoeColor:'#24242a'}),
 fashion('slides','Everyday slides','Shoes',6000,'shoe','#9a6245',{shoes:'slides',shoeColor:'#9a6245'}),
 fashion('boots','Chocolate ankle boots','Shoes',22000,'shoe','#9a6245',{shoes:'boots',shoeColor:'#9a6245'}),
 fashion('glasses','Statement sunglasses','Accessories',4500,'glasses','#252d36',{accessory:'glasses'}),
 fashion('cap','Campus baseball cap','Accessories',5000,'cap','#3d71c7',{accessory:'cap'}),
 fashion('tote','Everyday canvas tote','Accessories',6000,'bag','#c69a62',{accessory:'tote'}),
 fashion('shoulder','Mini shoulder bag','Accessories',12000,'bag','#c35490',{accessory:'bag'}),
 fashion('chain','Minimal gold chain','Accessories',3500,'chain','#dbad43',{accessory:'chain'})
];
export const offCampus=['maintenance','damico','ooni-layout','asherifa','mayfair','oduduwa-area'];
export function travelQuote(me:Pick<Student,'x'|'z'|'hostel'|'inside'>,destination:string,service='regular',support=false){
 const to=locations.find(l=>l.id===destination);if(!to)return null;
 const from=me.inside?locations.find(l=>l.id===me.inside):locations.reduce((a,l)=>Math.hypot(l.x-me.x,l.z-me.z)<Math.hypot(a.x-me.x,a.z-me.z)?l:a,locations[0]);
 if(!from)return null;
 const off=offCampus.includes(from.id)||offCampus.includes(to.id);
 // Stylised map coordinates represent route lengths, not surveyed geography.
 const km=from.id===to.id?0:Math.max(.5,Math.round(Math.hypot(to.x-from.x,to.z-from.z)*.06*10)/10);
 const subsidised=service==='subsidised';
 const base=subsidised?100:off?(km<=2?300:km<=4?400:600):km<=1.5?100:km<=3?150:200;
 return {from:from.short,km,cost:from.id===to.id?0:Math.max(50,base-(support?50:0)),available:!subsidised||!off};
}
