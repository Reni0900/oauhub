import {authDb} from './account-auth';
import {Student} from './campus';
import {roomProducts} from './commerce';
import {interiorLayout,isApartment,canStand,Point} from './interior-layout';
export type RoomItem={user_id:string;item:string;hostel:string;block:string;room:number;x:number;z:number;rotation:number};
export async function roomItems(home:{hostel:string;block:string;room:number}){
 const r=await authDb().prepare('SELECT r.* FROM room_items r JOIN students s ON s.id=r.user_id AND s.hostel=r.hostel AND s.block=r.block AND s.room=r.room WHERE r.hostel=? AND r.block=? AND r.room=? LIMIT 96').bind(home.hostel,home.block,home.room).all<RoomItem>();return r.results;
}
export function itemFits(p:Point,others:RoomItem[],item:string,rotation:number,apartment:boolean){
 const layout=interiorLayout(apartment),radius=item==='rug'?.35:.6;
 return [p,{x:p.x+radius,z:p.z},{x:p.x-radius,z:p.z},{x:p.x,z:p.z+radius},{x:p.x,z:p.z-radius}].every(q=>canStand(q,layout))&&!others.some(o=>Math.hypot(o.x-p.x,o.z-p.z)<1.35);
}
export async function roomDecorAction(b:Record<string,unknown>,me:Student,visiting:boolean,paidUntil:number|null,now:number){
 if(!['room-item-place','room-item-remove'].includes(String(b.op)))return null;
 const fail=(error:string,status=400)=>Response.json({error},{status});
 if(visiting||me.inside!==me.hostel||!me.room)return fail('Enter your own room before decorating.',403);
 if(paidUntil!==null&&paidUntil<=now)return fail('Renew your housing semester before decorating.',402);
 const item=roomProducts.find(p=>p.id===b.item);if(!item)return fail('Choose an item from the room shop.');
 const db=authDb(),owned=await db.prepare('SELECT item FROM campus_inventory WHERE user_id=? AND item=?').bind(me.id,item.id).first();if(!owned)return fail('Buy this item before placing it.',403);
 if(b.op==='room-item-remove'){await db.prepare('DELETE FROM room_items WHERE user_id=? AND item=?').bind(me.id,item.id).run();return Response.json({notice:`${item.name} returned to storage.`});}
 if(typeof b.x!=='number'||typeof b.z!=='number'||!Number.isFinite(b.x)||!Number.isFinite(b.z)||typeof b.rotation!=='number'||![0,1,2,3].includes(b.rotation))return fail('Choose a valid position and rotation.');
 const others=(await roomItems(me)).filter(o=>!(o.user_id===me.id&&o.item===item.id));
 if(!itemFits({x:b.x,z:b.z},others,item.id,b.rotation,isApartment(me.hostel)))return fail('That spot is blocked. Choose open floor away from furniture and other items.',409);
 await db.prepare('INSERT INTO room_items(user_id,item,hostel,block,room,x,z,rotation) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(user_id,item) DO UPDATE SET hostel=excluded.hostel,block=excluded.block,room=excluded.room,x=excluded.x,z=excluded.z,rotation=excluded.rotation').bind(me.id,item.id,me.hostel,me.block,me.room,b.x,b.z,b.rotation).run();
 return Response.json({notice:`${item.name} placed in your room.`});
}
