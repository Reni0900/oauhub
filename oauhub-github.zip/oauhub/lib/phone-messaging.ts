import {authDb} from './account-auth';
import {Student} from './campus';
import {meals} from './hostel-life';
const json=(body:unknown,status=200)=>Response.json(body,{status});
export async function ensurePhoneProfiles(){await authDb().batch([authDb().prepare("INSERT OR IGNORE INTO account_identities SELECT s.id,COALESCE(p.username,'ife_'||REPLACE(LOWER(s.id),'-','')),s.name FROM students s LEFT JOIN phone_profiles p ON p.user_id=s.id"),authDb().prepare('INSERT OR IGNORE INTO phone_profiles SELECT s.id,i.username FROM students s JOIN account_identities i ON i.account_id=s.id')]);}
export async function phoneBlocked(a:string,b:string){return !!await authDb().prepare('SELECT user_id FROM phone_blocks WHERE (user_id=? AND target_id=?) OR (user_id=? AND target_id=?)').bind(a,b,b,a).first();}
export async function phoneState(id:string){
 await ensurePhoneProfiles();const db=authDb();const [groups,messages,reads]=await Promise.all([
  db.prepare(`SELECT g.*, (SELECT COUNT(*) FROM phone_group_members WHERE group_id=g.id) AS members, (SELECT COUNT(*) FROM phone_group_messages m WHERE m.group_id=g.id AND m.sender!=? AND m.created>COALESCE((SELECT read_at FROM phone_reads WHERE user_id=? AND conversation='group:'||g.id),0)) AS unread FROM phone_groups g JOIN phone_group_members a ON a.group_id=g.id WHERE a.user_id=? ORDER BY g.created DESC LIMIT 30`).bind(id,id,id).all(),
  db.prepare('SELECT m.*,s.name AS sender_name FROM phone_group_messages m JOIN phone_group_members a ON a.group_id=m.group_id JOIN students s ON s.id=m.sender WHERE a.user_id=? AND NOT EXISTS(SELECT 1 FROM phone_blocks b WHERE b.user_id=a.user_id AND b.target_id=m.sender) ORDER BY m.created DESC LIMIT 200').bind(id).all(),
  db.prepare('SELECT conversation,read_at FROM phone_reads WHERE user_id=?').bind(id).all<{conversation:string;read_at:number}>()
 ]);const profile=await db.prepare('SELECT username FROM phone_profiles WHERE user_id=?').bind(id).first<{username:string}>();const blocked=await db.prepare('SELECT b.target_id,s.name,p.username FROM phone_blocks b JOIN students s ON s.id=b.target_id LEFT JOIN phone_profiles p ON p.user_id=s.id WHERE b.user_id=?').bind(id).all();return {username:profile?.username,blocked:blocked.results,groups:groups.results,messages:messages.results.reverse(),reads:Object.fromEntries(reads.results.map(r=>[r.conversation,r.read_at]))};
}
export async function phoneAction(b:{op?:string;name?:unknown;members?:unknown;group?:unknown;body?:unknown;conversation?:unknown;recipient?:unknown;username?:unknown;reason?:unknown;meal?:unknown},me:Student,now:number){
 const db=authDb();
 if(b.op==='phone-lookup'){
  const username=typeof b.username==='string'?b.username.trim().replace(/^@/,'').toLowerCase():'';
  if(!/^[a-z0-9_]{3,44}$/.test(username))return json({error:'Enter the complete username.'},400);
  await ensurePhoneProfiles();const contact=await db.prepare('SELECT s.id,s.name,s.color,s.appearance,s.hostel,s.last_seen,p.username FROM phone_profiles p JOIN students s ON s.id=p.user_id WHERE p.username=? AND s.id!=?').bind(username,me.id).first();
  return contact?json({contact}):json({error:'No player has that username.'},404);
 }
 if(b.op==='phone-username'){
  const username=typeof b.username==='string'?b.username.trim().replace(/^@/,'').toLowerCase():'';
  if(!/^[a-z][a-z0-9_]{2,23}$/.test(username)||username.startsWith('ife_'))return json({error:'Use 3–24 letters, numbers or underscores, starting with a letter. The ife_ prefix is reserved.'},400);
  await ensurePhoneProfiles();try{await db.batch([db.prepare('UPDATE account_identities SET username=? WHERE account_id=?').bind(username,me.id),db.prepare('UPDATE phone_profiles SET username=? WHERE user_id=?').bind(username,me.id)]);}catch(e){if(String(e).includes('UNIQUE'))return json({error:'That username is taken.'},409);throw e;}return json({ok:true,notice:'Your username is saved. Share it with your friends.'});
 }
 if(['phone-block','phone-unblock','phone-report','food-gift'].includes(b.op||'')){
  const target=typeof b.recipient==='string'?await db.prepare('SELECT id,name FROM students WHERE id=? AND id!=?').bind(b.recipient,me.id).first<{id:string;name:string}>():null;
  if(!target)return json({error:'Choose another student.'},400);
  if(b.op==='phone-unblock'){await db.prepare('DELETE FROM phone_blocks WHERE user_id=? AND target_id=?').bind(me.id,target.id).run();return json({ok:true,notice:'Player unblocked.'});}
  if(b.op==='phone-block'||b.op==='phone-report'){
   if(b.op==='phone-report'){
    if(typeof b.reason!=='string'||!['Harassment','Spam','Inappropriate messages','Other'].includes(b.reason))return json({error:'Choose a report reason.'},400);
    const recent=await db.prepare('SELECT id FROM phone_reports WHERE reporter=? AND target=? AND created>?').bind(me.id,target.id,now-86400000).first();if(!recent)await db.prepare('INSERT INTO phone_reports VALUES (?,?,?,?,?)').bind(crypto.randomUUID(),me.id,target.id,b.reason,now).run();
   }
   await db.batch([db.prepare('INSERT OR IGNORE INTO phone_blocks VALUES (?,?,?)').bind(me.id,target.id,now),db.prepare("UPDATE home_invites SET status='cancelled' WHERE ((host_id=? AND guest_id=?) OR (host_id=? AND guest_id=?)) AND status IN ('pending','accepted')").bind(me.id,target.id,target.id,me.id),db.prepare('DELETE FROM home_visits WHERE (host_id=? AND guest_id=?) OR (host_id=? AND guest_id=?)').bind(me.id,target.id,target.id,me.id)]);
   return json({ok:true,notice:b.op==='phone-report'?'Report saved and player blocked.':'Player blocked. Messages, invitations and gifts are disabled.'});
  }
  if(await phoneBlocked(me.id,target.id))return json({error:'You cannot send gifts to this player.'},403);
  const meal=meals.find(m=>m.id===b.meal);if(!meal)return json({error:'Choose a meal.'},400);
  const nonce=crypto.randomUUID();const result=await db.batch([
   db.prepare('UPDATE students SET money=money-?,last_action=?,action_nonce=? WHERE id=? AND money>=? AND last_action<?').bind(meal.price,now,nonce,me.id,meal.price,now-8000),
   db.prepare('UPDATE students SET hunger=MIN(100,hunger+?) WHERE id=? AND EXISTS(SELECT 1 FROM students WHERE id=? AND action_nonce=?)').bind(meal.hunger,target.id,me.id,nonce),
   db.prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,meal.name+' for '+target.name,-meal.price,now,me.id,nonce),
   db.prepare('INSERT INTO direct_messages (id,sender,recipient,body,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,target.id,'Sent you '+meal.name+' 🍚',now,me.id,nonce)
  ]);return result[0].meta.changes?json({ok:true,notice:meal.name+' delivered to '+target.name+'.'}):json({error:'Insufficient game money, or finish your last activity first.'},409);
 }
 if(b.op==='phone-read'){
  if(typeof b.conversation!=='string'||b.conversation.length>120)return json({error:'Choose a conversation.'},400);
  const [kind,...rest]=b.conversation.split(':'),id=rest.join(':');
  if(kind==='group'){if(!await db.prepare('SELECT user_id FROM phone_group_members WHERE group_id=? AND user_id=?').bind(id,me.id).first())return json({error:'You are not in this group.'},403);}
  else if(kind!=='dm'||id===me.id||!await db.prepare('SELECT id FROM students WHERE id=?').bind(id).first())return json({error:'Choose a student.'},400);
  await db.prepare('INSERT INTO phone_reads (user_id,conversation,read_at) VALUES (?,?,?) ON CONFLICT(user_id,conversation) DO UPDATE SET read_at=MAX(read_at,excluded.read_at)').bind(me.id,b.conversation,now).run();return json({ok:true});
 }
 if(b.op==='group-create'){
  const name=typeof b.name==='string'?b.name.trim():'';if(name.length<2||name.length>40||!Array.isArray(b.members))return json({error:'Name your group and choose students.'},400);
  const members=[...new Set(b.members)];if(members.length<1||members.length>7||members.some(id=>typeof id!=='string'||id===me.id))return json({error:'Choose between one and seven other students.'},400);
  for(const id of members)if(await phoneBlocked(me.id,String(id)))return json({error:'You cannot add a blocked player.'},403);
  for(const id of members)if(!await db.prepare('SELECT id FROM students WHERE id=?').bind(id).first())return json({error:'A selected student is no longer available.'},400);
  const count=await db.prepare('SELECT COUNT(*) AS total FROM phone_groups WHERE owner_id=? AND created>?').bind(me.id,now-86400000).first<{total:number}>();if((count?.total??0)>=10)return json({error:'You can create ten groups per day. Try again tomorrow.'},429);
  const id=crypto.randomUUID();await db.batch([db.prepare('INSERT INTO phone_groups (id,name,owner_id,created) VALUES (?,?,?,?)').bind(id,name,me.id,now),...[me.id,...members].map(user=>db.prepare('INSERT INTO phone_group_members (group_id,user_id) VALUES (?,?)').bind(id,user))]);return json({ok:true,notice:`${name} created. Your friends can find it in Messages.`});
 }
 if(b.op!=='group-chat'&&b.op!=='group-leave')return null;
 if(typeof b.group!=='string'||!await db.prepare('SELECT user_id FROM phone_group_members WHERE group_id=? AND user_id=?').bind(b.group,me.id).first())return json({error:'You are not in this group.'},403);
 if(b.op==='group-leave'){await db.prepare('DELETE FROM phone_group_members WHERE group_id=? AND user_id=?').bind(b.group,me.id).run();return json({ok:true,notice:'You left the group.'});}
 const body=typeof b.body==='string'?b.body.trim():'';if(!body||body.length>280)return json({error:'Write between 1 and 280 characters.'},400);
 const result=await db.batch([db.prepare('INSERT INTO phone_group_messages (id,group_id,sender,body,created) SELECT ?,?,id,?,? FROM students WHERE id=? AND last_chat<? AND EXISTS(SELECT 1 FROM phone_group_members WHERE group_id=? AND user_id=?)').bind(crypto.randomUUID(),b.group,body,now,me.id,now-3000,b.group,me.id),db.prepare('UPDATE students SET last_chat=?,last_seen=? WHERE id=? AND last_chat<?').bind(now,now,me.id,now-3000)]);
 if(!result[0].meta.changes)return json({error:'Wait a moment before your next message.'},429);return json({ok:true});
}
