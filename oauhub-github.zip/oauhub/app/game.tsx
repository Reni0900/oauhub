'use client';

import {useState,useEffect,useRef,useCallback} from 'react';

import {MapPin,MessageCircle,Users,Compass,BookOpen,Home,Plus,Minus,X,Send,Volume2,VolumeX,ChevronDown,GraduationCap,Wallet,Zap,Utensils,Check,LoaderCircle,Smartphone,Search,Shirt,HelpCircle,ArrowRight} from 'lucide-react';

import VenueView from './venue-view';

import {venueApps} from './campus-apps';

import AvatarPreview from './avatar-preview';

import {AvatarCustomizer} from './avatar-customizer';

import {defaultAppearance} from '../lib/appearance';

import {meals} from '../lib/hostel-life';

import HostelView from './hostel-view';

import GameHud,{SiteMetrics} from './game-hud';
import UpdateNotice from './update-notice';
import {reportActivity} from '../lib/activity-status';
import StudentPhone from './student-phone';

import {LifeState} from '../lib/hostel-life';

import AccountDialog from './account-dialog';

import CampusScene from './campus-scene';

import {locations,hostels,colors,arrival,Student,Message} from '../lib/campus';

import type {StudentOrigin} from '../lib/student-origin';

import type {HousingOption} from '../lib/housing';

import OriginReveal from './origin-reveal';

type World={metrics?:SiteMetrics;identity?:{username:string;display_name:string}|null;housingOptions?:HousingOption[];origin?:StudentOrigin|null;me:Student|null;players:Student[];messages:Message[]};

export default function Game({signedIn:initialSignedIn,localPreview=false}:{signedIn:boolean;signInPath?:string;localPreview?:boolean}){

 const [metrics,setMetrics]=useState<SiteMetrics|null>(null);
 const [search,setSearch]=useState('');const [help,setHelp]=useState(false);

 const [origin,setOrigin]=useState<StudentOrigin|null>(null);const [revealing,setRevealing]=useState(false);

 const [appearance,setAppearance]=useState({...defaultAppearance});const [venue,setVenue]=useState<string|null>(null);const [phoneApp,setPhoneApp]=useState('home');

 const [follow,setFollow]=useState(true);const [viewReset,setViewReset]=useState(0);const [opening,setOpening]=useState('');const [phone,setPhone]=useState(false);const [life,setLife]=useState<LifeState|null>(null);const closePhone=useCallback(()=>setPhone(false),[]);

 const [signedIn,setSignedIn]=useState(initialSignedIn);const [authMode,setAuthMode]=useState<'register'|'login'|null>(null);const closeAuth=useCallback(()=>setAuthMode(null),[]);

 const [world,setWorld]=useState<World>({me:null,players:[],messages:[]});const [loaded,setLoaded]=useState(!signedIn);const [error,setError]=useState('');const [notice,setNotice]=useState('');const [busy,setBusy]=useState(false);const [creating,setCreating]=useState(false);const [selected,setSelected]=useState<string|null>(null);const [panel,setPanel]=useState<'places'|'chat'|null>(null);const [zoom,setZoom]=useState(()=>typeof window!=='undefined'&&window.innerWidth<760?.65:.95);const [muted,setMuted]=useState(false);const [message,setMessage]=useState('');const [name,setName]=useState('');const [hall,setHall]=useState('awo');const [faculty,setFaculty]=useState('Science');const [color,setColor]=useState(colors[0]);const [filter,setFilter]=useState('all');

 const position=useRef({x:-15,z:20});const walk=useRef<{x:number;z:number}|null>(null);const current=useRef(world);current.current=world;const syncBusy=useRef(false);const initialized=useRef(false);const chatEnd=useRef<HTMLDivElement>(null);

 const api=useCallback(async(body?:object)=>{const r=await fetch('/api/game',body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{cache:'no-store'});const d=await r.json() as World & {error?:string;notice?:string;ok?:boolean};if(r.status===401){setSignedIn(false);setOrigin(null);setRevealing(false);setPhone(false);setLife(null);setVenue(null);setWorld({me:null,players:[],messages:[]});initialized.current=false;setCreating(false);setAuthMode('login');}if(!r.ok)throw new Error(d.error||'Campus connection interrupted.');return d;},[]);

 async function accountSuccess(mode:'register'|'login',assigned?:StudentOrigin){if(assigned){setOrigin(assigned);setHall(assigned.hostel);setRevealing(mode==='register');}initialized.current=false;setError('');setLoaded(false);setSignedIn(true);setAuthMode(null);if(mode==='register')setCreating(true);await refresh();}

 useEffect(()=>{let stopped=false;let visitorId=crypto.randomUUID();try{const saved=localStorage.getItem('oauhub-visitor');if(saved&&/^[a-f0-9-]{36}$/i.test(saved))visitorId=saved as `${string}-${string}-${string}-${string}-${string}`;else localStorage.setItem('oauhub-visitor',visitorId);}catch{}async function beat(){if(document.hidden)return;try{const d=await api({op:'presence',visitorId});if(!stopped&&d.metrics)setMetrics(d.metrics);}catch{}}void beat();const timer=setInterval(()=>void beat(),10000);document.addEventListener('visibilitychange',beat);return()=>{stopped=true;clearInterval(timer);document.removeEventListener('visibilitychange',beat);};},[api]);
 async function logout(){try{const r=await fetch('/api/account',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({op:'logout'})});if(!r.ok)throw new Error('Could not log out. Please try again.');setSignedIn(false);setOrigin(null);setRevealing(false);setPhone(false);setLife(null);setVenue(null);setWorld({me:null,players:[],messages:[]});initialized.current=false;walk.current=null;setCreating(false);setSelected(null);setLoaded(true);setError('');}catch(e){setError((e as Error).message);}}

const loadLife=useCallback(async()=>{try{const r=await fetch('/api/life',{cache:'no-store'});const data=await r.json() as LifeState&{error?:string};if(!r.ok)throw new Error(data.error);setLife(data);}catch(e){setError((e as Error).message);}},[]);

 async function lifeAction(body:object){setBusy(true);setError('');try{const r=await fetch('/api/life',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await r.json() as {me?:Student;error?:string;notice?:string};if(!r.ok)throw new Error(data.error);if(data.me){setWorld(w=>({...w,me:data.me!}));if(['transport','event-attend','housing-move','visit-accept','visit-leave'].includes((body as {op:string}).op)){position.current={x:data.me.x,z:data.me.z};walk.current=null;setVenue(null);setSelected(null);setPhone(false);setFollow(true);}}if(data.notice)setNotice(data.notice);const activity=body as {op:string;activity?:string;meal?:string};if(activity.op==='food')reportActivity('recent',`Eating ${meals.find(m=>m.id===activity.meal)?.name||'a meal'}`,12);if(activity.op==='venue-activity')reportActivity('recent',String((body as {venue?:string}).venue)==='sports'?'Playing football':'Studying',18);if(activity.op==='wellbeing')reportActivity('recent',activity.activity==='fitness'?'Working out':activity.activity==='clinic'?'Visiting the clinic':'Taking a quiet break',18);if(activity.op==='quiz')reportActivity('recent','Playing campus quiz',12);if(activity.op==='activity')reportActivity('recent',activity.activity?.replaceAll('-',' ')||'Enjoying hostel life',18);await loadLife();await refresh();return true;}catch(e){setError((e as Error).message);return false;}finally{setBusy(false);}}

 const refresh=useCallback(async()=>{try{const d=await api();if(d.me&&!initialized.current){position.current={x:d.me.x,z:d.me.z};initialized.current=true;}setWorld(d);setOrigin(d.origin??null);if(d.origin)setHall(d.origin.hostel);if(!d.me){if(d.identity)setName(d.identity.display_name);setCreating(true);}setLoaded(true);setError('');}catch(e){setError((e as Error).message);setLoaded(true);}},[api]);

 useEffect(()=>{if(signedIn)void refresh();},[signedIn,refresh]);

 useEffect(()=>{if(!signedIn||!world.me)return;let stopped=false;const tick=async()=>{if(syncBusy.current||document.hidden)return;syncBusy.current=true;try{await api({op:'move',...position.current});if(!stopped)await refresh();}catch(e){if(!stopped)setError((e as Error).message);}finally{syncBusy.current=false;}};void tick();const timer=setInterval(tick,3500);return()=>{stopped=true;clearInterval(timer);};},[!!world.me,signedIn,api,refresh]);

 useEffect(()=>{if(!notice)return;const t=setTimeout(()=>setNotice(''),5500);return()=>clearTimeout(t);},[notice]);

 useEffect(()=>{chatEnd.current?.scrollIntoView({block:'nearest'});},[world.messages.length,panel]);

 async function run(body:object){setBusy(true);setError('');try{const d=await api(body);if(d.me){if(!initialized.current){position.current={x:d.me.x,z:d.me.z};initialized.current=true;}setWorld(w=>({...w,me:d.me}));}if(d.notice)setNotice(d.notice);if((body as {op:string}).op==='action'){const place=locations.find(l=>l.id===(body as {location:string}).location);if(place)reportActivity('recent',place.id==='sports'?'Playing football':place.type==='academic'?'Studying':place.type==='hostel'?'Resting':'Hanging out',18);}return true;}catch(e){setError((e as Error).message);return false;}finally{setBusy(false);}}

 async function create(e:React.FormEvent){e.preventDefault();if(await run({op:'create',name,hostel:hall,faculty,color,appearance})){setCreating(false);setNotice('Welcome to Great Ife. Your story starts here.');await refresh();}}

 async function enterHostel(id:string){setVenue(null);if(!world.me){if(!signedIn)setAuthMode('register');else setCreating(true);return;}setOpening(locations.find(l=>l.id===id)?.short||'hostel');setPhone(false);setPanel(null);setSelected(null);walk.current=null;try{await lifeAction({op:'enter',hostel:id});}finally{setOpening('');}}

 async function exitHostel(){const l=locations.find(l=>l.id===world.me?.inside);if(l)position.current=arrival(l);await lifeAction({op:'exit'});}

 async function visit(id:string){setVenue(null);if(world.me?.inside)await exitHostel();if(!world.me){if(!signedIn)setAuthMode('register');else setCreating(true);return;}const l=locations.find(l=>l.id===id)!;walk.current=null;position.current=arrival(l);setSelected(id);await run({op:'move',...position.current});await refresh();}

 async function action(){if(!loc)return;if(venueApps[loc.id]){await openVenue(loc.id);return;}if(!world.me){if(!signedIn)setAuthMode('register');else setCreating(true);return;}if(loc.type==='hostel'){await enterHostel(loc.id);return;}walk.current=null;position.current=arrival(loc);if(loc.type==='food'){await lifeAction({op:'food',meal:'rice'});return;}await api({op:'move',...position.current}).catch(()=>{});await run({op:'action',location:loc.id});}

 async function send(e:React.FormEvent){e.preventDefault();if(!message.trim())return;const text=message;if(await run({op:'chat',body:text})){setMessage('');await refresh();}}

 useEffect(()=>{if(!signedIn||!world.me)return;void loadLife();const timer=setInterval(()=>{if(!document.hidden)void loadLife();},4000);return()=>clearInterval(timer);},[signedIn,!!world.me,loadLife]);

 const loc=locations.find(l=>l.id===selected);const me=world.me;const nearby=world.players.filter(p=>Math.hypot(p.x-position.current.x,p.z-position.current.z)<20);const messages=world.messages.filter(m=>Math.hypot(m.x-position.current.x,m.z-position.current.z)<20);const at=loc?Math.hypot(position.current.x-arrival(loc).x,position.current.z-arrival(loc).z)<9:false;

 function needStudent(){if(me)return true;if(!signedIn)setAuthMode('register');else setCreating(true);return false;}

 useEffect(()=>{if(world.me)setZoom(1.65);},[!!world.me]);

 useEffect(()=>{const close=(e:KeyboardEvent)=>{if(e.key==='Escape'&&!authMode&&!creating&&!phone){setSelected(null);setPanel(null);setHelp(false);}};window.addEventListener('keydown',close);return()=>window.removeEventListener('keydown',close);},[authMode,creating,phone]);

 function togglePhone(){setPhoneApp('home');setPhone(!phone);}

 async function openVenue(id:string){if(!world.me){setAuthMode('register');return;}await visit(id);setSelected(null);setPanel(null);setVenue(id);setPhone(false);}

 const select=(id:string)=>{const place=locations.find(l=>l.id===id);setPanel(null);if(!world.me){setSelected(id);return;}if(place?.type==='hostel'){void enterHostel(id);return;}if(venueApps[id]&&world.me){void openVenue(id);return;}setSelected(id);};const update=useCallback(()=>{},[]);

 useEffect(()=>{const ctx=(document as Document & {modelContext?:{registerTool:(t:unknown,o?:unknown)=>void}}).modelContext;if(!ctx?.registerTool)return;const life=new AbortController();try{ctx.registerTool({name:'inspect_campus',title:'Inspect OAU campus',description:'Read campus locations and the current student status without changing gameplay.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:true},execute:(input:unknown)=>{if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).length)throw new TypeError('This inspection tool takes an empty object.');return({locations:locations.map(l=>({id:l.id,name:l.name,activity:l.action})),student:current.current.me?{name:current.current.me.name,hostel:current.current.me.hostel,study:current.current.me.study}:null,online:current.current.players.length+(current.current.me?1:0)}); }},{signal:life.signal});}catch{}return()=>life.abort();},[]);

 return <main className="game-shell">

  {me?.inside?<HostelView key={`${me.inside}:${life?.visit?.id||'home'}`} me={me} life={life} busy={busy} onAction={lifeAction} onExit={()=>void exitHostel()} onPhone={(app='home')=>{setPhoneApp(app);setPhone(true);}}/>:venue&&me?<VenueView id={venue} me={me} life={life} busy={busy} onAction={lifeAction} onVisit={id=>void openVenue(id)} onExit={()=>setVenue(null)} onPhone={()=>togglePhone()} messages={messages} message={message} onMessage={setMessage} onSend={send}/>:<CampusScene me={me} players={world.players} zoom={zoom} selected={selected} follow={follow} viewReset={viewReset} onPan={()=>setFollow(false)} onSelect={select} onPosition={update} position={position} walk={walk}/>}

  <header className="topbar"><a className="brand" href="./" aria-label="OAUHub home"><span className="brand-mark"><GraduationCap size={25}/></span><div>OAU<span className="brand-life">Hub</span><small>LIVE YOUR GREAT IFE STORY</small></div></a><div className="campus-status"><span className={me&&!error?'online-dot':'offline-dot'}/>{me?world.players.length+1:world.players.length} on campus<span className="divider"/>Ile-Ife, Nigeria</div><div className="top-actions"><span className="alpha-badge">{localPreview?'PREVIEW':'FREE TO PLAY'}</span>{me?<button className="profile-button" onClick={()=>void enterHostel(me.hostel)}><span style={{background:me.color}}>{me.name.charAt(0).toUpperCase()}</span>{me.name}<ChevronDown size={15}/></button>:signedIn?<button className="primary small" onClick={()=>setCreating(true)}>Create student</button>:<><button className="auth-link" onClick={()=>setAuthMode('login')}>Log in</button><button className="primary small" onClick={()=>setAuthMode('register')}>Create account</button></>}{signedIn&&<button className="auth-link" onClick={()=>void logout()}>Log out</button>}</div></header>

  {!me?.inside&&!venue&&<><nav className="explore-strip" aria-label="Quick campus destinations"><button onClick={()=>{setPanel('places');setFilter('all');}}><Compass size={15}/>Explore campus</button><button onClick={()=>{setPanel('places');setFilter('hostel');}}><Home size={15}/>Hostels</button><button onClick={()=>{if(needStudent()){setPhoneApp('style');setPhone(true);}}}><Shirt size={15}/>Fashion</button><button className={help?'active':''} aria-label="How to play" onClick={()=>setHelp(!help)}><HelpCircle size={15}/><span>How to play</span></button></nav>

  {!me&&!selected&&!panel&&<div className="campus-welcome"><span className="eyebrow">WELCOME TO GREAT IFE</span><h1>A little campus.<br/>A whole lot of life.</h1><p>Tap a place. Find your hall.<br/>Make this story yours.</p><button onClick={()=>{setPanel('places');setFilter('all');}}><Compass size={15}/>Find a place<ArrowRight size={15}/></button></div>}

  {help&&<section className="how-to-play" aria-label="How to play"><button className="icon-button" aria-label="Close how to play" onClick={()=>setHelp(false)}><X size={18}/></button><span className="eyebrow">YOUR FIRST DAY</span><h2>Campus, made simple.</h2><ol><li><strong>Create your student</strong><span>Sign up, discover your background and assigned hostel, then style your avatar.</span></li><li><strong>Go somewhere</strong><span>Drag the map to look around. Tap a building to visit or the ground to walk; use WASD on a keyboard. My avatar brings the view back to you.</span></li><li><strong>Make yourself at home</strong><span>Enter a hostel for rooms and activities. Open Phone for food, Fashion and friends.</span></li></ol></section>}

  <nav className="tool-rail" aria-label="Game panels"><button className={panel==='places'?'active':''} aria-label="Campus places" aria-expanded={panel==='places'} onClick={()=>setPanel(panel==='places'?null:'places')}><Compass/><span>Places</span></button><button className={panel==='chat'?'active':''} aria-label="Nearby chat" aria-expanded={panel==='chat'} onClick={()=>setPanel(panel==='chat'?null:'chat')}><MessageCircle/><span>Chat</span>{nearby.length>0&&<i>{nearby.length}</i>}</button><button aria-label="Visit your hostel" onClick={()=>{if(needStudent())void enterHostel(me!.hostel);}}><Home/><span>Hostel</span></button></nav>

  {panel&&<aside className="side-panel"><div className="panel-header"><div><span className="eyebrow">{panel==='places'?'EXPLORE GREAT IFE':'MEET YOUR PEOPLE'}</span><h2>{panel==='places'?'Where to next?':'Nearby chat'}</h2></div><button className="icon-button" aria-label="Close panel" onClick={()=>setPanel(null)}><X size={18}/></button></div>

   {panel==='places'?<><label className="place-search"><Search size={17}/><input aria-label="Search campus places" placeholder="Search halls, food, places…" value={search} onChange={e=>setSearch(e.target.value)}/>{search&&<button aria-label="Clear place search" onClick={()=>setSearch('')}><X size={15}/></button>}</label><div className="filters">{[['all','All'],['academic','Study'],['hostel','Hostels'],['social','Campus life']].map(([id,label])=><button key={id} className={filter===id?'selected':''} onClick={()=>setFilter(id)}>{label}</button>)}</div><div className="places-list">{locations.filter(l=>(filter==='all'||l.type===filter)&&`${l.name} ${l.short} ${l.action}`.toLowerCase().includes(search.toLowerCase().trim())).map(l=><button key={l.id} className={`place-row ${selected===l.id?'selected':''}`} onClick={()=>select(l.id)}><span className={`place-icon ${l.type}`}>{l.type==='hostel'?<Home size={19}/>:l.type==='academic'?<BookOpen size={19}/>:l.type==='food'?<Utensils size={19}/>:<Users size={19}/>}</span><span><strong>{l.short}</strong><small>{l.type==='hostel'?'Hall of residence':l.type==='academic'?'Learning & culture':l.type==='food'?'Food & a little gist':'Campus life'}</small></span>{me?.hostel===l.id&&<span className="home-badge">HOME</span>}</button>)}{!locations.some(l=>(filter==='all'||l.type===filter)&&`${l.name} ${l.short} ${l.action}`.toLowerCase().includes(search.toLowerCase().trim()))&&<p className="no-places">No places found. Try a hall name or clear your search.</p>}</div><div className="panel-footer"><MapPin size={14}/>Real names. A playful campus layout.</div></>:<><div className="chat-context"><Users size={16}/>{nearby.length} other {nearby.length===1?'student':'students'} nearby<button className="icon-button" aria-label={muted?'Unmute chat':'Mute chat'} onClick={()=>setMuted(!muted)}>{muted?<VolumeX size={16}/>:<Volume2 size={16}/>}</button></div><div className="chat-feed" role="log" aria-label="Nearby messages">{muted?<p className="empty-chat">Chat is muted. You can keep exploring.</p>:messages.length?messages.map(m=><div key={m.id} className="chat-message"><strong>{m.name}<time>{new Date(m.created).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</time></strong><p>{m.body}</p></div>):<div className="empty-chat"><MessageCircle size={30}/><h3>A little quiet here.</h3><p>Messages from students near you appear here. Head to the amphitheatre to meet up.</p></div>}<div ref={chatEnd}/></div><form onSubmit={send} className="chat-compose"><input aria-label="Chat message" placeholder={me?'Say something…':'Join campus to chat'} maxLength={280} value={message} onChange={e=>setMessage(e.target.value)} disabled={!me||muted}/><button aria-label="Send message" disabled={!me||busy||muted||!message.trim()}><Send size={18}/></button></form><div className="panel-footer">Nearby means within your part of campus. Be kind.</div></>}

  </aside>}

  <button className="phone-launch" aria-label="Open student phone" onClick={()=>{if(needStudent())togglePhone();}}><Smartphone size={22}/><span>Phone</span></button>

  <div className="map-controls"><button aria-label="Zoom in" onClick={()=>setZoom(z=>Math.min(3,z+.2))}><Plus size={19}/></button><button aria-label="Zoom out" onClick={()=>setZoom(z=>Math.max(.6,z-.15))}><Minus size={19}/></button><button aria-label="Campus overview" onClick={()=>{setFollow(false);setViewReset(n=>n+1);setZoom(1);}}><Compass size={19}/></button></div>

  {loc&&<section className="location-card interactive-location"><div className="location-title"><span className={`place-icon ${loc.type}`}><MapPin size={21}/></span><div><span className="eyebrow">{loc.type==='hostel'?'HALL OF RESIDENCE':loc.type==='academic'?'LEARNING & CULTURE':'CAMPUS LIFE'}</span><h2>{loc.name}</h2></div><button aria-label="Close location" className="icon-button" onClick={()=>setSelected(null)}><X size={18}/></button></div><p>{loc.description}</p>{!me&&<div className="guest-place-note"><GraduationCap size={18}/><span>Create your student to {loc.type==='hostel'?'explore blocks, choose a room and meet roommates':'join activities and meet other students here'}.</span></div>}<div className="location-actions"><button className="secondary" disabled={busy} onClick={()=>loc.type==='hostel'?void enterHostel(loc.id):void visit(loc.id)}>{!me?'Join to visit':loc.type==='hostel'?'Enter hostel':'Visit location'}</button><button className="primary" disabled={busy} onClick={()=>{if(needStudent())void action();}}>{busy?<LoaderCircle size={16} className="spin"/>:null}{!me?'Create your student':loc.id==='sports'?'Play football':loc.action}</button></div>{me&&loc.type==='food'&&<div className="location-menu">{meals.map(m=><button key={m.id} disabled={busy||!!me&&me.money<m.price} onClick={()=>me?void lifeAction({op:'food',meal:m.id}):setCreating(true)}><Utensils size={17}/>{m.name}<strong>{'\u20a6'}{m.price}</strong></button>)}</div>}{me&&loc.type==='social'&&<button className="location-chat" onClick={()=>{setPanel('chat');setSelected(null);void visit(loc.id);}}>Meet students here - Open chat</button>}</section>}

  {!me&&!creating&&<section className="join-card"><span className="join-icon"><GraduationCap size={30}/></span><div><h2>Your next chapter starts here.</h2><p>Your avatar, your hostel, your people. Free to play.</p></div>{signedIn?<button className="primary" disabled={!loaded} onClick={()=>setCreating(true)}>{loaded?'Create your student':'Connecting…'}</button>:<div className="join-actions"><button className="primary" onClick={()=>setAuthMode('register')}>Create account <ArrowRight size={16}/></button><button className="secondary" onClick={()=>setAuthMode('login')}>Log in</button></div>}</section>}

  </>}

  {(me?.inside||venue)&&<button className="phone-launch" aria-label="Open student phone" onClick={()=>togglePhone()}><Smartphone size={22}/><span>Phone</span></button>}

  {me&&!me.inside&&!venue&&<div className="play-dock"><button onClick={()=>{setFollow(true);setViewReset(n=>n+1);setZoom(1.8);setSelected(null);setPanel(null);}}><Users size={19}/>My avatar</button><button onClick={()=>void enterHostel(me.hostel)}><Home size={19}/>Hostel</button><button onClick={()=>togglePhone()}><Smartphone size={19}/>Phone</button><button onClick={()=>{setPanel(panel==='places'?null:'places');setFollow(false);setViewReset(n=>n+1);setZoom(1);}}><Compass size={19}/>Campus</button><button aria-label="Nearby chat" aria-expanded={panel==='chat'} onClick={()=>setPanel(panel==='chat'?null:'chat')}><MessageCircle size={19}/>Chat</button><button aria-label="How to play" onClick={()=>setHelp(!help)}><HelpCircle size={19}/>Help</button></div>}

  {opening&&<div className="opening-hostel" role="status"><LoaderCircle className="spin" size={26}/><strong>Entering {opening}...</strong></div>}

  {me&&<section className="student-bar" aria-label="Student stats"><div className="student-identity"><AvatarPreview color={me.color} appearance={me.appearance} name={me.name}/><div><strong>{me.name}</strong><small>100 level · {me.faculty}</small></div></div><div className="stat"><Wallet size={18}/><span><small>Allowance</small><strong>₦{me.money.toLocaleString()}</strong></span></div><div className="stat meter"><Zap size={18}/><span><small>Energy {me.energy}%</small><progress max={100} value={me.energy}/></span></div><div className="stat meter"><Utensils size={18}/><span><small>Hunger {me.hunger}%</small><progress max={100} value={me.hunger}/></span></div><div className="stat"><BookOpen size={18}/><span><small>Study points</small><strong>{me.study}</strong></span></div></section>}

  {me&&!venue&&!me.inside&&<nav className="campus-shortcuts" aria-label="Campus life shortcuts">{[['elections','🗳️ Union'],['events','🎭 Events'],['jobs','💼 Jobs'],['shop','🛍️ Shop']].map(([id,label])=><button key={id} onClick={()=>{setPhoneApp(id);setPhone(true);}}>{label}</button>)}{life?.campus.policy&&<span>{life.campus.policy==='transport'?'🚐 Shuttle support':life.campus.policy==='food'?'🍲 Meal support':'📚 Study support'} active</span>}</nav>}

  <footer className="game-footer"><span><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> to move <span className="desktop-tip">· click the ground to walk</span></span><span>Unofficial OAU student-life game <a href="https://oauife.edu.ng/student-affairs/" target="_blank" rel="noreferrer">Campus names</a></span></footer>

  {(error||notice)&&<div className={`toast ${error?'error':''}`} role={error?'alert':'status'}>{error||notice}{error&&signedIn&&<button onClick={()=>void refresh()}>Retry</button>}<button aria-label="Dismiss message" onClick={()=>{setError('');setNotice('');}}><X size={16}/></button></div>}

  {revealing&&origin&&<OriginReveal origin={origin} onContinue={()=>{setRevealing(false);setCreating(true);}}/>}

  {creating&&!revealing&&<div className="modal-backdrop"><section className="create-modal student-creator" role="dialog" aria-modal="true" aria-labelledby="create-title"><button aria-label="Close student creation" className="modal-close icon-button" onClick={()=>setCreating(false)}><X size={20}/></button><span className="eyebrow">WELCOME, FRESHER</span><h2 id="create-title">Every story starts<br/>with <em>you.</em></h2><p>Customise your style and choose your first home. Your campus story awaits.</p>{!signedIn?<button className="primary" onClick={()=>{setCreating(false);setAuthMode('register');}}>Create an account to become a student</button>:<form onSubmit={create}><label>Display name<input required minLength={2} maxLength={24} value={name} readOnly={!!world.identity} placeholder="Your campus name" onChange={e=>setName(e.target.value)} autoFocus/>{world.identity&&<small>@{world.identity.username} · Set during account creation</small>}</label><div className="form-grid"><label>Your first home<select value={hall} onChange={e=>setHall(e.target.value)}>{(world.housingOptions??[]).filter(h=>h.eligible).map(h=><option key={h.id} value={h.id} disabled={h.fee!==null&&h.fee>(origin?.startingMoney??5000)}>{h.name}{h.id===origin?.hostel?' · Allocated':''} · {h.fee===null?'Fee pending':`₦${h.fee.toLocaleString()} / semester`}</option>)}</select></label><label>Your faculty<select value={faculty} onChange={e=>setFaculty(e.target.value)}>{['Science','Arts','Administration','Education','Law','Social Sciences','Technology','Agriculture','Environmental Design & Management','Pharmacy','Health Sciences'].map(f=><option key={f}>{f}</option>)}</select></label></div><p className="create-note">First semester fee: ₦{world.housingOptions?.find(h=>h.id===hall)?.fee?.toLocaleString()??'Pending'}. Balance after payment: ₦{Math.max(0,(origin?.startingMoney??5000)-(world.housingOptions?.find(h=>h.id===hall)?.fee??0)).toLocaleString()}. {((world.housingOptions?.find(h=>h.id===hall)?.fee??0)>(origin?.startingMoney??5000))?'Choose an affordable home to enter campus.':'You can move later using the Housing app.'}</p><AvatarCustomizer color={color} appearance={appearance} name={name||'Your avatar'} onChange={(a,c)=>{setAppearance(a);setColor(c);}}/><div className="starter-gift"><Wallet size={18}/><span>{origin?.background==='nepo'?'Nepo baby':origin?.background==='lapo'?'Lapo baby':'Your starter allowance'}: <strong>₦{(origin?.startingMoney??5000).toLocaleString('en-NG')}</strong><small>Your first semester housing fee is deducted before you enter campus. You can choose another affordable home.</small></span></div><button className="primary enter-campus" disabled={busy||!loaded||!!error||(world.housingOptions?.find(h=>h.id===hall)?.fee??Infinity)>(origin?.startingMoney??5000)}>{busy?'Saving your student…':'Enter campus'}</button><small className="create-note">{localPreview?'Progress is saved on this computer for the preview.':'Your progress is saved to your signed-in account.'}</small></form>}</section></div>}

 {phone&&me&&<StudentPhone key={phoneApp} initialApp={phoneApp} me={me} life={life} busy={busy} onAction={lifeAction} onRoom={()=>void enterHostel(me.hostel)} onVisit={id=>{setPhone(false);if(locations.find(l=>l.id===id)?.type==='hostel')void enterHostel(id);else if(venueApps[id])void openVenue(id);else void visit(id);}} onClose={closePhone}/>}

 <GameHud me={me} life={life} metrics={metrics} busy={busy} onJobs={()=>{if(needStudent()){setPhoneApp('jobs');setPhone(true);}}}/><UpdateNotice busy={busy}/>
 {authMode&&<AccountDialog mode={authMode} onMode={setAuthMode} onClose={closeAuth} onSuccess={accountSuccess}/>}

 </main>;

}











