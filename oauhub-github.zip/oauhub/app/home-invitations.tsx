'use client';
import {Home,Users} from 'lucide-react';
import {hostels} from '../lib/campus';
import {HomeInvite} from '../lib/hostel-life';
export default function HomeInvitations({invites,me,busy,onAction}:{invites:HomeInvite[];me:string;busy:boolean;onAction:(body:object)=>Promise<boolean>}){
 return <div className="home-invitations">{invites.map(i=>{const incoming=i.guest_id===me,pending=i.status==='pending'&&i.expires_at>Date.now(),active=i.status==='accepted'&&(i.visit_until||0)>Date.now(),status=pending?'Waiting for a reply':active?'Visit in progress':i.status==='pending'?'Invitation expired':i.status==='accepted'?'Visit finished':i.status==='cancelled'?'Ended by host':'Declined';return <article className={`home-invite ${incoming?'incoming':''}`} key={i.id}>
  <span className="home-invite-icon"><Home size={20}/></span><div><strong>{incoming?`${i.host_name} invited you over`:`You invited ${i.guest_name}`}</strong><p>{hostels.find(h=>h.id===i.hostel)?.short} · {i.block}{i.room}</p><small>{status}{pending?' · expires in 30 minutes from sending':''}</small></div>
  {pending&&<div className="home-invite-actions">{incoming?<><button className="primary small" disabled={busy} onClick={()=>void onAction({op:'visit-accept',invite:i.id})}><Users size={14}/>Accept & visit</button><button className="secondary small" disabled={busy} onClick={()=>void onAction({op:'visit-decline',invite:i.id})}>Decline</button></>:<button className="secondary small" disabled={busy} onClick={()=>void onAction({op:'visit-cancel',invite:i.id})}>Cancel invitation</button>}</div>}
  {active&&!incoming&&<button className="secondary small" disabled={busy} onClick={()=>void onAction({op:'visit-cancel',invite:i.id})}>End visit</button>}
 </article>;})}</div>;
}
