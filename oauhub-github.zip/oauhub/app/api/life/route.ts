import {roomItems,roomDecorAction} from '../../../lib/room-decor';
import {phoneState,phoneAction,ensurePhoneProfiles,phoneBlocked} from '../../../lib/phone-messaging';
import {currentVisit,homeInvitations,homeChannel,visitAction} from '../../../lib/home-visits';
import {readOrigin} from '../../../lib/account-origin';
import {isApartment,roomCapacity} from '../../../lib/interior-layout';
import {housingState,housingAction} from '../../../lib/housing-actions';
import {authDb,getCampusUser,sameOrigin} from '../../../lib/account-auth';
import {hostels,arrival,Student} from '../../../lib/campus';
import {blocks,roomNumbers,meals,activities} from '../../../lib/hostel-life';
import {campusAction,campusState} from '../../../lib/campus-actions';
export const dynamic='force-dynamic';
const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
const readStudent=(id:string)=>authDb().prepare('SELECT * FROM students WHERE id=?').bind(id).first<Student>();
const channel=(s:Student)=>`${s.hostel}:${s.block}:${s.room}`;
export async function GET(request:Request){try{
 const user=await getCampusUser(request.headers.get('cookie'));if(!user)return json({error:'Log in to use your phone.'},401);
 const me=await readStudent(user.userId);if(!me)return json({error:'Create your student first.'},400);
 const hall=new URL(request.url).searchParams.get('hostel')||me.inside||me.hostel;if(!hostels.some(h=>h.id===hall))return json({error:'Choose a hostel.'},400);
 await ensurePhoneProfiles();const visit=await currentVisit(me),home=visit||me;const db=authDb();const [residents,roomMessages,contacts,directMessages,wallet]=await Promise.all([
 db.prepare(`SELECT id,name,color,appearance,block,room,last_seen,CASE WHEN EXISTS (SELECT 1 FROM home_visits v WHERE v.guest_id=students.id AND v.expires_at>?) THEN '' ELSE inside END AS inside FROM students WHERE hostel=? AND room>0 ORDER BY block,room LIMIT 192`).bind(Date.now(),hall).all(),
 (visit||me.room&&me.inside===me.hostel)?db.prepare('SELECT id,user_id,name,body,created FROM room_messages WHERE channel=? ORDER BY created DESC LIMIT 60').bind(homeChannel(home)).all():Promise.resolve({results:[]}),
 db.prepare('SELECT s.id,s.name,s.color,s.appearance,s.hostel,s.last_seen,p.username FROM students s JOIN phone_profiles p ON p.user_id=s.id WHERE s.id!=? AND (EXISTS(SELECT 1 FROM direct_messages d WHERE (d.sender=s.id AND d.recipient=?) OR (d.recipient=s.id AND d.sender=?)) OR EXISTS(SELECT 1 FROM home_invites i WHERE (i.host_id=s.id AND i.guest_id=?) OR (i.guest_id=s.id AND i.host_id=?)) OR EXISTS(SELECT 1 FROM room_messages r JOIN room_messages mine ON mine.channel=r.channel WHERE r.user_id=s.id AND mine.user_id=?) OR EXISTS(SELECT 1 FROM phone_group_members g JOIN phone_group_members mine ON mine.group_id=g.group_id WHERE g.user_id=s.id AND mine.user_id=?)) ORDER BY s.last_seen DESC').bind(me.id,me.id,me.id,me.id,me.id,me.id,me.id).all(),
 db.prepare('SELECT d.*,s.name AS sender_name,r.name AS recipient_name FROM direct_messages d JOIN students s ON s.id=d.sender JOIN students r ON r.id=d.recipient WHERE d.sender=? OR d.recipient=? ORDER BY d.created DESC LIMIT 100').bind(me.id,me.id).all(),
 db.prepare('SELECT id,label,amount,created FROM wallet_entries WHERE user_id=? ORDER BY created DESC LIMIT 30').bind(me.id).all()]);
 const guests=await db.prepare(`SELECT s.id,s.name,s.color,s.appearance,v.block,v.room,s.last_seen,s.inside,1 AS visitor FROM home_visits v JOIN students s ON s.id=v.guest_id JOIN students h ON h.id=v.host_id LEFT JOIN housing_leases l ON l.user_id=h.id WHERE v.hostel=? AND v.expires_at>? AND s.inside=v.hostel AND h.hostel=v.hostel AND h.block=v.block AND h.room=v.room AND (l.paid_until IS NULL OR l.paid_until>?)`).bind(hall,Date.now(),Date.now()).all();
 return json({decor:(visit||me.room&&me.inside===me.hostel)?await roomItems(home):[],phone:await phoneState(me.id),visit,invites:await homeInvitations(me),housing:await housingState(me.id),residents:[...residents.results,...guests.results],roomMessages:roomMessages.results.reverse(),contacts:contacts.results,directMessages:directMessages.results.reverse(),wallet:wallet.results,campus:await campusState(me)});
 }catch(e){console.error('Student life read failed',e);return json({error:'Student life is temporarily unavailable. Please retry.'},503);}}
export async function POST(request:Request){try{
 if(!sameOrigin(request))return json({error:'Please use the campus page.'},403);
 const user=await getCampusUser(request.headers.get('cookie'));if(!user)return json({error:'Log in to continue.'},401);
 const raw=await request.text();if(raw.length>4096)return json({error:'Request too large.'},413);let b;try{b=JSON.parse(raw);}catch{return json({error:'Invalid request.'},400);}if(!b||typeof b!=='object')return json({error:'Invalid request.'},400);
 const db=authDb(),me=await readStudent(user.userId),now=Date.now();if(!me)return json({error:'Create your student first.'},400);
 if(['dm','transfer','visit-invite','food-gift'].includes(b.op)&&typeof b.recipient==='string'&&await phoneBlocked(me.id,b.recipient))return json({error:'This player connection is blocked.'},403);
 if(b.op==='visit-accept'&&typeof b.invite==='string'){const i=await db.prepare('SELECT host_id FROM home_invites WHERE id=? AND guest_id=?').bind(b.invite,me.id).first<{host_id:string}>();if(i&&await phoneBlocked(me.id,i.host_id))return json({error:'This player connection is blocked.'},403);}
 const phone=await phoneAction(b,me,now);if(phone)return phone;
 const visiting=await currentVisit(me,now);const visitingAction=await visitAction(b,me,now);if(visitingAction)return visitingAction;
 const housing=await housingAction(b,me,now);if(housing){if(housing.status<400&&b.op==='housing-move')await db.prepare('DELETE FROM home_visits WHERE guest_id=?').bind(me.id).run();return housing;}
 const housingTerm=(await housingState(me.id)).lease;
 if(housingTerm&&housingTerm.paid_until<=now&&(b.op==='cook'||b.op==='room'||(b.op==='room-chat'&&!visiting)||(b.op==='activity'&&( ['sleep','study'].includes(b.activity)||b.activity==='gist'&&!visiting))))return json({error:'Your housing semester has ended. Open Housing on your phone to renew or move to an affordable home.'},402);
 const decor=await roomDecorAction(b,me,!!visiting,housingTerm?.paid_until??null,now);if(decor)return decor;
 const campus=await campusAction(b,me,now);if(campus)return campus;
 if(b.op==='enter'||b.op==='exit'){
  const hall=hostels.find(h=>h.id===(b.op==='exit'?me.inside:b.hostel));if(!hall)return json({error:'Choose a hostel.'},400);if(b.op==='enter'&&hall.id==='maintenance'&&(await readOrigin(me.id))?.gender!=='female')return json({error:'Maintenance is a female-only hostel.'},403);const p=arrival(hall);
  await db.prepare('DELETE FROM home_visits WHERE guest_id=?').bind(me.id).run();
  await db.prepare('UPDATE students SET inside=?,x=?,z=?,last_seen=? WHERE id=?').bind(b.op==='exit'?'':hall.id,p.x,p.z,now,me.id).run();
  return json({me:await readStudent(me.id)});
 }
 if(b.op==='room'){
  if(visiting||me.inside!==me.hostel)return json({error:'Enter your own hostel to choose your room.'},400);
  if(!blocks.includes(b.block)||!roomNumbers.includes(b.room))return json({error:'Choose a valid block and room.'},400);
  const result=await db.prepare('UPDATE students SET block=?,room=?,last_seen=? WHERE id=? AND (SELECT COUNT(*) FROM students WHERE hostel=? AND block=? AND room=? AND id!=?)<?').bind(b.block,b.room,now,me.id,me.hostel,b.block,b.room,me.id,roomCapacity(me.hostel)).run();
  if(!result.meta.changes)return json({error:isApartment(me.hostel)?'This apartment is occupied. Choose another one.':'This room is full. Choose another room.'},409);return json({me:await readStudent(me.id),notice:isApartment(me.hostel)?`You moved into Apartment ${b.block}${b.room}.`:`You moved into Block ${b.block}, Room ${b.room}.`});
 }
 if(b.op==='dm'||b.op==='room-chat'){
  const body=typeof b.body==='string'?b.body.trim():'';if(!body||body.length>280)return json({error:'Write between 1 and 280 characters.'},400);
  if(b.op==='room-chat'&&(!visiting&&(!me.room||me.inside!==me.hostel)))return json({error:'Enter your own room or an invited home to chat.'},403);
  if(b.op==='dm'&&(typeof b.recipient!=='string'||b.recipient===me.id||!await readStudent(b.recipient)))return json({error:'Choose another student.'},400);
  const insert=b.op==='dm'?db.prepare('INSERT INTO direct_messages (id,sender,recipient,body,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND last_chat<?').bind(crypto.randomUUID(),b.recipient,body,now,me.id,now-3000):db.prepare('INSERT INTO room_messages (id,channel,user_id,name,body,created) SELECT ?,?,id,name,?,? FROM students WHERE id=? AND last_chat<?').bind(crypto.randomUUID(),homeChannel(visiting||me),body,now,me.id,now-3000);
  const result=await db.batch([insert,db.prepare('UPDATE students SET last_chat=?,last_seen=? WHERE id=? AND last_chat<?').bind(now,now,me.id,now-3000)]);
  if(!result[0].meta.changes)return json({error:'Wait a moment before your next message.'},429);return json({ok:true});
 }
 if(b.op==='activity'||b.op==='food'||b.op==='cook'){
  const cooking=b.op==='cook';
  if(cooking&&(visiting||!me.room||me.inside!==me.hostel))return json({error:'Choose and enter your own room or apartment before using the kitchen.'},403);
  const food=b.op==='food'||cooking?meals.find(m=>m.id===b.meal):null;const activity=b.op==='activity'?activities.find(a=>a.id===b.activity):null;
  if(!food&&!activity)return json({error:'Choose a valid activity or meal.'},400);
  if(activity&&!me.inside)return json({error:'Enter a hostel to do this activity.'},400);
  if(activity&&((['sleep','study'].includes(activity.id)&&(visiting||!me.room||me.inside!==me.hostel))||(activity.id==='gist'&&!visiting&&(!me.room||me.inside!==me.hostel))))return json({error:'Choose a room in your hostel first.'},400);
  const support=food&&!cooking?(await campusState(me)).policy==='food':false;
  const cost=food?Math.max(0,food.price-(support?100:0)):0,id=activity?.id;const energy=id==='sleep'?30:id==='study'?-10:id==='football'?-12:id==='laundry'?-5:0;
  const required=Math.max(0,-energy);if(me.money<cost)return json({error:'You do not have enough game money for this meal.'},400);if(me.energy<required)return json({error:'Rest before this activity.'},400);
  const hunger=food?.hunger??(id==='football'?-8:id==='sleep'?-5:0),hygiene=id==='shower'?35:id==='laundry'?15:id==='football'?-8:0,social=id==='gist'?15:id==='football'?12:0,study=id==='study'?8:0,nonce=crypto.randomUUID();
  const statements=[db.prepare('UPDATE students SET money=money-?,energy=MIN(100,MAX(0,energy+?)),hunger=MIN(100,MAX(0,hunger+?)),hygiene=MIN(100,MAX(0,hygiene+?)),social=MIN(100,MAX(0,social+?)),study=study+?,last_action=?,last_seen=?,action_nonce=? WHERE id=? AND money>=? AND energy>=? AND last_action<?').bind(cost,energy,hunger,hygiene,social,study,now,now,nonce,me.id,cost,required,now-8000)];
  if(food)statements.push(db.prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,cooking?`Kitchen ingredients · ${food.name}`:food.name,-cost,now,me.id,nonce));
  if(id==='gist')statements.push(db.prepare('INSERT INTO room_messages (id,channel,user_id,name,body,created) SELECT ?,?,?,?, ?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,homeChannel(visiting||me),'npc-moyo','Moyo · campus character',['Lectures were packed today! Want to study together later?','Jollof or amala? I am heading to the canteen after this.','A quick match in the courtyard would be nice.'][Math.floor(Math.random()*3)],now,me.id,nonce));
  const result=await db.batch(statements);if(!result[0].meta.changes)return json({error:'Finish your last activity first. Try again in a few seconds.'},429);
  return json({me:await readStudent(me.id),notice:food?cooking?`${food.name} cooked and served. Your hunger meter is replenished.`:`${food.name} delivered. Enjoy your meal!`:id==='shower'?'Fresh and ready for campus.':id==='sleep'?'Rested and recharged.':id==='study'?'You earned 8 study points.':id==='football'?'Good game! Your social meter increased.':id==='laundry'?'Clean clothes, sorted.':isApartment(me.hostel)?'Relaxed at home. Moyo left you a message.':'Your roommates have something to say. Check room chat.'});
 }
 return json({error:'Unknown student life action.'},400);
 }catch(e){console.error('Student life save failed',e);return json({error:'Could not save that. Please try again.'},503);}}
