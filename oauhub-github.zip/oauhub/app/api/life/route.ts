import {readOrigin} from '../../../lib/account-origin';
import {authDb,getCampusUser,sameOrigin} from '../../../lib/account-auth';
import {hostels,arrival,Student} from '../../../lib/campus';
import {blocks,roomNumbers,meals,activities} from '../../../lib/hostel-life';
import {campusAction,campusState} from '../../../lib/campus-actions';
export const dynamic='force-dynamic';
const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
const readStudent=(id:string)=>authDb().prepare('SELECT * FROM students WHERE id=?').bind(id).first<Student>();
const channel=(s:Student)=>`${s.hostel}:${s.block}:${s.room}`;
export async function GET(request:Request){try{
 const user=await getCampusUser(request.headers.get('cookie'));if(!user)return json({error:'Log in to use your phone.'},401);
 const me=await readStudent(user.userId);if(!me)return json({error:'Create your student first.'},400);
 const hall=new URL(request.url).searchParams.get('hostel')||me.inside||me.hostel;if(!hostels.some(h=>h.id===hall))return json({error:'Choose a hostel.'},400);
 const db=authDb();const [residents,roomMessages,contacts,directMessages,wallet]=await Promise.all([
 db.prepare('SELECT id,name,color,appearance,block,room,last_seen,inside FROM students WHERE hostel=? AND room>0 ORDER BY block,room LIMIT 192').bind(hall).all(),
 me.room&&me.inside===me.hostel?db.prepare('SELECT id,user_id,name,body,created FROM room_messages WHERE channel=? ORDER BY created DESC LIMIT 60').bind(channel(me)).all():Promise.resolve({results:[]}),
 db.prepare('SELECT id,name,color,hostel,last_seen FROM students WHERE id!=? ORDER BY last_seen DESC LIMIT 100').bind(me.id).all(),
 db.prepare('SELECT d.*,s.name AS sender_name,r.name AS recipient_name FROM direct_messages d JOIN students s ON s.id=d.sender JOIN students r ON r.id=d.recipient WHERE d.sender=? OR d.recipient=? ORDER BY d.created DESC LIMIT 100').bind(me.id,me.id).all(),
 db.prepare('SELECT id,label,amount,created FROM wallet_entries WHERE user_id=? ORDER BY created DESC LIMIT 30').bind(me.id).all()]);
 return json({residents:residents.results,roomMessages:roomMessages.results.reverse(),contacts:contacts.results,directMessages:directMessages.results.reverse(),wallet:wallet.results,campus:await campusState(me)});
 }catch(e){console.error('Student life read failed',e);return json({error:'Student life is temporarily unavailable. Please retry.'},503);}}
export async function POST(request:Request){try{
 if(!sameOrigin(request))return json({error:'Please use the campus page.'},403);
 const user=await getCampusUser(request.headers.get('cookie'));if(!user)return json({error:'Log in to continue.'},401);
 const raw=await request.text();if(raw.length>4096)return json({error:'Request too large.'},413);let b;try{b=JSON.parse(raw);}catch{return json({error:'Invalid request.'},400);}if(!b||typeof b!=='object')return json({error:'Invalid request.'},400);
 const db=authDb(),me=await readStudent(user.userId),now=Date.now();if(!me)return json({error:'Create your student first.'},400);
 const campus=await campusAction(b,me,now);if(campus)return campus;
 if(b.op==='enter'||b.op==='exit'){
  const hall=hostels.find(h=>h.id===(b.op==='exit'?me.inside:b.hostel));if(!hall)return json({error:'Choose a hostel.'},400);if(b.op==='enter'&&hall.id==='maintenance'&&(await readOrigin(me.id))?.gender!=='female')return json({error:'Maintenance is a female-only hostel.'},403);const p=arrival(hall);
  await db.prepare('UPDATE students SET inside=?,x=?,z=?,last_seen=? WHERE id=?').bind(b.op==='exit'?'':hall.id,p.x,p.z,now,me.id).run();
  return json({me:await readStudent(me.id)});
 }
 if(b.op==='room'){
  if(me.inside!==me.hostel)return json({error:'Enter your own hostel to choose your room.'},400);
  if(!blocks.includes(b.block)||!roomNumbers.includes(b.room))return json({error:'Choose a valid block and room.'},400);
  const result=await db.prepare('UPDATE students SET block=?,room=?,last_seen=? WHERE id=? AND (SELECT COUNT(*) FROM students WHERE hostel=? AND block=? AND room=? AND id!=?)<4').bind(b.block,b.room,now,me.id,me.hostel,b.block,b.room,me.id).run();
  if(!result.meta.changes)return json({error:'This room is full. Choose another room.'},409);return json({me:await readStudent(me.id),notice:`You moved into Block ${b.block}, Room ${b.room}.`});
 }
 if(b.op==='dm'||b.op==='room-chat'){
  const body=typeof b.body==='string'?b.body.trim():'';if(!body||body.length>280)return json({error:'Write between 1 and 280 characters.'},400);
  if(b.op==='room-chat'&&(!me.room||me.inside!==me.hostel))return json({error:'Enter your assigned room to chat.'},403);
  if(b.op==='dm'&&(typeof b.recipient!=='string'||b.recipient===me.id||!await readStudent(b.recipient)))return json({error:'Choose another student.'},400);
  const insert=b.op==='dm'?db.prepare('INSERT INTO direct_messages (id,sender,recipient,body,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND last_chat<?').bind(crypto.randomUUID(),b.recipient,body,now,me.id,now-3000):db.prepare('INSERT INTO room_messages (id,channel,user_id,name,body,created) SELECT ?,?,id,name,?,? FROM students WHERE id=? AND last_chat<?').bind(crypto.randomUUID(),channel(me),body,now,me.id,now-3000);
  const result=await db.batch([insert,db.prepare('UPDATE students SET last_chat=?,last_seen=? WHERE id=? AND last_chat<?').bind(now,now,me.id,now-3000)]);
  if(!result[0].meta.changes)return json({error:'Wait a moment before your next message.'},429);return json({ok:true});
 }
 if(b.op==='activity'||b.op==='food'){
  const food=b.op==='food'?meals.find(m=>m.id===b.meal):null;const activity=b.op==='activity'?activities.find(a=>a.id===b.activity):null;
  if(!food&&!activity)return json({error:'Choose a valid activity or meal.'},400);
  if(activity&&!me.inside)return json({error:'Enter a hostel to do this activity.'},400);
  if(activity&&['sleep','study','gist'].includes(activity.id)&&(!me.room||me.inside!==me.hostel))return json({error:'Choose a room in your hostel first.'},400);
  const support=food?(await campusState(me)).policy==='food':false;
  const cost=food?Math.max(0,food.price-(support?100:0)):0,id=activity?.id;const energy=id==='sleep'?30:id==='study'?-10:id==='football'?-12:id==='laundry'?-5:0;
  const required=Math.max(0,-energy);if(me.money<cost)return json({error:'You do not have enough game money for this meal.'},400);if(me.energy<required)return json({error:'Rest before this activity.'},400);
  const hunger=food?.hunger??(id==='football'?-8:id==='sleep'?-5:0),hygiene=id==='shower'?35:id==='laundry'?15:id==='football'?-8:0,social=id==='gist'?15:id==='football'?12:0,study=id==='study'?8:0,nonce=crypto.randomUUID();
  const statements=[db.prepare('UPDATE students SET money=money-?,energy=MIN(100,MAX(0,energy+?)),hunger=MIN(100,MAX(0,hunger+?)),hygiene=MIN(100,MAX(0,hygiene+?)),social=MIN(100,MAX(0,social+?)),study=study+?,last_action=?,last_seen=?,action_nonce=? WHERE id=? AND money>=? AND energy>=? AND last_action<?').bind(cost,energy,hunger,hygiene,social,study,now,now,nonce,me.id,cost,required,now-8000)];
  if(food)statements.push(db.prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,food.name,-cost,now,me.id,nonce));
  if(id==='gist')statements.push(db.prepare('INSERT INTO room_messages (id,channel,user_id,name,body,created) SELECT ?,?,?,?, ?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,channel(me),'npc-moyo','Moyo · campus character',['Lectures were packed today! Want to study together later?','Jollof or amala? I am heading to the canteen after this.','A quick match in the courtyard would be nice.'][Math.floor(Math.random()*3)],now,me.id,nonce));
  const result=await db.batch(statements);if(!result[0].meta.changes)return json({error:'Finish your last activity first. Try again in a few seconds.'},429);
  return json({me:await readStudent(me.id),notice:food?`${food.name} delivered. Enjoy your meal!`:id==='shower'?'Fresh and ready for campus.':id==='sleep'?'Rested and recharged.':id==='study'?'You earned 8 study points.':id==='football'?'Good game! Your social meter increased.':id==='laundry'?'Clean clothes, sorted.':'Your roommates have something to say. Check room chat.'});
 }
 return json({error:'Unknown student life action.'},400);
 }catch(e){console.error('Student life save failed',e);return json({error:'Could not save that. Please try again.'},503);}}
