import {readIdentity} from '../../../lib/account-identity';
import {readOrigin} from '../../../lib/account-origin';
import {housingOptions,housingQuote} from '../../../lib/housing';
import {validateAppearance} from '../../../lib/appearance';
import {campusState} from '../../../lib/campus-actions';
import { env } from 'cloudflare:workers';
import {getCampusUser,sameOrigin} from '../../../lib/account-auth';
import { locations,hostels,colors,arrival,Student } from '../../../lib/campus';
export const dynamic='force-dynamic';
const response=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
function db(){if(!env.DB)throw new Error('Campus database unavailable');return env.DB;}
async function student(id:string){return db().prepare('SELECT * FROM students WHERE id = ?').bind(id).first<Student>();}
export async function GET(request:Request){
 try{
  const user=await getCampusUser(request.headers.get('cookie'));if(!user)return response({error:'Log in to join campus.'},401);
  const now=Date.now();
  const me=await student(user.userId);
  const [players,messages]=await Promise.all([db().prepare("SELECT id,name,hostel,faculty,color,appearance,x,z FROM students WHERE last_seen > ? AND id != ? AND inside='' LIMIT 100").bind(now-20000,user.userId).all(),me&&!me.inside?db().prepare('SELECT id,name,body,x,z,created FROM messages WHERE created > ? AND ((x-?)*(x-?) + (z-?)*(z-?)) < 400 ORDER BY created DESC LIMIT 60').bind(now-600000,me.x,me.x,me.z,me.z).all():Promise.resolve({results:[]})]);
  const origin=await readOrigin(user.userId);
  return response({me,origin,identity:await readIdentity(user.userId),housingOptions:housingOptions(origin?.gender??null),players:players.results,messages:messages.results.reverse()});
 }catch(e){console.error('Campus read failed',e);return response({error:'Campus is temporarily unavailable. Please try again.'},503);}
}
export async function POST(request:Request){
 try{
  if(!sameOrigin(request))return response({error:'Please use the campus page.'},403);
  if(Number(request.headers.get('content-length')||0)>4000)return response({error:'Request too large.'},413);
  const b=await request.json() as {op?:string;housingTier?:unknown;name?:string;hostel?:string;faculty?:string;color?:string;appearance?:unknown;x?:number;z?:number;body?:string;location?:string;visitorId?:unknown};if(!b||typeof b!=='object'||Array.isArray(b))return response({error:'Invalid request.'},400);const now=Date.now();
  if(b.op==='presence'){
   if(typeof b.visitorId!=='string'||!/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(b.visitorId))return response({error:'Invalid visitor.'},400);
   await db().prepare('INSERT INTO site_presence(visitor_id,first_seen,last_seen) VALUES(?,?,?) ON CONFLICT(visitor_id) DO UPDATE SET last_seen=excluded.last_seen').bind(b.visitorId,now,now).run();
   const metrics=await db().prepare('SELECT COUNT(*) AS visitors,COALESCE(SUM(CASE WHEN last_seen>? THEN 1 ELSE 0 END),0) AS online FROM site_presence').bind(now-30000).first();return response({metrics});
  }
  const user=await getCampusUser(request.headers.get('cookie'));if(!user)return response({error:'Log in to join campus.'},401);
  const me=await student(user.userId);
  if(b.op==='create'){
   if(me)return response({me});
   const identity=await readIdentity(user.userId);const name=identity?.display_name??(typeof b.name==='string'?b.name.trim():'');const origin=await readOrigin(user.userId);const hall=hostels.find(l=>l.id===(b.hostel??origin?.hostel));
   if(hall?.id==='maintenance'&&origin?.gender!=='female')return response({error:'Maintenance is a female hostel. Choose another hostel.'},403);
   if(name.length<2||name.length>24||!hall||!b.color||!colors.includes(b.color)||typeof b.faculty!=='string'||b.faculty.length>40)return response({error:'Choose a name, hostel, and colour.'},400);
   const appearance=validateAppearance(b.appearance);if(!appearance)return response({error:'Choose valid appearance options.'},400);const p=arrival(hall);
   const startingMoney=origin?.startingMoney??5000,quote=housingQuote(hall.id,origin?.gender??null,startingMoney,b.housingTier);
   if('error' in quote)return response({error:quote.error},quote.status);
   const nonce=crypto.randomUUID();
   await db().batch([
    db().prepare('INSERT OR IGNORE INTO students (id,name,hostel,faculty,color,appearance,x,z,last_seen,money,action_nonce) VALUES (?,?,?,?,?,?,?,?,?,?,?)').bind(user.userId,name,hall.id,b.faculty,b.color,JSON.stringify(appearance),p.x,p.z,now,startingMoney-quote.fee,nonce),
    db().prepare('INSERT OR IGNORE INTO housing_leases (user_id,hostel,paid_until,fee) SELECT id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(hall.id,now+quote.duration,quote.fee,user.userId,nonce),
    db().prepare('INSERT INTO wallet_entries (id,user_id,label,amount,created) SELECT ?,id,?,?,? FROM students WHERE id=? AND action_nonce=?').bind(nonce,`First home · ${quote.option.name} · semester fee`,-quote.fee,now,user.userId,nonce)
   ]);return response({me:await student(user.userId)});
  }
  if(!me)return response({error:'Create your student first.'},400);
  if(b.op==='move'){
   if(typeof b.x!=='number'||typeof b.z!=='number'||!Number.isFinite(b.x)||!Number.isFinite(b.z))return response({error:'Invalid position.'},400);
   if(me.inside){await db().prepare('UPDATE students SET last_seen=? WHERE id=?').bind(now,user.userId).run();return response({ok:true});}
   await db().prepare('UPDATE students SET x=?,z=?,last_seen=? WHERE id=?').bind(Math.max(-46,Math.min(58,b.x)),Math.max(-36,Math.min(39,b.z)),now,user.userId).run();return response({ok:true});
  }
  if(b.op==='chat'){
   if(me.inside)return response({error:'Use room chat or your phone while inside a hostel.'},400);
   const body=typeof b.body==='string'?b.body.trim():'';if(!body||body.length>280)return response({error:'Write between 1 and 280 characters.'},400);
   const results=await db().batch([db().prepare('INSERT INTO messages (id,user_id,name,body,x,z,created) SELECT ?,id,name,?,x,z,? FROM students WHERE id=? AND last_chat < ?').bind(crypto.randomUUID(),body,now,user.userId,now-3000),db().prepare('UPDATE students SET last_chat=?,last_seen=? WHERE id=? AND last_chat < ?').bind(now,now,user.userId,now-3000)]);
   if(!results[0].meta.changes)return response({error:'Give it a moment before your next message.'},429);return response({ok:true});
  }
  if(b.op==='action'){
   if(me.inside)return response({error:'Use hostel activities or return to campus first.'},400);
   const loc=locations.find(l=>l.id===b.location);if(!loc)return response({error:'Choose a campus location.'},400);
   const p=arrival(loc);if(Math.hypot(me.x-p.x,me.z-p.z)>9)return response({error:'Walk closer to this location first.'},400);
   if(loc.type==='hostel'&&loc.id!==me.hostel)return response({error:'You can rest in your own hostel. Chat with students here instead.'},400);
   let money=me.money,energy=me.energy,hunger=me.hunger,study=me.study,social=me.social,hygiene=me.hygiene;
   if(loc.type==='academic'){if(energy<15||hunger<10)return response({error:'Eat or rest before studying.'},400);energy-=12;hunger-=8;study+=(loc.id==='library'?12:10)+((await campusState(me)).policy==='study'?3:0);}
   else if(loc.type==='hostel'){energy=Math.min(100,energy+30);hunger=Math.max(0,hunger-5);}
   else if(loc.type==='food'){if(money<500)return response({error:'You need ₦500 for a meal.'},400);money-=500;hunger=Math.min(100,hunger+35);}
   else if(loc.id==='sports'){if(energy<12)return response({error:'Rest before playing football.'},400);energy-=12;hunger=Math.max(0,hunger-8);social=Math.min(100,social+12);hygiene=Math.max(0,hygiene-8);}
   else {energy=Math.min(100,energy+8);hunger=Math.max(0,hunger-5);social=Math.min(100,social+15);}
   const result=await db().prepare('UPDATE students SET money=?,energy=?,hunger=?,study=?,social=?,hygiene=?,last_action=?,last_seen=? WHERE id=? AND last_action < ?').bind(money,energy,hunger,study,social,hygiene,now,now,user.userId,now-10000).run();
   if(!result.meta.changes)return response({error:'Your student is still finishing the last activity. Wait a few seconds.'},429);
   return response({me:await student(user.userId),notice:loc.type==='academic'?`Nice work! You earned ${study-me.study} study points.`:loc.type==='food'?'Meal sorted. Your hunger meter is replenished.':loc.type==='hostel'?'Feeling rested. Back to campus life.':'A little break goes a long way.'});
  }return response({error:'Unknown action.'},400);
 }catch(e){console.error('Campus update failed',e);return response({error:'Could not save that. Please try again.'},503);}
}

