import bcrypt from 'bcryptjs';
import {allocateOrigin} from '../../../lib/student-origin';
import {readOrigin} from '../../../lib/account-origin';
import {authDb,getCampusUser,makeSession,sessionCookie,sessionToken,digest,sameOrigin,reserveAttempt} from '../../../lib/account-auth';
export const dynamic='force-dynamic';
const json=(data:unknown,status=200,headers:Record<string,string>={})=>Response.json(data,{status,headers:{'Cache-Control':'no-store',...headers}});
// A fixed dummy hash keeps incorrect-password and unknown-email checks comparable.
const DUMMY_HASH='$2b$12$R9h/cIPz0gi.URNNX3kh2OPST9/PgBkqquzi.Ss7KIUgO2t0jWMUW';
export async function GET(request:Request){try{const user=await getCampusUser(request.headers.get('cookie'));return json({signedIn:!!user,origin:user?await readOrigin(user.userId):null});}catch{return json({error:'Accounts are temporarily unavailable. Please try again.'},503);}}
export async function POST(request:Request){
 try{
  if(!sameOrigin(request))return json({error:'Please submit this form from OAU Life.'},403);
  if(!request.headers.get('content-type')?.startsWith('application/json'))return json({error:'Invalid account request.'},400);
  const raw=await request.text();if(raw.length>4096)return json({error:'Account request is too large.'},413);
  let b:{op?:string;email?:string;password?:string;gender?:string};try{b=JSON.parse(raw);}catch{return json({error:'Invalid account request.'},400);}if(!b||typeof b!=='object')return json({error:'Invalid account request.'},400);
  if(b.op==='logout'){
   const token=sessionToken(request.headers.get('cookie'));
   const user=await getCampusUser(request.headers.get('cookie'));
   if(token)await authDb().prepare('DELETE FROM auth_sessions WHERE token_hash=?').bind(await digest(token)).run();
   if(user)await authDb().prepare('UPDATE students SET last_seen=0 WHERE id=?').bind(user.userId).run();
   return json({ok:true},200,{'Set-Cookie':sessionCookie(request,'',true)});
  }
  if(b.op!=='register'&&b.op!=='login')return json({error:'Unknown account action.'},400);
  const email=typeof b.email==='string'?b.email.trim().toLowerCase():'';
  const password=typeof b.password==='string'?b.password:'';
  if(email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return json({error:'Enter a valid email address.'},400);
  if(password.length<8||bcrypt.truncates(password))return json({error:'Use a password of at least 8 characters and no more than 72 bytes.'},400);
  const ip=request.headers.get('cf-connecting-ip');
  if(ip&&!await reserveAttempt('ip:'+await digest(ip),30))return json({error:'Too many account attempts. Please try again in 15 minutes.'},429);
  if(!await reserveAttempt(b.op+':'+await digest(email),b.op==='login'?10:5))return json({error:'Too many attempts. Please try again in 15 minutes.'},429);
  const existing=await authDb().prepare('SELECT id,password_hash FROM accounts WHERE email=?').bind(email).first<{id:string;password_hash:string}>();
  let accountId:string;
  if(b.op==='register'){
   if(existing)return json({error:'An account already uses this email. Log in instead.'},409);
   if(b.gender!=='male'&&b.gender!=='female')return json({error:'Choose your student gender for hostel allocation.'},400);
   const origin=allocateOrigin(b.gender);
   accountId=crypto.randomUUID();const passwordHash=await bcrypt.hash(password,12);const session=await makeSession(accountId);
   try{await authDb().batch([authDb().prepare('INSERT INTO accounts (id,email,password_hash,created) VALUES (?,?,?,?)').bind(accountId,email,passwordHash,Date.now()),authDb().prepare('INSERT INTO account_origins (account_id,background,gender,starting_money,hostel,created) VALUES (?,?,?,?,?,?)').bind(accountId,origin.background,origin.gender,origin.startingMoney,origin.hostel,Date.now()),session.statement]);}catch(e){if(String(e).includes('UNIQUE'))return json({error:'An account already uses this email. Log in instead.'},409);throw e;}
   return json({ok:true,origin},201,{'Set-Cookie':sessionCookie(request,session.token)});
  }
  const matches=await bcrypt.compare(password,existing?.password_hash??DUMMY_HASH);
  if(!existing||!matches)return json({error:'Email or password is incorrect.'},401);
  accountId=existing.id;const session=await makeSession(accountId);
  await authDb().batch([session.statement,authDb().prepare('DELETE FROM auth_sessions WHERE expires_at<?').bind(Date.now()),authDb().prepare('DELETE FROM auth_limits WHERE expires_at<?').bind(Date.now())]);
  return json({ok:true},200,{'Set-Cookie':sessionCookie(request,session.token)});
 }catch(e){console.error('Account request failed',e instanceof Error?e.name:'Unknown');return json({error:'Could not complete that. Your details have not been changed. Please try again.'},503);}
}
