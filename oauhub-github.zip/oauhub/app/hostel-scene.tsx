'use client';
import {useEffect,useRef,useState} from 'react';
import * as THREE from 'three';
import {createAvatar,updateAvatarAppearance,animateAvatar,disposeAvatarScene} from '../lib/avatar-model';
import {Student} from '../lib/campus';
import {Resident} from '../lib/hostel-life';
import {interiorLayout,interiorPath,canStand,isApartment,Point,ROOM_X,ROOM_Z} from '../lib/interior-layout';
import {buildInterior} from '../lib/interior-model';
import {addRoomItem} from '../lib/room-item-model';
import type {RoomItem} from '../lib/room-decor';
import type {PlacementDraft} from './room-decorator';
type Label={id:string;text:string;x:number;y:number;zone?:boolean};
const names:Record<string,string>={bed:'Your bed',desk:'Study',shower:'Shower',sofa:'Relax & chat',kitchen:'Cook a meal',laundry:'Laundry',food:'Eat',football:'Play ball',style:'Wardrobe'};
export default function HostelScene({me,residents,zone,command,onSpot,onDone,inventory=[],zoom=1,visitor=false,decor=[],draft=null,onPick}:{decor?:RoomItem[];draft?:PlacementDraft|null;onPick?:(p:Point)=>void;visitor?:boolean;inventory?:{item:string}[];zoom?:number;me:Student;residents:Resident[];zone:'room'|'yard';command:{spot:string;token:number}|null;onSpot:(spot:string)=>void;onDone:()=>void}){
 const root=useRef<HTMLDivElement>(null),latest=useRef({me,residents,command,onSpot,onDone,zoom,draft,onPick});latest.current={me,residents,command,onSpot,onDone,zoom,draft,onPick};const [labels,setLabels]=useState<Label[]>([]),[failed,setFailed]=useState(false);
 const apartment=isApartment(me.inside),bedIndex=Math.max(0,residents.filter(r=>!r.visitor).map(r=>r.id).concat(me.id).filter((id,i,all)=>all.indexOf(id)===i).sort().indexOf(me.id))%4;
 useEffect(()=>{
  const el=root.current;if(!el)return;let renderer:THREE.WebGLRenderer;
  try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});}catch{setFailed(true);return;}setFailed(false);
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;el.appendChild(renderer.domElement);
  const scene=new THREE.Scene();scene.background=new THREE.Color('#d5e8eb');const layout=interiorLayout(apartment,bedIndex);for(const item of decor)if(item.item!=='rug')layout.obstacles.push({x:item.x,z:item.z,w:1.1,d:1.1});
  const camera=new THREE.OrthographicCamera(-20,20,15,-15,.1,140);camera.position.set(26,32,34);camera.lookAt(0,0,0);
  scene.add(new THREE.HemisphereLight('#fff7df','#76958c',2.6));const light=new THREE.DirectionalLight('#fff2d8',3);light.position.set(-15,28,12);light.castShadow=true;light.shadow.mapSize.set(1536,1536);Object.assign(light.shadow.camera,{left:-24,right:24,top:24,bottom:-24});light.shadow.normalBias=.04;scene.add(light);
  let floor:THREE.Mesh,hot:THREE.Object3D[],objects:Record<string,THREE.Group>={};
  const yardSpots:Record<string,Point>={football:{x:2,z:1},laundry:{x:-9,z:3},shower:{x:9,z:4},food:{x:0,z:-7}};
  if(zone==='room')({floor,hot,objects}=buildInterior(scene,interiorLayout(apartment,bedIndex,1),[]));
  else{
   const box=(w:number,h:number,d:number,c:string,x:number,y:number,z:number)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshStandardMaterial({color:c,roughness:.9}));m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;scene.add(m);return m;};
   floor=box(33.6,.25,28,'#92b890',0,-.2,0);box(18,.04,12,'#65996f',0,.02,0);for(const z of [-6,6])box(18,.025,.08,'#e8f0d7',0,.055,z);for(const x of [-9,9])box(.08,.025,12,'#e8f0d7',x,.055,0);box(18,.025,.08,'#e8f0d7',0,.055,0);
   for(const z of [-6.5,6.5]){box(.12,2.1,.12,'#eef2e7',-2,1,z);box(.12,2.1,.12,'#eef2e7',2,1,z);box(4.1,.12,.12,'#eef2e7',0,2.1,z);}
   hot=[];for(const [id,p]of Object.entries(yardSpots)){if(id==='football')continue;const m=box(id==='food'?5:2,id==='shower'?3:1.8,2,id==='food'?'#c69568':'#d9e3dd',p.x,id==='shower'?1.5:.9,p.z);m.userData.spot=id;hot.push(m);}
  }
  if(zone==='room'){for(const item of decor){if(draft?.item===item.item&&item.user_id===me.id)continue;addRoomItem(scene,item);}if(draft&&draft.x!==null&&draft.z!==null)addRoomItem(scene,{item:draft.item,x:draft.x,z:draft.z,rotation:draft.rotation},true);}
  const ball=new THREE.Mesh(new THREE.IcosahedronGeometry(.33,1),new THREE.MeshStandardMaterial({color:'#fbf6e6'}));ball.position.set(2,.35,1);ball.castShadow=true;ball.visible=zone==='yard';ball.userData.spot='football';scene.add(ball);if(zone==='yard')hot.push(ball);
  const avatar=(color:string)=>{const g=createAvatar(color);g.scale.setScalar(.8);scene.add(g);return g;};const player=avatar(latest.current.me.color);player.position.set(0,0,0);const others=new Map<string,THREE.Group>();
  const marker=new THREE.Mesh(new THREE.OctahedronGeometry(.22),new THREE.MeshStandardMaterial({color:'#c4f398'}));scene.add(marker);
  const npc=avatar('#c99665');npc.position.set(apartment?-6:-8,0,4);npc.rotation.y=.8;npc.visible=!apartment&&zone==='room';
  const ray=new THREE.Raycaster(),pointer=new THREE.Vector2(),keys=new Set<string>();let route:Point[]=[],activity='',token=-1,finish=0,lastLabels=0,lastZoom=0;let standing:Point={x:0,z:0};
  const spotPoint=(id:string)=>zone==='yard'?yardSpots[id]:layout.spots[id];
  const walkTo=(p:Point)=>{route=zone==='room'?interiorPath(player.position,p,layout):[p];};
  function click(e:PointerEvent){const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);if(latest.current.draft){const floorHit=ray.intersectObject(floor)[0];if(floorHit)latest.current.onPick?.({x:Math.round(floorHit.point.x*2)/2,z:Math.round(floorHit.point.z*2)/2});return;}const hit=ray.intersectObjects(hot.filter(o=>!visitor||!['bed','desk','kitchen'].includes(o.userData.spot)),false)[0];if(hit){latest.current.onSpot(hit.object.userData.spot);return;}const point=ray.intersectObject(floor)[0];if(point&&!activity)walkTo({x:point.point.x,z:point.point.z});}
  function down(e:KeyboardEvent){if((e.target as HTMLElement).matches('input,select,textarea'))return;if(['w','a','s','d','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();keys.add(e.key);if(!activity)route=[];}}const up=(e:KeyboardEvent)=>keys.delete(e.key),blur=()=>keys.clear();
  renderer.domElement.addEventListener('pointerdown',click);window.addEventListener('keydown',down);window.addEventListener('keyup',up);window.addEventListener('blur',blur);
  const resize=()=>{const w=el.clientWidth,h=el.clientHeight;if(!w||!h)return;renderer.setSize(w,h);const ratio=w/h,span=Math.max(16,22/ratio);camera.left=-span*ratio;camera.right=span*ratio;camera.top=span;camera.bottom=-span;camera.updateProjectionMatrix();};const observer=new ResizeObserver(resize);observer.observe(el);resize();
  let frame=0,last=performance.now();
  function loop(t:number){const p=latest.current,dt=Math.min((t-last)/1000,.04);last=t;const before=player.position.clone();
   if(lastZoom!==p.zoom){lastZoom=p.zoom;camera.zoom=p.zoom;camera.updateProjectionMatrix();}
   if(p.command&&p.command.token!==token){token=p.command.token;activity=p.command.spot;const point=spotPoint(activity);if(point)walkTo(point);finish=0;}
   if(route.length){const next=route[0],dx=next.x-player.position.x,dz=next.z-player.position.z,d=Math.hypot(dx,dz);if(d<.06){player.position.x=next.x;player.position.z=next.z;route.shift();if(!route.length&&activity){standing={x:next.x,z:next.z};finish=t+2600;}}else{const step=Math.min(d,dt*5);player.position.x+=dx/d*step;player.position.z+=dz/d*step;player.rotation.y=Math.atan2(dx,dz);}}
   else if(activity&&!finish){standing={x:player.position.x,z:player.position.z};finish=t+2600;}
   else if(!activity){let dx=0,dz=0;if(keys.has('w')||keys.has('ArrowUp')){dx-=.7;dz-=.7;}if(keys.has('s')||keys.has('ArrowDown')){dx+=.7;dz+=.7;}if(keys.has('a')||keys.has('ArrowLeft')){dx-=.7;dz+=.7;}if(keys.has('d')||keys.has('ArrowRight')){dx+=.7;dz-=.7;}const candidate={x:THREE.MathUtils.clamp(player.position.x+dx*dt*5,-ROOM_X+.1,ROOM_X-.1),z:THREE.MathUtils.clamp(player.position.z+dz*dt*5,-ROOM_Z+.1,ROOM_Z-.1)};if(zone==='yard'||canStand(candidate,layout)){player.position.x=candidate.x;player.position.z=candidate.z;}if(dx||dz)player.rotation.y=Math.atan2(dx,dz);}
   if(finish){if(activity==='bed'){const b=layout.beds[Math.min(bedIndex,layout.beds.length-1)];player.position.set(b.x,1.45,b.z+.3);player.rotation.z=Math.PI/2;player.rotation.y=0;}else if(activity==='sofa')player.position.y=.2;else player.position.y=Math.sin(t/170)*.05;if(activity==='football'){const progress=((t-(finish-2600))/1300)%1;ball.position.set(2-progress*2,.35+Math.sin(progress*Math.PI),1-progress*6);}if(t>finish){activity='';finish=0;player.rotation.z=0;player.position.set(standing.x,0,standing.z);ball.position.set(2,.35,1);p.onDone();}}
   const visible=p.residents.filter(r=>r.id!==p.me.id&&r.inside===p.me.inside&&Date.now()-r.last_seen<20000),ids=new Set(visible.map(r=>r.id));for(const [id,g]of others)if(!ids.has(id)){scene.remove(g);disposeAvatarScene(g);others.delete(id);}visible.slice(0,8).forEach((r,i)=>{let g=others.get(r.id);if(!g){g=avatar(r.color);others.set(r.id,g);}updateAvatarAppearance(g,r.color,r.appearance);g.position.set(zone==='room'?-8+(i%4)*2:-4+(i%4)*3,0,zone==='room'?3.4+Math.floor(i/4)*1.8:-3);});npc.visible=zone==='room'&&!apartment&&visible.length<3;
   updateAvatarAppearance(player,p.me.color,p.me.appearance);animateAvatar(player,t,player.position.distanceTo(before)>.005&&!finish);marker.position.copy(player.position).add(new THREE.Vector3(0,2.8+Math.sin(t/450)*.1,0));marker.rotation.y=t/1000;
   if(t-lastLabels>220){lastLabels=t;const active=zone==='room'?visitor?['sofa','shower']:['bed','desk','kitchen','sofa','shower']:['football','laundry','shower','food'];const project=(point:Point,height:number)=>{const q=new THREE.Vector3(point.x,height,point.z).project(camera);return{x:(q.x+1)*el!.clientWidth/2,y:(1-q.y)*el!.clientHeight/2};};setLabels([...active.map(id=>({id,text:names[id],...project(spotPoint(id),1.7)})),...(zone==='room'?layout.zones.map((z,i)=>({id:`zone-${i}`,text:z.name,zone:true,...project(z,.1)})):[])]);}
   renderer.render(scene,camera);frame=requestAnimationFrame(loop);
  }frame=requestAnimationFrame(loop);
  return()=>{cancelAnimationFrame(frame);observer.disconnect();renderer.domElement.removeEventListener('pointerdown',click);window.removeEventListener('keydown',down);window.removeEventListener('keyup',up);window.removeEventListener('blur',blur);disposeAvatarScene(scene);renderer.dispose();renderer.domElement.remove();};
 },[zone,apartment,bedIndex,visitor,JSON.stringify(decor),JSON.stringify(draft)]);
 return <div className="hostel-scene" ref={root} aria-label={zone==='yard'?'Interactive courtyard':apartment?'Interactive cutaway apartment':'Interactive four-person hostel room'}>{failed&&<p className="hostel-fallback">The 3D interior could not load. Open Activities to keep playing.</p>}<div className="hostel-hotspots">{labels.map(l=>l.zone?<span className="interior-zone-label" key={l.id} style={{left:l.x,top:l.y}}>{l.text}</span>:<button key={l.id} style={{left:l.x,top:l.y}} onClick={()=>onSpot(l.id)}>{l.text}</button>)}</div></div>;
}
