import Game from './game';
import {headers} from 'next/headers';
import {getCampusUser} from '../lib/account-auth';
export const dynamic='force-dynamic';
export default async function Page(){const requestHeaders=await headers();const user=await getCampusUser(requestHeaders.get('cookie'));return <Game signedIn={!!user} />;}
