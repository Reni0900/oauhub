'use client';

import {useEffect,useRef,useState} from 'react';

import * as THREE from 'three';

import {createAvatar,updateAvatarAppearance,animateAvatar,disposeAvatarScene} from '../lib/avatar-model';

import {locations,Student} from '../lib/campus';

type Props={me:Student|null;players:Student[];zoom:number;follow:boolean;viewReset:number;onPan:()=>void;selected?:string|null;onSelect:(id:string)=>void;onPosition:(x:number,z:number)=>void;position:React.RefObject<{x:number;z:number}>;walk:React.RefObject<{x:number;z:number}|null>};

export default function CampusScene(props:Props){

 const root=useRef<HTMLDivElement>(null);const latest=useRef(props);latest.current=props;

 const [avatarLabel,setAvatarLabel]=useState<{x:number;y:number}|null>(null);const [labels,setLabels]=useState<{id:string;x:number;y:number;anchorX:number;anchorY:number}[]>([]);const [failed,setFailed]=useState(false);

 useEffect(()=>{

  if(!root.current)return;const element=root.current;

  let renderer:THREE.WebGLRenderer;

  try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});}catch{setFailed(true);return;}

  renderer.setPixelRatio(Math.min(window.devicePixelRatio,1.6));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.setClearColor('#d8e6d9');element.appendChild(renderer.domElement);

  const scene=new THREE.Scene();scene.background=new THREE.Color('#d8e6d9');

  const camera=new THREE.OrthographicCamera(-64,64,44,-44,0.1,250);camera.position.set(76,100,95);camera.lookAt(6,0,0);

  scene.add(new THREE.HemisphereLight('#fffff4','#6d947d',2.7));const sun=new THREE.DirectionalLight('#fff4d5',3);sun.position.set(-25,65,30);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-70,right:70,top:60,bottom:-60});sun.shadow.bias=-0.001;sun.shadow.normalBias=.025;scene.add(sun);

  const mats=new Map<string,THREE.MeshStandardMaterial>();function mat(color:string){if(!mats.has(color))mats.set(color,new THREE.MeshStandardMaterial({color,roughness:0.9}));return mats.get(color)!;}

  function box(w:number,h:number,d:number,color:string,x:number,y:number,z:number,parent:THREE.Object3D=scene){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(color));mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;}

  box(116,1.5,83,'#81b78d',5,-0.9,0);box(117,.18,84,'#487463',5,-1.8,0);

  const ground=box(115,.08,82,'#a3bd87',5,-.09,0);

  box(104,.08,4,'#ddd8c6',4,0,31);box(5,.08,64,'#ddd8c6',-15,0,0);box(5,.08,64,'#ddd8c6',35,0,0);

  box(42,.08,4,'#ddd8c6',10,0,-3);box(40,.08,4,'#ddd8c6',10,0,-28);

  for(let z=-25;z<=26;z+=6){box(.22,.1,2,'#fff9de',-15,.03,z);box(.22,.1,2,'#fff9de',35,.03,z);}

  const clickable:THREE.Object3D[]=[];

  for(const l of locations){

   const group=new THREE.Group();group.position.set(l.x,0,l.z);group.userData.location=l.id;scene.add(group);

   const height=l.type==='hostel'?3.8:l.id==='library'?5:3;

   if(l.id==='sports'){

    box(l.w,.15,l.d,'#4d976b',0,.1,0,group);box(l.w-.7,.08,.13,'#edf0d8',0,.22,-l.d/2+.5,group);box(l.w-.7,.08,.13,'#edf0d8',0,.22,l.d/2-.5,group);box(.13,.08,l.d-1,'#edf0d8',-l.w/2+.5,.22,0,group);box(.13,.08,l.d-1,'#edf0d8',l.w/2-.5,.22,0,group);box(l.w-1,.08,.13,'#edf0d8',0,.22,0,group);

   }else if(l.id==='amphi'){

    for(let i=0;i<4;i++)box(l.w-i*1.4,.5+i*.3,l.d-i*1.7,l.color,0,(.5+i*.3)/2,-i*.4,group);

    box(4,.2,2,'#536a78',0,.12,l.d/2,group);

   }else if(l.type==='hostel'){

    for(let n=0;n<4;n++){const bx=(n%2?1:-1)*l.w/4,bz=(n<2?-1:1)*l.d/4,bw=l.w/2-.5,bd=l.d/2-.5;box(bw,3.2,bd,l.color,bx,1.6,bz,group);box(bw+.2,.2,bd+.2,'#526d75',bx,3.3,bz,group);box(.8,1.6,.09,'#354e63',bx,.8,bz+bd/2,group);box(.5,.65,.08,'#83a2ab',bx-1,2.2,bz+bd/2,group);box(.5,.65,.08,'#83a2ab',bx+1,2.2,bz+bd/2,group);}

   }else{

    box(l.w,height,l.d,l.color,0,height/2,0,group);box(l.w+.6,.35,l.d+.6,'#526d75',0,height+.18,0,group);

    box(l.w+.2,.25,.8,'#fff1d4',0,height-.25,l.d/2+.25,group);

    for(let x=-l.w/2+1.2;x<l.w/2-1;x+=2){box(.8,1.1,.08,'#557f89',x,2,l.d/2+.05,group);}

    box(1.2,2.1,.12,'#354e63',0,1.05,l.d/2+.12,group);box(l.w+.6,.15,2,'#e6ddc2',0,.08,l.d/2+1,group);

    if(l.id==='library')for(let x=-5;x<6;x+=2)box(.45,3.2,.45,'#faf0d4',x,1.6,l.d/2+.65,group);

   }

   group.traverse(o=>{if(o instanceof THREE.Mesh){o.userData.location=l.id;clickable.push(o);}});

  }

  for(let i=0;i<85;i++){const x=((i*37)%109)-49,z=((i*23)%74)-35;if(locations.some(l=>Math.abs(x-l.x)<l.w/2+3&&Math.abs(z-l.z)<l.d/2+4)||Math.abs(x+15)<4||Math.abs(x-35)<4||Math.abs(z-31)<4)continue;

   box(.55,2,.55,'#8e7960',x,1,z);const tree=new THREE.Mesh(new THREE.IcosahedronGeometry(1.8+(i%3)*.2,0),mat(i%2?'#3f8968':'#619768'));tree.position.set(x,3.3,z);tree.castShadow=true;scene.add(tree);

  }

  // Courtyards and street furniture make campus feel lived in without blocking movement.
  function cylinder(radius:number,h:number,color:string,x:number,y:number,z:number){const mesh=new THREE.Mesh(new THREE.CylinderGeometry(radius,radius,h,24),mat(color));mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;scene.add(mesh);return mesh;}
  cylinder(3.2,.3,'#eee5d0',-4,.1,-11);cylinder(2.6,.25,'#587b78',-4,.34,-11);cylinder(2.25,.06,'#83b9bd',-4,.49,-11);cylinder(.45,1.3,'#e7dbc1',-4,1,-11);cylinder(1.2,.2,'#e7dbc1',-4,1.7,-11);
  for(const x of [-12,32])for(let z=-27;z<=28;z+=11){box(.15,3.4,.15,'#48615b',x,1.7,z);box(.75,.2,.55,'#fff3cf',x,3.45,z);box(2.1,.22,.7,'#967453',x+1.5,.65,z+2);box(2.1,.75,.14,'#967453',x+1.5,1,z+2.3);box(.15,.65,.6,'#4e6258',x+.7,.33,z+2);box(.15,.65,.6,'#4e6258',x+2.3,.33,z+2);}
  for(const l of locations){if(l.id==='sports'||l.id==='amphi')continue;box(l.w+1,.12,l.d+1,'#e3dcc7',l.x,-.01,l.z);for(const side of [-1,1]){box(1.5,.6,1,'#628557',l.x+side*(l.w/2+.9),.3,l.z+l.d/2);box(1,.14,.4,'#d2b467',l.x+side*(l.w/2+.9),.65,l.z+l.d/2);}}
  // A small entrance gate anchors the campus layout.
  for(const x of [-19,-11])box(.6,4,.8,'#eae0bf',x,2,32);box(9,.85,.9,'#426958',-15,4,32);box(7,.22,.3,'#dacb8f',-15,4.1,32.5);
  const selection=new THREE.Mesh(new THREE.RingGeometry(1,1.035,64),new THREE.MeshBasicMaterial({color:'#f3cc67',side:THREE.DoubleSide,transparent:true,opacity:.85}));selection.rotation.x=-Math.PI/2;selection.position.y=.22;scene.add(selection);
  const avatarMap=new Map<string,THREE.Group>();

  function avatar(s:Student){const g=createAvatar(s.color,s.appearance);g.scale.setScalar(1.45);scene.add(g);return g;}

  const marker=new THREE.Mesh(new THREE.OctahedronGeometry(.35),mat('#e8ff9a'));marker.position.set(0,3.2,0);scene.add(marker);

  const keys=new Set<string>();const ray=new THREE.Raycaster();const pointer=new THREE.Vector2();

  function click(e:PointerEvent){const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);const b=ray.intersectObjects(clickable,false)[0];if(b){latest.current.onSelect(b.object.userData.location);return;}const p=ray.intersectObject(ground)[0];if(p&&latest.current.me)latest.current.walk.current={x:p.point.x,z:p.point.z};}

  function keydown(e:KeyboardEvent){if((e.target as HTMLElement)?.matches('input,select,textarea,button,a'))return;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','w','a','s','d'].includes(e.key)){e.preventDefault();keys.add(e.key);latest.current.walk.current=null;}}

  // A drag moves the camera; only a released tap selects or walks.
  const freeCenter=new THREE.Vector3(6,0,0),floor=new THREE.Plane(new THREE.Vector3(0,1,0),0);
  let gesture:{id:number;x:number;y:number;anchor:THREE.Vector3;dragging:boolean}|null=null;
  function floorPoint(e:PointerEvent){const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);return ray.ray.intersectPlane(floor,new THREE.Vector3());}
  function pointerdown(e:PointerEvent){if(!e.isPrimary||e.button!==0)return;const anchor=floorPoint(e);if(!anchor)return;gesture={id:e.pointerId,x:e.clientX,y:e.clientY,anchor,dragging:false};renderer.domElement.setPointerCapture(e.pointerId);}
  function pointermove(e:PointerEvent){if(!gesture||gesture.id!==e.pointerId)return;if(!gesture.dragging&&Math.hypot(e.clientX-gesture.x,e.clientY-gesture.y)<6)return;
   if(!gesture.dragging){gesture.dragging=true;freeCenter.copy(cameraCenter);latest.current.onPan();renderer.domElement.classList.add('map-dragging');}
   const point=floorPoint(e);if(!point)return;freeCenter.x=THREE.MathUtils.clamp(freeCenter.x+gesture.anchor.x-point.x,-60,70);freeCenter.z=THREE.MathUtils.clamp(freeCenter.z+gesture.anchor.z-point.z,-45,50);cameraCenter.copy(freeCenter);camera.position.set(76+cameraCenter.x,100,95+cameraCenter.z);camera.lookAt(cameraCenter);camera.updateMatrixWorld();
  }
  function pointerup(e:PointerEvent){if(!gesture||gesture.id!==e.pointerId)return;const tap=!gesture.dragging;gesture=null;renderer.domElement.classList.remove('map-dragging');if(renderer.domElement.hasPointerCapture(e.pointerId))renderer.domElement.releasePointerCapture(e.pointerId);if(tap)click(e);}
  function pointercancel(){gesture=null;renderer.domElement.classList.remove('map-dragging');}
  const keyup=(e:KeyboardEvent)=>keys.delete(e.key);const blur=()=>{keys.clear();pointercancel();};
  renderer.domElement.addEventListener('pointerdown',pointerdown);renderer.domElement.addEventListener('pointermove',pointermove);renderer.domElement.addEventListener('pointerup',pointerup);renderer.domElement.addEventListener('pointercancel',pointercancel);renderer.domElement.addEventListener('lostpointercapture',pointercancel);window.addEventListener('keydown',keydown);window.addEventListener('keyup',keyup);window.addEventListener('blur',blur);

  let width=1,height=1;

  const resize=()=>{width=element.clientWidth;height=element.clientHeight;renderer.setSize(width,height);};const observer=new ResizeObserver(resize);observer.observe(element);resize();

  let frame=0,last=performance.now(),lastLabels=0;const cameraCenter=new THREE.Vector3(6,0,0);let followingId='';let lastViewReset=latest.current.viewReset;

  function loop(time:number){const dt=Math.min((time-last)/1000,.04);last=time;const p=latest.current;

   const picked=locations.find(l=>l.id===p.selected);selection.visible=!!picked;if(picked){selection.position.set(picked.x,.22,picked.z);selection.scale.setScalar(Math.max(picked.w,picked.d)*.7);}
   if(p.viewReset!==lastViewReset){lastViewReset=p.viewReset;freeCenter.set(6,0,0);}const desired=p.me&&p.follow?new THREE.Vector3(p.position.current.x,0,p.position.current.z):freeCenter;if(p.me?.id!==followingId){cameraCenter.copy(desired);followingId=p.me?.id||'';}cameraCenter.lerp(desired,Math.min(1,dt*6));camera.position.set(76+cameraCenter.x,100,95+cameraCenter.z);camera.lookAt(cameraCenter);const ratio=width/height;camera.left=-48*ratio/p.zoom;camera.right=48*ratio/p.zoom;camera.top=48/p.zoom;camera.bottom=-48/p.zoom;camera.updateProjectionMatrix();

   if(p.me){let dx=0,dz=0;const pos=p.position.current;

    if(keys.has('w')||keys.has('ArrowUp')){dx-=.7;dz-=.7;}if(keys.has('s')||keys.has('ArrowDown')){dx+=.7;dz+=.7;}if(keys.has('a')||keys.has('ArrowLeft')){dx-=.7;dz+=.7;}if(keys.has('d')||keys.has('ArrowRight')){dx+=.7;dz-=.7;}

    const dest=p.walk.current;if(dest){const distance=Math.hypot(dest.x-pos.x,dest.z-pos.z);if(distance<.5)p.walk.current=null;else{dx=(dest.x-pos.x)/distance;dz=(dest.z-pos.z)/distance;}}

    if(dx||dz){const scale=6*dt/Math.max(1,Math.hypot(dx,dz));const nx=Math.max(-46,Math.min(58,pos.x+dx*scale)),nz=Math.max(-36,Math.min(39,pos.z+dz*scale));

     const blocked=(x:number,z:number)=>locations.some(l=>l.id!=='sports'&&Math.abs(x-l.x)<l.w/2+.5&&Math.abs(z-l.z)<l.d/2+.5);

     if(!blocked(nx,pos.z))pos.x=nx;if(!blocked(pos.x,nz))pos.z=nz;p.onPosition(pos.x,pos.z);

    }

   }

   const all=[...(p.me?[{...p.me,...p.position.current}]:[]),...p.players];const ids=new Set(all.map(s=>s.id));for(const [id,g]of avatarMap){if(!ids.has(id)){scene.remove(g);avatarMap.delete(id);}}

   for(const s of all){let g=avatarMap.get(s.id);if(!g){g=avatar(s);avatarMap.set(s.id,g);}updateAvatarAppearance(g,s.color,s.appearance);const dx=s.x-g.position.x,dz=s.z-g.position.z;const moving=Math.hypot(dx,dz)>.008;if(moving)g.rotation.y=Math.atan2(dx,dz);animateAvatar(g,time,moving);g.position.set(s.x,0,s.z);}

   marker.visible=!!p.me;if(p.me){marker.position.set(p.position.current.x,4.5+Math.sin(time/400)*.15,p.position.current.z);marker.rotation.y=time/1000;}

   if(time-lastLabels>150){lastLabels=time;if(p.me){const av=new THREE.Vector3(p.position.current.x,5.8,p.position.current.z).project(camera);setAvatarLabel({x:(av.x+1)*width/2,y:(1-av.y)*height/2});}else setAvatarLabel(null);// Keep every visible building labelled. Move crowded labels instead of discarding them.
    const placed:{id:string;x:number;y:number;width:number;anchorX:number;anchorY:number}[]=[];
    const ranked=[...locations].sort((a,b)=>Number(b.id===p.selected)-Number(a.id===p.selected));
    for(const l of ranked){
     const v=new THREE.Vector3(l.x,l.type==='hostel'?5.1:5.8,l.z).project(camera);
     const anchorX=(v.x+1)*width/2,anchorY=(1-v.y)*height/2;
     if(anchorX<0||anchorX>width||anchorY<0||anchorY>height)continue;
     const labelWidth=l.short.length*(width<700?5:6)+42;
     const candidates=[];
     for(let ring=0;ring<=6;ring++)for(const offset of ring?[[0,-ring*28],[0,ring*28],[-ring*34,0],[ring*34,0],[-ring*28,-ring*28],[ring*28,ring*28]]:[[0,0]]){
      const x=THREE.MathUtils.clamp(anchorX+offset[0],labelWidth/2+8,width-labelWidth/2-8);
      const y=THREE.MathUtils.clamp(anchorY+offset[1],115,height-120);
      const avatarPoint=p.me?new THREE.Vector3(p.position.current.x,5.8,p.position.current.z).project(camera):null;
      const avatarCollision=avatarPoint&&Math.abs(x-(avatarPoint.x+1)*width/2)<labelWidth/2+110&&Math.abs(y-(1-avatarPoint.y)*height/2)<34?1:0;
      const collisions=avatarCollision+placed.filter(other=>Math.abs(other.x-x)<(other.width+labelWidth)/2+6&&Math.abs(other.y-y)<29).length;
      candidates.push({x,y,score:collisions*10000+Math.hypot(x-anchorX,y-anchorY)});
     }
     candidates.sort((a,b)=>a.score-b.score);const best=candidates[0];
     placed.push({id:l.id,...best,width:labelWidth,anchorX,anchorY});
    }
    setLabels(placed);}

   renderer.render(scene,camera);frame=requestAnimationFrame(loop);

  }frame=requestAnimationFrame(loop);

  return()=>{cancelAnimationFrame(frame);observer.disconnect();window.removeEventListener('keydown',keydown);window.removeEventListener('keyup',keyup);window.removeEventListener('blur',blur);renderer.domElement.removeEventListener('pointerdown',pointerdown);renderer.domElement.removeEventListener('pointermove',pointermove);renderer.domElement.removeEventListener('pointerup',pointerup);renderer.domElement.removeEventListener('pointercancel',pointercancel);renderer.domElement.removeEventListener('lostpointercapture',pointercancel);disposeAvatarScene(scene);renderer.dispose();renderer.domElement.remove();};

 },[]);

 return <div className="scene" ref={root} aria-label="Interactive OAU campus map">{failed&&<div className="map-fallback">Your browser couldn’t load the 3D map. You can still use Places to visit campus locations.</div>}<div className="map-labels"><svg className="map-label-leaders" aria-hidden="true">{labels.filter(p=>Math.hypot(p.x-p.anchorX,p.y-p.anchorY)>12).map(p=><line key={p.id} x1={p.anchorX} y1={p.anchorY} x2={p.x} y2={p.y}/>)}</svg>{avatarLabel&&props.me&&<span className="my-avatar-label" style={{left:avatarLabel.x,top:avatarLabel.y}}>YOU · {props.me.name}</span>}{labels.map(p=>{const l=locations.find(l=>l.id===p.id)!;return <button key={p.id} onClick={()=>props.onSelect(p.id)} aria-current={props.selected===l.id?'location':undefined} className={`map-label ${l.type} ${props.selected===l.id?'selected':''}`} style={{left:p.x,top:p.y}}><span className="map-pin-icon">{l.type==='hostel'?'🏡':l.id==='sports'?'⚽':l.type==='academic'?'📚':l.type==='food'?'🍲':l.id==='salon'?'👕':l.id==='health'?'✚':l.id==='shuttle'?'🚌':'✦'}</span> <span>{l.short}</span></button>;})}</div></div>;

}



