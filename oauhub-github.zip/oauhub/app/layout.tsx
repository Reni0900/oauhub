import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "OAU Life — Your Great Ife story",
  description: "Explore a playful OAU campus, create your student, and meet other players online.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
