'use client';
import {useRef,useState} from 'react';
import {Student,locations} from '../lib/campus';
import {LifeState} from '../lib/hostel-life';
import CampusApps,{venueApps,appNames} from './campus-apps';
import VenueScene from './venue-scene';
export default function VenueView({id,me,life,busy,onAction,onVisit,onExit}:{id:string;me:Student;life:LifeState|null;busy:boolean;onAction:(b:object)=>Promise<boolean>;onVisit:(id:string)=>void;onExit:()=>void}){
 const [activity,setActivity]=useState(0);const panel=useRef<HTMLElement>(null),place=locations.find(l=>l.id===id)!,app=venueApps[id];
 async function perform(b:object){const ok=await onAction(b);if(ok)setActivity(Date.now());return ok;}
 return <section className="venue-view" aria-label={`${place.short} interior`}><header><div><span className="eyebrow">CAMPUS LIFE</span><h1>{place.short}</h1></div><button className="exit-hostel" onClick={onExit}>Return to campus</button></header><div className="venue-play"><VenueScene activity={activity} me={me} kind={app} onInteract={()=>panel.current?.focus()}/><div className="room-caption">{me.name}<small>Walk with WASD or tap the floor. Use the counter to interact.</small></div><span className="venue-npc">Campus host · game character</span></div><aside tabIndex={-1} ref={panel} className="venue-panel"><h2>{appNames[app]}</h2><CampusApps app={app} me={me} life={life} busy={busy} onAction={perform} onVisit={onVisit}/></aside></section>;
}
