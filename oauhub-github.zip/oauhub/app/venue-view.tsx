'use client';
import {useState} from 'react';
import {ArrowLeft,ChevronDown,ChevronUp,MessageCircle,Minus,Plus,Send,Smartphone,Sparkles,X} from 'lucide-react';
import {Student,locations} from '../lib/campus';
import {LifeState} from '../lib/hostel-life';
import CampusApps,{venueApps,appNames} from './campus-apps';
import VenueScene from './venue-scene';
type ChatMessage={id:string;name:string;body:string;created:number};
export default function VenueView({id,me,life,busy,onAction,onVisit,onExit,onPhone,messages,message,onMessage,onSend}:{id:string;me:Student;life:LifeState|null;busy:boolean;onAction:(b:object)=>Promise<boolean>;onVisit:(id:string)=>void;onExit:()=>void;onPhone:()=>void;messages:ChatMessage[];message:string;onMessage:(v:string)=>void;onSend:(e:React.FormEvent)=>void}){
 const [activity,setActivity]=useState(0),[drawer,setDrawer]=useState<'activities'|'chat'|null>(null),[collapsed,setCollapsed]=useState(false),[zoom,setZoom]=useState(1);
 const place=locations.find(l=>l.id===id)!,app=venueApps[id];
 async function perform(b:object){const ok=await onAction(b);if(ok)setActivity(Date.now());return ok;}
 return <section className="venue-view immersive-interior" aria-label={`${place.short} interior`}>
  <div className="venue-play"><VenueScene activity={activity} me={me} kind={app} zoom={zoom} onInteract={()=>{setDrawer('activities');setCollapsed(false);}}/></div>
  <div className="venue-scene-hint">Tap the floor to walk · tap the counter to interact</div>
  <div className="interior-zoom"><button aria-label="Zoom in at venue" onClick={()=>setZoom(z=>Math.min(1.7,z+.15))}><Plus size={18}/></button><button aria-label="Zoom out at venue" onClick={()=>setZoom(z=>Math.max(.7,z-.15))}><Minus size={18}/></button></div>
  <section className={`venue-bottom-card ${collapsed?'collapsed':''}`} aria-label="Building controls">
   <header><span className="venue-student-icon" style={{background:me.color}}>{me.name.charAt(0)}</span><div><h1>{place.short}</h1><p>{place.action} · {me.name}</p></div><button aria-label="Return to campus" onClick={onExit}><ArrowLeft size={18}/></button><button aria-label={collapsed?'Expand building controls':'Collapse building controls'} onClick={()=>setCollapsed(!collapsed)}>{collapsed?<ChevronUp size={18}/>:<ChevronDown size={18}/>}</button></header>
   {!collapsed&&<><form className="chat-compose" onSubmit={onSend}><input aria-label="Building chat message" placeholder="Say something to students nearby…" maxLength={280} value={message} onChange={e=>onMessage(e.target.value)}/><button aria-label="Send building message" disabled={busy||!message.trim()}><Send size={18}/></button></form><nav aria-label="Building activities"><button aria-expanded={drawer==='activities'} onClick={()=>setDrawer(drawer==='activities'?null:'activities')}><Sparkles size={17}/>{appNames[app]||'Activities'}</button><button aria-expanded={drawer==='chat'} onClick={()=>setDrawer(drawer==='chat'?null:'chat')}><MessageCircle size={17}/>Nearby chat</button><button onClick={onPhone}><Smartphone size={17}/>Phone</button></nav></>}
  </section>
  {drawer&&<aside className="venue-panel venue-action-sheet" aria-label={drawer==='chat'?'Building conversation':'Building activities'}><header><div><small>{place.short}</small><h2>{drawer==='chat'?'Nearby conversation':appNames[app]||'Activities'}</h2></div><button aria-label="Close building panel" onClick={()=>setDrawer(null)}><X size={18}/></button></header>{drawer==='activities'?<CampusApps app={app} me={me} life={life} busy={busy} onAction={perform} onVisit={onVisit}/>:<div className="venue-chat-log" role="log">{messages.length?messages.map(m=><article key={m.id}><strong>{m.name}</strong><p>{m.body}</p><small>{new Date(m.created).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</small></article>):<p>No messages nearby yet. Start a conversation below.</p>}</div>}</aside>}
 </section>;
}
