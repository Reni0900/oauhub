'use client';
import {useEffect,useRef} from 'react';
import {GraduationCap,Home,Wallet,ArrowRight} from 'lucide-react';
import type {StudentOrigin} from '../lib/student-origin';
import {hostels} from '../lib/campus';
export default function OriginReveal({origin,onContinue}:{origin:StudentOrigin;onContinue:()=>void}){
 const button=useRef<HTMLButtonElement>(null);
 useEffect(()=>{const previous=document.activeElement as HTMLElement|null;button.current?.focus();return()=>previous?.focus();},[]);
 const rich=origin.background==='nepo',hostel=hostels.find(h=>h.id===origin.hostel);
 return <div className="modal-backdrop origin-backdrop"><section className={`create-modal origin-reveal ${rich?'nepo':'lapo'}`} role="dialog" aria-modal="true" aria-labelledby="origin-title" aria-describedby="origin-description" onKeyDown={e=>{if(e.key==='Tab'){e.preventDefault();button.current?.focus();}}}>
  <span className="eyebrow">VERSION 2 · YOUR STORY BEGINS</span><div className="origin-emblem"><GraduationCap size={48}/></div>
  <p className="origin-intro">Your campus background is…</p><h2 id="origin-title">{rich?'Nepo baby':'Lapo baby'}<span>!</span></h2>
  <p id="origin-description">{rich?'You come from a rich home. You arrive with a generous family allowance.':'You come from a modest home. Your own campus journey starts here.'}</p>
  <div className="origin-facts"><div><Wallet size={22}/><span>Starting student balance<strong>₦{origin.startingMoney.toLocaleString('en-NG')}</strong></span></div><div><Home size={22}/><span>Your assigned home<strong>{hostel?.short??origin.hostel}</strong><small>{origin.hostel==='maintenance'?'Off-campus · Female hostel':['ojaja','oakhouse'].includes(origin.hostel)?'Private hostel':'School hostel'}</small></span></div></div>
  <small className="origin-note">Randomly assigned once and saved to your account. Both backgrounds can reach every eligible hostel.</small>
  <button ref={button} className="primary enter-campus" onClick={onContinue}>Meet your student <ArrowRight size={18}/></button>
 </section></div>;
}
