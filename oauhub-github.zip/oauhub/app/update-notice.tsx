'use client';
import {useEffect,useState} from 'react';
import release from '../public/version.json';
type Release={version:string;kind:'big'|'small';title:string;notes:string};
export function needsUpdate(current:string,next:Release){return !!next.version&&next.version!==current;}
export default function UpdateNotice({busy=false}:{busy?:boolean}){
 const [next,setNext]=useState<Release|null>(null);
 useEffect(()=>{let stopped=false;async function check(){try{const r=await fetch(new URL('./version.json',window.location.href),{cache:'no-store'});if(!r.ok)return;const d=await r.json() as Release;if(!stopped&&['big','small'].includes(d.kind))setNext(needsUpdate(release.version,d)?d:null);}catch{}}
 void check();const timer=setInterval(()=>{if(!document.hidden)void check();},30000);const focus=()=>void check();window.addEventListener('focus',focus);return()=>{stopped=true;clearInterval(timer);window.removeEventListener('focus',focus);};},[]);
 function refresh(){window.location.reload();}
 useEffect(()=>{if(next?.kind!=='small')return;const timer=setInterval(()=>{const field=document.activeElement?.tagName;if(!busy&&!['INPUT','TEXTAREA','SELECT'].includes(field||'')&&!document.hidden)refresh();},2000);return()=>clearInterval(timer);},[next,busy]);
 return next?.kind==='big'?<section className="update-available" role="status"><div><strong>A new update is available</strong></div><button className="primary small" disabled={busy} onClick={refresh}>Refresh game</button></section>:null;
}
