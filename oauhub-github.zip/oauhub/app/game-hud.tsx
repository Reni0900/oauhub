'use client';
import {useEffect,useState} from 'react';
import {Student} from '../lib/campus';
import {LifeState} from '../lib/hostel-life';
import {campusJobs} from '../lib/campus-life';
type Activity={source:string;label:string;started:number;duration:number};
export type SiteMetrics={online:number;visitors:number};
export default function GameHud({me,life,metrics,busy,onJobs}:{me:Student|null;life:LifeState|null;metrics:SiteMetrics|null;busy:boolean;onJobs:()=>void}){
 const [clock,setClock]=useState(Date.now()),[activities,setActivities]=useState<Record<string,Activity>>({});
 useEffect(()=>{const handler=(e:Event)=>{const a=(e as CustomEvent<Activity>).detail;setActivities(current=>{const copy={...current};if(a.label)copy[a.source]=a;else delete copy[a.source];return copy;});};window.addEventListener('oauhub-activity',handler);const timer=setInterval(()=>setClock(Date.now()),1000);return()=>{window.removeEventListener('oauhub-activity',handler);clearInterval(timer);};},[]);
 const job=campusJobs.find(j=>j.id===life?.campus.job?.id),remaining=job&&life?.campus.job?Math.max(0,Math.ceil((life.campus.job.started+job.duration*1000-clock)/1000)):0;
 const active=Object.values(activities).filter(a=>!a.duration||clock<a.started+a.duration*1000).sort((a,b)=>b.started-a.started)[0];
 const mood=me?me.energy<25||me.hunger<25?'Need a break':me.social>65&&me.energy>50?'Very happy':'Feeling good':'Welcome to Ife';
 return <aside className="global-game-hud" aria-label="Live game status"><div className="game-status-pill"><time>{new Date(clock).toLocaleString('en-GB',{timeZone:'Africa/Lagos',weekday:'short',hour:'2-digit',minute:'2-digit'})}</time><span className="hud-mood">{mood}</span><span title="Active browsers seen in the last 30 seconds"><i/>{metrics?.online.toLocaleString()??'…'} online</span><span title="Unique browsers since visitor tracking began">◉ {metrics?.visitors.toLocaleString()??'…'} visits</span>{me&&<strong>₦{me.money.toLocaleString()}</strong>}</div><div className="global-activity-row"><span className="activity-pill" role="status"><i className={busy||active||remaining?'activity-pulse':''}/><span><strong>{busy?'Saving activity…':active?.label||(me?.inside?'At home':'Exploring campus')}</strong><small>{active?.duration?`${Math.max(0,Math.ceil((active.started+active.duration*1000-clock)/1000))}s remaining`:active?'In progress':me?.inside?'Your home on campus':'Your Great Ife story'}</small></span></span>{job&&<button className="activity-pill job-status" onClick={onJobs}><span><strong>{job.name}</strong><small>{remaining?`${remaining}s · ₦${job.reward.toLocaleString()}`:`Collect ₦${job.reward.toLocaleString()}`}</small></span></button>}</div></aside>;
}
