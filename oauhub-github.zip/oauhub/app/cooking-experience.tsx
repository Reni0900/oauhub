'use client';
import {useEffect,useRef,useState} from 'react';
import {ChefHat,Check,Flame,Utensils,X} from 'lucide-react';
import {useActivityStatus} from '../lib/activity-status';
import {Student} from '../lib/campus';
import {meals} from '../lib/hostel-life';
export default function CookingExperience({me,busy,onCook,onClose}:{me:Student;busy:boolean;onCook:(meal:string)=>Promise<boolean>;onClose:()=>void}){
 const [meal,setMeal]=useState(meals[0].id),[stage,setStage]=useState<'choose'|'prep'|'heat'|'serve'|'done'>('choose'),[chops,setChops]=useState(0),[progress,setProgress]=useState(0),[error,setError]=useState('');const saving=useRef(false),dialog=useRef<HTMLElement>(null);
 const recipe=meals.find(m=>m.id===meal)!;
 useActivityStatus('cooking',!['choose','done'].includes(stage)?'Cooking a meal':'');
 useEffect(()=>{const before=document.activeElement as HTMLElement|null;dialog.current?.querySelector<HTMLButtonElement>('button')?.focus();return()=>before?.focus();},[]);
 useEffect(()=>{if(stage!=='heat')return;const timer=setInterval(()=>setProgress(p=>Math.min(100,p+10)),400);return()=>clearInterval(timer);},[stage]);
 useEffect(()=>{if(progress===100)setStage('serve');},[progress]);
 async function serve(){if(saving.current)return;saving.current=true;setError('');try{if(await onCook(meal))setStage('done');else setError('Could not save this meal. Wait a few seconds and try again.');}finally{saving.current=false;}}
 return <div className="modal-backdrop cooking-backdrop"><section ref={dialog} className="create-modal cooking-modal" role="dialog" aria-modal="true" aria-labelledby="cooking-title" onKeyDown={e=>{if(e.key==='Escape'&&!busy)onClose();if(e.key==='Tab'){const nodes=Array.from(dialog.current!.querySelectorAll<HTMLElement>('button:not(:disabled),select:not(:disabled)'));const first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}}}>
 <button className="modal-close icon-button" aria-label="Close kitchen" disabled={busy} onClick={onClose}><X size={20}/></button><span className="eyebrow">YOUR KITCHEN</span><h2 id="cooking-title">Something good<br/>is cooking.</h2>
 <div className={`cooking-stove ${stage==='heat'?'heating':''}`} aria-hidden="true"><div className="cooking-steam"><i/><i/><i/></div><div className="cooking-pot"><span>{stage==='done'?<Check/>:<Utensils/>}</span></div><div className="cooking-burner"><Flame/></div></div>
 <ol className="cooking-steps"><li className={stage==='choose'?'active':''}>Choose</li><li className={stage==='prep'?'active':''}>Prep</li><li className={stage==='heat'?'active':''}>Cook</li><li className={stage==='serve'||stage==='done'?'active':''}>Serve</li></ol>
 {stage==='choose'&&<><p>Pick a meal. The ingredient cost comes from your game wallet when you serve it.</p><label>Recipe<select value={meal} onChange={e=>setMeal(e.target.value)}>{meals.map(m=><option key={m.id} value={m.id}>{m.name} · ₦{m.price}</option>)}</select></label><button className="primary enter-campus" disabled={me.money<recipe.price} onClick={()=>setStage('prep')}><ChefHat size={18}/>Prepare ingredients</button></>}
 {stage==='prep'&&<><p role="status">Prepare your ingredients: {chops}/3 steps.</p><button className="primary enter-campus" onClick={()=>{const next=chops+1;setChops(next);if(next===3)setStage('heat');}}>Chop & prepare</button></>}
 {stage==='heat'&&<><p role="status">{recipe.name} is on the stove…</p><progress aria-label="Cooking progress" max={100} value={progress}/></>}
 {stage==='serve'&&<><p>{recipe.name} is ready. Serving costs ₦{recipe.price} and adds {recipe.hunger} hunger points.</p><button className="primary enter-campus" disabled={busy||me.money<recipe.price} onClick={()=>void serve()}>{busy?'Serving…':'Serve & eat'}</button></>}
 {stage==='done'&&<><p role="status">Meal cooked, enjoyed and saved to your account.</p><button className="primary enter-campus" onClick={onClose}><Check size={18}/>Back home</button></>}{error&&<p className="account-error" role="alert">{error}</p>}
 </section></div>;
}
